from pathlib import Path
import datetime, hashlib, json, subprocess

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / 'labbit-vm-access-147'
P = REPO / 'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
def sha(b): return hashlib.sha256(b).hexdigest()
source = json.loads((P / 'source-manifest.json').read_text(encoding='utf-8'))
checks = []
for x in source['productFiles']:
    data = (REPO / x['path']).read_bytes()
    committed = subprocess.check_output(['git', 'show', source['codeCommit'] + ':' + x['path']], cwd=REPO)
    blob = subprocess.check_output(['git', 'hash-object', '--path', x['path'], str(REPO / x['path'])], cwd=REPO).decode().strip()
    committed_blob = subprocess.check_output(['git', 'rev-parse', source['codeCommit'] + ':' + x['path']], cwd=REPO).decode().strip()
    assert sha(data) == x['byteSHA256'] and blob == committed_blob == x['gitBlob']
    assert data.replace(b'\r\n', b'\n') == committed.replace(b'\r\n', b'\n')
    checks.append({'path': x['path'], 'exactBytes': data == committed, 'eolOnly': data != committed,
                   'byteSHA256': sha(data), 'committedSHA256': sha(committed), 'cleanAndCommittedBlob': blob})
expected = {'contracts/http/openapi.yaml', 'go.mod', 'go.sum', 'runtime/README.md', 'runtime/contract.yaml', 'web/package-lock.json', 'web/package.json'}
assert {x['path'] for x in checks if x['eolOnly']} == expected
assert sum(x['exactBytes'] for x in checks) == 32
mapping = json.loads((OUT / 'independent-final-source-mapping.json').read_text(encoding='utf-8'))
assert len(mapping['latestVMSource']) == 36
assert sum(x['commitBytesMatch'] for x in mapping['latestVMSource']) == 32
assert {x['path'] for x in mapping['latestVMSource'] if not x['commitBytesMatch']} == expected - {'contracts/http/openapi.yaml', 'web/package-lock.json', 'web/package.json'}
report = OUT / 'independent-review.md'
previous = report.read_bytes()
(OUT / 'independent-review-before-eol-correction.md').write_bytes(previous)
text = previous.decode('utf-8').replace('\r\r\n', '\n').replace('\r\n', '\n')
assert '34exactbyte+runtime2EOL-only' in text
assert '34개Go/의존파일은최종committedblobexact bytes, runtime2개는EOL-only다.' in text
text = text.replace('34exactbyte+runtime2EOL-only', 'Go32exactbyte+go.mod/go.sum/runtime2총4EOL-only')
text = text.replace('34개Go/의존파일은최종committedblobexact bytes, runtime2개는EOL-only다.', '32개Go파일은최종committedblobexact bytes, go.mod/go.sum/runtime2개총4개는EOL-only다.')
text += '\n\n### 게시 감사 P3/EOL 집계 정정\n\n'
text += 'source-only section7의초기집계는Go/의존34exact와runtime2EOL-only라고잘못표현했다. 게시감사에서전체PR84집합에는go.mod/go.sumcontext가없는데그집계를최신36source에확대했음을발견해수정했다. 개별JSONrawSHA/cleanGitblob매핑은이미정확했으며제품내용변경이나실행소스유실은없다. 실제36source는Go32exact+go.mod/go.sum/runtime2총4EOL-only; publication39는그36+OpenAPI/Web2context를포함하여Go32exact+7EOL-only다. 39rawSHA와Gitcleanblob/committedblob및LF정규화동일성을재대조했고7개정확한집합을assert했다. 기존84PR파일은78exact+역사JSON4/runtime2 EOL-only로초기집계가맞다. 수정전보고서원본은외부independent-review-before-eol-correction.md에보존한다.\n'
report.write_bytes(text.encode('utf-8'))
result = {'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'finding': 'PUB-SOURCE-EOL/P3',
          'result': 'PASS', 'previousReportSHA256': sha(previous), 'correctedReportSHA256': sha(report.read_bytes()),
          'latestVMSourceCount': 36, 'latestVMExactGoCount': 32, 'latestVMEOLOnlyCount': 4,
          'publicationSourceCount': 39, 'publicationExactGoCount': 32, 'publicationEOLOnlyCount': 7,
          'productSourceChanged': False, 'checks': checks}
(OUT / 'publication-eol-regression.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'checks'}))
