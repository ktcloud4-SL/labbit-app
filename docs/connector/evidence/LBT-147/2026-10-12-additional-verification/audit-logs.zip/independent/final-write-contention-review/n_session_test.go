package terminal

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"github.com/ktcloud4-SL/labbit-app/internal/connector/protocol"
)

// This observes cumulative lock-contention latency only. Each lock is held
// synthetically; there is no claim of real network backpressure in this test.
func TestReviewTwentyBusySessionShutdown(t *testing.T) {
	const count = 20
	stop := make(chan struct{})
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		peer, err := (&websocket.Upgrader{CheckOrigin: func(*http.Request) bool { return true }}).Upgrade(w, r, nil)
		if err != nil {
			return
		}
		defer peer.Close()
		<-stop
	}))
	defer server.Close()
	defer close(stop)
	var callbacks atomic.Int64
	manager := NewSessionManager(time.Minute, func(*Session, string, *int, error) { callbacks.Add(1) })
	for i := 0; i < count; i++ {
		client, _, err := websocket.DefaultDialer.Dial("ws"+strings.TrimPrefix(server.URL, "http"), nil)
		if err != nil {
			t.Fatal(err)
		}
		defer client.Close()
		pty := &streamingDataPTY{start: make(chan struct{}), closed: make(chan struct{})}
		session, _, err := manager.GetOrCreateSession(protocol.TerminalOpenPayload{TargetVmKey: "workspace", ProviderServerID: "server-1"}, protocol.BaseEnvelope{TerminalSessionID: fmt.Sprint(i), LabInstanceID: "lab", Generation: 1}, func() (PTYChannel, error) { return pty, nil })
		if err != nil {
			t.Fatal(err)
		}
		if _, err := session.AttachDataConn(client); err != nil {
			t.Fatal(err)
		}
		session.writeMu.Lock()
		defer session.writeMu.Unlock()
	}
	start := time.Now()
	done := make(chan struct{})
	go func() { manager.Shutdown(protocol.TerminalReasonServiceRestart); close(done) }()
	select {
	case <-done:
	case <-time.After(3 * time.Second):
		t.Fatal("20 synthetically busy locks exceeded 3s observation limit")
	}
	if callbacks.Load() != count || manager.ActiveCount() != 0 {
		t.Fatalf("callbacks=%d remaining=%d", callbacks.Load(), manager.ActiveCount())
	}
	t.Logf("syntheticBusyLocks=%d elapsedMilliseconds=%d expectedCumulativeLockBudgetMilliseconds=%d callbacks=%d", count, time.Since(start).Milliseconds(), count*finalDataWriteLockWait.Milliseconds(), callbacks.Load())
}
