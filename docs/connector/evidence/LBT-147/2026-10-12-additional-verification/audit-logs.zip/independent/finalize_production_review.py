from pathlib import Path
import datetime, hashlib, json, subprocess

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / 'labbit-vm-access-147'
RUN = OUT.parent / 'LBT-147-additional-verification-20261012'

def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=REPO)
def actions(p):
    events = [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s.startswith('{')]
    return {a: sum(bool(e.get('Test')) and e.get('Action') == a for e in events) for a in ('pass', 'fail', 'skip')}

head = git('rev-parse', 'HEAD').decode().strip()
main = git('rev-parse', 'origin/main').decode().strip()
old = read(OUT / 'independent-current-source-manifest.json')
reviewed = [x for x in old['files'] if x['role'] != 'pending-publication']
pr = git('diff', '--name-only', main + '...HEAD').decode('utf-8').splitlines()
assert set(pr) == {x['path'] for x in reviewed}
checks = []
for item in reviewed:
    path = item['path']
    data = (REPO / path).read_bytes()
    committed = git('show', head + ':' + path)
    checks.append({'path': path, 'role': item['role'], 'sha256': sha(data),
                   'snapshotMatch': sha(data) == item['sha256'], 'commitBytesMatch': data == committed,
                   'committedSha256': sha(committed), 'commitContentMatch': data.replace(b'\r\n', b'\n') == committed.replace(b'\r\n', b'\n'),
                   'committedBlob': git('rev-parse', head + ':' + path).decode().strip()})
assert all(x['snapshotMatch'] and x['commitContentMatch'] for x in checks)
latest = read(RUN / 'latest-vm-tested-source.json')
latest_checks = []
for item in latest['files']:
    path = item['path']
    data = (REPO / path).read_bytes()
    committed = git('show', head + ':' + path)
    latest_checks.append({'path': path, 'sha256': sha(data), 'testedBytesMatch': sha(data) == item['sha256'],
                          'commitBytesMatch': data == committed, 'committedSha256': sha(committed),
                          'commitContentMatch': data.replace(b'\r\n', b'\n') == committed.replace(b'\r\n', b'\n')})
assert latest['head'] == head and latest['main'] == main
assert all(x['testedBytesMatch'] and x['commitContentMatch'] for x in latest_checks)
assert sum(x['commitBytesMatch'] for x in latest_checks) == 32
assert {x['path'] for x in latest_checks if not x['commitBytesMatch']} == {'go.mod', 'go.sum', 'runtime/README.md', 'runtime/contract.yaml'}
runs = read(RUN / 'latest-vm-results.json')
assert all(x['exitCode'] == 0 and x['counts'] == {'pass': 1, 'fail': 0, 'skip': 0} for x in runs)
logs = []
for x in runs:
    p = RUN / (x['label'] + '.jsonl')
    assert actions(p) == x['counts']
    logs.append({'path': p.name, 'sha256': sha(p.read_bytes()), 'counts': actions(p)})
assert read(RUN / 'latest-vm-final-source-state.json')['changedSourceFiles'] == []
portable = {}
for mode, expected in [('before', 1), ('current', 0)]:
    p = OUT / ('portable-ssh-' + mode)
    result = read(p / 'result.json')
    assert result['exitCode'] == expected and not result['cloudExecuted'] and not result['repositoryEditsByThisScript']
    raw = p / 'go-test.jsonl'
    if not raw.exists():
        matches = list(p.glob('*.jsonl'))
        assert len(matches) == 1
        raw = matches[0]
    portable[mode] = {'result': result, 'resultSha256': sha((p / 'result.json').read_bytes()),
                      'rawSha256': sha(raw.read_bytes()), 'counts': actions(raw), 'rawName': raw.name}

mapping = {'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'originMain': main,
           'reviewedCommittedFiles': len(reviewed), 'files': checks, 'latestVMSource': latest_checks,
           'latestVMRuns': runs, 'latestVMRawLogs': logs, 'portableSSH': portable,
           'publicationReviewed': False, 'newEvidencePrefixExcluded': 'docs/connector/evidence/LBT-147/2026-10-12-additional-verification/'}
(OUT / 'independent-final-source-mapping.json').write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

report_path = OUT / 'independent-review.md'
report = report_path.read_text(encoding='utf-8-sig')
report = report.replace('HEAD `a5b2d1210c3941641dc96dfc4aa2201358e9293a`.', '실행 snapshot HEAD `a5b2d1210c3941641dc96dfc4aa2201358e9293a` + local; 최종 코드 HEAD `' + head + '`로 아래 section7에서 byte mapping을 확정했다.')
report = report.replace('최신Close delegation의realSFTP-after-PTY-close는normalVM test 재실행 권장/현재미실행', '최신Close delegation의realSFTP-after-PTY-close는현재코드normalVM test 재실행PASS(section7)')
report = report.replace('기존 actual no-channel idle 후 다른 SSH_CONNECTION', '현재코드actual no-channel idle 후 다른 SSH_CONNECTION(section7)')
report = report.replace('다만최신Close delegation의actualSFTP-after-PTY-close/idleidentity는oldnormalVMsource기록과구분하며현재source TestOpenStackVMAccessIntegration 재실행을root에게요청했다.', '최신Close delegation의actualSFTP-after-PTY-close/idleidentity도현재source TestOpenStackVMAccessIntegration 재실행으로직접검증됐다(section7).')
report = report.replace('최종 결과를 그대로 확인해야 한다.', '선택3test -race3의중첩test action15PASS/0FAIL/0skip를확인했다. 별도Before mode는count1 예상FAIL을실제재실행해원본/exit1을보존했다(section7).')
report += '\n\n## 7. 최종 코드 커밋 및 최신 real PTY/SFTP/idle 검증 보완\n\n'
report += f'독립 확인 UTC: {mapping["recordedAt"]}. 최종 코드 HEAD `{head}`, origin/main `{main}`. 현재 committed PR 전체84파일은 앞서 검토한 source/역사 Evidence84파일과정확히같은집합이며, 모두reviewedsnapshot SHA에일치한다(불일치0). Gitcommittedcontent는78파일exact bytes,6파일은workingCRLF→GitLF만다르다(runtimeREADME/contract2개,과거2026-10-10JSON4개). 이전89파일snapshot에는당시초안5파일이포함됐으며그5파일은pending-publication이다. 현재새Evidence폴더전체는이production판정에서제외하고후속게시감사로검토한다. `independent-final-source-mapping.json`에84파일검사와현재실행36source의Go32exactbyte+go.mod/go.sum/runtime2총4EOL-only를보존했다. 최신main통합과9파일코드커밋은이미검토한production/test바이트의고정이며새동작변경은없다.\n\n'
report += '| 추가 실제 실행 | tested source / 결과 | 독립 확인한 행동 |\n| --- | --- | --- |\n'
report += f'| current TestOpenStackVMAccessIntegration | `{head}`; -race count1 PASS/no skip; 2026-10-12 07:39:53–07:43:36 UTC, test214.69s | real OP-01 gen1; strict Lab/gen/VM rejection; authenticated/pinned managementSSH; PTY input/output/resize; simultaneous SFTP INIT/VERSION; PTY.Close 뒤SFTP REALPATH 성공; 메모리에서SSH_CONNECTION 두번같음 및 idle후다름; Resetgen2 새Server와stalegen1거절 |\n'
report += '| current cleanup / read-only pre+final inventory | 각PASS/no skip; final07:43:46 UTC | gen1+gen2 distinct14 ResourceRef 각각GET404; finalmatchingprefix0; servers0/images3/flavors4/networks4; pre와final keypairs1/SG4/ports11/subnets4/router1 동일. 이normaltest의임시keypair/managementSG는ownDelete cleanup와prefixList0으로검증했으며aux각각의독립GET404로그는주장하지않는다. |\n\n'
report += 'VM integration은현재production을그대로사용했다. cloud overlay는sharedintegration helper의metadata-only 로그/cleanup 검증과read-only inventory fixture만바꿨으며VMAccess/Terminal/Providerproduction은바꾸지않았다. 이번실제실행36개source는실행전manifest/currentworkingbytes모두일치하고실행후changedSourceFiles=[]다. 32개Go파일은최종committedblobexact bytes, go.mod/go.sum/runtime2개총4개는EOL-only다. PTY내용/SSH_CONNECTION/개인키는로그되지않고식별비교는메모리에서만했다. productionFileCRUD는이minimalSFTPwireprobe의증명범위가아니다.\n\n'
report += '| 최신 원본 | SHA256 | counts |\n| --- | --- | --- |\n'
for x in logs: report += f'| `{x["path"]}` | `{x["sha256"]}` | {json.dumps(x["counts"])} |\n'
report += '\nPortableSSH별도확인: Current는최종Session/SSHPTYbyte로-race count3 실행한15test-actionPASS이며Cloud0/소스수정0; Before는동일fixture/currentVMAccess와a5rawSSHPTY+Datafix-onlySessionoverlay로count1 실제실행한예상5FAIL/exit1이다. 두result모두source/fixtureSHA,명령,before/aftergitstatus를보존했고prepareddependency/scenarioidentity를구분했다. Before실행당시HEAD는bd8071이지만production두파일만의oldbyteoverlay이므로최종코드의실패로해석하지않는다.\n\n'
report += '**최종 production/동작 판정: 검토한PR범위에서미해결confirmed결함없음.** R1/R2/R3, partialfencing/lazyinit, 새Data/SSHbackpressure/ownership/Resize수정과최신actualPTY/SFTP/sharedidle/Reset/Cleanup을검증했다. PR84의로컬OpenStack구현범위는충족하며KT/Browser/actualSaaS/Fileproduction미검증범위는section6과같다. 새Evidence문서/ZIP/재현helper/secret/checksum의최종publication판정은아직별도검토대상이다.\n'
report_path.write_text(report, encoding='utf-8')
print(json.dumps({'head': head, 'reviewedCommittedFiles': len(reviewed), 'reviewedSHAOrBlobMismatch': 0,
                  'exactCommitBytes': sum(x['commitBytesMatch'] for x in checks), 'eolOnlyFiles': [x['path'] for x in checks if not x['commitBytesMatch']],
                  'latestVMSourceFiles': len(latest_checks), 'latestVMSourceMismatch': 0,
                  'portableCounts': {k: v['counts'] for k, v in portable.items()},
                  'reportSha256': sha(report_path.read_bytes()),
                  'mappingSha256': sha((OUT / 'independent-final-source-mapping.json').read_bytes())}, ensure_ascii=False))
