from pathlib import Path
import subprocess,json,hashlib
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent/'labbit-vm-access-147'
old=subprocess.check_output(['git','show','a5b2d1210c3941641dc96dfc4aa2201358e9293a:internal/connector/terminal/ssh_pty.go'],cwd=REPO)
(ROOT/'ssh_pty_before_lifecycle.go').write_bytes(old)
replacements={str(REPO/'internal/connector/terminal/ssh_pty.go'):str(ROOT/'ssh_pty_before_lifecycle.go'),str(REPO/'internal/connector/terminal/session.go'):str(ROOT/'session_candidate.go'),str(REPO/'internal/connector/terminal/independent_ssh_unread_lifecycle_test.go'):str(ROOT/'ssh_unread_lifecycle_test.go'),str(REPO/'internal/connector/terminal/independent_ssh_manager_unread_test.go'):str(ROOT/'ssh_manager_unread_test.go')}
(ROOT/'ssh-manager-unread-before-overlay.json').write_text(json.dumps({'Replace':replacements},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'ssh_pty_before_lifecycle.go',ROOT/'session_candidate.go',ROOT/'ssh_manager_unread_test.go']},indent=2))
