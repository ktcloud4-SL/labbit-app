"""Prepare review-only overlays; never writes repository source or runs cloud."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "labbit-vm-access-147"
SOURCE = REPO / "internal/connector/terminal/session.go"
original_bytes = subprocess.check_output(["git", "show", "da6b6701f13ba17c38b0778983545da62ac07212:internal/connector/terminal/session.go"], cwd=REPO)
(ROOT / "session_original.go").write_bytes(original_bytes)
original = original_bytes.decode("utf-8").replace("\r\n", "\n")
before = """\t\t\ts.writeMu.Lock()
\t\t\t_ = conn.WriteJSON(endedMsg)
\t\t\t_ = conn.Close()
\t\t\ts.writeMu.Unlock()"""
after = """\t\t\t// Data ENDED is best effort. Never wait behind an unread peer's
\t\t\t// active write: Close is permitted concurrently by gorilla/websocket
\t\t\t// and releases that write before PTY and Control cleanup proceeds.
\t\t\tif s.writeMu.TryLock() {
\t\t\t\t// This is an internal final-frame budget, not a wire limit or
\t\t\t\t// the SaaS/platform graceful shutdown budget. The lock also
\t\t\t\t// serializes SetWriteDeadline with all regular write methods.
\t\t\t\t_ = conn.SetWriteDeadline(time.Now().Add(time.Second))
\t\t\t\t_ = conn.WriteJSON(endedMsg)
\t\t\t\t_ = conn.Close()
\t\t\t\ts.writeMu.Unlock()
\t\t\t} else {
\t\t\t\t_ = conn.Close()
\t\t\t}"""
assert original.count(before) == 1
minimal = original.replace(before, after)
(ROOT / "session_close_only.go").write_text(minimal, encoding="utf-8", newline="\n")
old_close = """\t\ts.writeMu.Lock()
\t\t_ = oldConn.Close()
\t\ts.writeMu.Unlock()"""
assert original.count(old_close) == 2
complete = minimal.replace(old_close, """\t\t// Close may run concurrently with writes. Waiting for writeMu
\t\t// would strand an unread old socket after ownership has moved.
\t\t_ = oldConn.Close()""")
(ROOT / "session_candidate.go").write_text(complete, encoding="utf-8", newline="\n")
tests = {
    "internal/connector/terminal/audit_unread_shutdown_test.go": "unread_shutdown_test.go",
    "internal/connector/terminal/audit_replacement_unread_test.go": "replacement_unread_test.go",
    "internal/connector/app/audit_runcontrol_unread_test.go": "runcontrol_unread_test.go",
    "internal/connector/terminal/audit_finalframe_unread_test.go": "finalframe_unread_test.go",
}
for mode in ("before", "close-only", "candidate"):
    replacements = {str(REPO / name): str(ROOT / source) for name, source in tests.items()}
    if mode == "before":
        replacements[str(SOURCE)] = str(ROOT / "session_original.go")
    else:
        replacements[str(SOURCE)] = str(ROOT / ("session_close_only.go" if mode == "close-only" else "session_candidate.go"))
    (ROOT / f"{mode}-all-overlay.json").write_text(json.dumps({"Replace": replacements}, indent=2), encoding="utf-8", newline="\n")
print(json.dumps({"originalSHA256": hashlib.sha256(original_bytes).hexdigest(), "repositoryModifiedByThisScript": False, "cloudRun": False}))
