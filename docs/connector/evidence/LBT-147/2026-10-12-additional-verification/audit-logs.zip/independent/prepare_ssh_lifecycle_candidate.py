from pathlib import Path
import subprocess,json,hashlib
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'labbit-vm-access-147'
ssh=(REPO/'internal/connector/terminal/ssh_pty.go').read_text(encoding='utf-8')
session=(REPO/'internal/connector/terminal/session.go').read_text(encoding='utf-8')
assert 'if p.closeChannel != nil {\n\t\treturn p.closeChannel()' not in ssh
ssh=ssh.replace('func (p *SSHPTY) Resize(cols, rows int) error {\n\tp.mu.Lock()\n\tdefer p.mu.Unlock()\n\tif p.closed {\n\t\treturn io.ErrClosedPipe\n\t}\n\tp.cols = cols\n\tp.rows = rows\n', 'func (p *SSHPTY) Resize(cols, rows int) error {\n\tp.mu.Lock()\n\tif p.closed {\n\t\tp.mu.Unlock()\n\t\treturn io.ErrClosedPipe\n\t}\n\tp.cols = cols\n\tp.rows = rows\n\tp.mu.Unlock()\n')
ssh=ssh.replace('\tp.closed = true\n\n\tvar errs []error', '\tp.closed = true\n\n\t// Managed channel cleanup must not wait for an SSH packet write.\n\tif p.closeChannel != nil {\n\t\treturn p.closeChannel()\n\t}\n\n\tvar errs []error',1)
old='''func (s *Session) Resize(cols, rows int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.Status == StatusClosed {
		return ErrSessionAlreadyClosed
	}

	s.Cols = cols
	s.Rows = rows
	if s.PTY != nil {
		return s.PTY.Resize(cols, rows)
	}
	return nil
}'''
new='''func (s *Session) Resize(cols, rows int) error {
	s.mu.Lock()
	if s.Status == StatusClosed {
		s.mu.Unlock()
		return ErrSessionAlreadyClosed
	}
	s.Cols = cols
	s.Rows = rows
	pty := s.PTY
	s.mu.Unlock()
	if pty != nil {
		return pty.Resize(cols, rows)
	}
	return nil
}'''
assert old in session
session=session.replace(old,new,1)
for name,data in [('ssh_pty_lifecycle_candidate.go',ssh),('session_ssh_lifecycle_candidate.go',session)]:
 (ROOT/name).write_text(data,encoding='utf-8',newline='\n')
subprocess.run(['gofmt','-w',str(ROOT/'ssh_pty_lifecycle_candidate.go'),str(ROOT/'session_ssh_lifecycle_candidate.go')],check=True)
replacements={
 str(REPO/'internal/connector/terminal/ssh_pty.go'):str(ROOT/'ssh_pty_lifecycle_candidate.go'),
 str(REPO/'internal/connector/terminal/session.go'):str(ROOT/'session_ssh_lifecycle_candidate.go'),
 str(REPO/'internal/connector/terminal/independent_ssh_unread_lifecycle_test.go'):str(ROOT/'ssh_unread_lifecycle_test.go'),
}
(ROOT/'ssh-lifecycle-candidate-overlay.json').write_text(json.dumps({'Replace':replacements},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'ssh_pty_lifecycle_candidate.go',ROOT/'session_ssh_lifecycle_candidate.go',ROOT/'ssh_unread_lifecycle_test.go']},indent=2))
