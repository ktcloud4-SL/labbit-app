param(
    [Parameter(Mandatory=$true)][string]$Repo,
    [string]$Out = (Join-Path $PSScriptRoot 'reproduced'),
    [ValidateSet('Before','Candidate','Current')][string]$Mode = 'Current',
    [ValidateRange(1,20)][int]$Count = 3
)
$ErrorActionPreference = 'Stop'
$auditRepo = (Resolve-Path -LiteralPath $Repo).Path
$auditOutput = [IO.Path]::GetFullPath($Out)
$auditRoot = [IO.Path]::GetFullPath($PSScriptRoot)
if ($auditOutput.StartsWith($auditRepo + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or $auditOutput -eq $auditRepo) {
    throw 'Output must be outside the repository.'
}
[void][IO.Directory]::CreateDirectory($auditOutput)
$auditTests = @{
    'internal/connector/terminal/audit_unread_shutdown_test.go' = 'unread_shutdown_test.go'
    'internal/connector/terminal/audit_replacement_unread_test.go' = 'replacement_unread_test.go'
    'internal/connector/terminal/audit_finalframe_unread_test.go' = 'finalframe_unread_test.go'
    'internal/connector/app/audit_runcontrol_unread_test.go' = 'runcontrol_unread_test.go'
}
$auditReplacements = @{}
$auditHashes = @{}
foreach ($auditTarget in $auditTests.Keys) {
    $auditFixture = Join-Path $auditRoot $auditTests[$auditTarget]
    if (-not (Test-Path -LiteralPath $auditFixture -PathType Leaf)) { throw 'Missing external fixture.' }
    $auditReplacements[(Join-Path $auditRepo $auditTarget)] = $auditFixture
    $auditHashes[$auditTests[$auditTarget]] = (Get-FileHash -LiteralPath $auditFixture -Algorithm SHA256).Hash.ToLowerInvariant()
}
if ($Mode -ne 'Current') {
    $auditSourceName = if ($Mode -eq 'Before') { 'session_original.go' } else { 'session_candidate.go' }
    $auditSource = Join-Path $auditRoot $auditSourceName
    if (-not (Test-Path -LiteralPath $auditSource -PathType Leaf)) { throw 'Missing proposed/original source copy.' }
    $auditReplacements[(Join-Path $auditRepo 'internal/connector/terminal/session.go')] = $auditSource
    $auditHashes[$auditSourceName] = (Get-FileHash -LiteralPath $auditSource -Algorithm SHA256).Hash.ToLowerInvariant()
}
$auditOverlay = Join-Path $auditOutput 'overlay.json'
[IO.File]::WriteAllText($auditOverlay, (@{Replace=$auditReplacements} | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))
$auditPattern = '^TestIndependentAudit(UnreadDataPreventsTerminalShutdown|UnreadOldConnectionOwnership|UnreadConnectionRecoveryPreservesPTY|FinalFrameWriteDeadline|RunControlUnreadDataShutdown)$'
$auditArguments = @('test','-race','-json',('-count=' + $Count),'-timeout=90s','-overlay',$auditOverlay,'-run',$auditPattern,'./internal/connector/terminal','./internal/connector/app')
$auditMetadata = @{
    mode=$Mode; cloudExecuted=$false; externalOverlay=$true; repositoryEditsByThisScript=$false
    fixtureSha256=$auditHashes; arguments=$auditArguments; startedUtc=[DateTime]::UtcNow.ToString('o')
}
$auditPriorLocation = Get-Location
try {
    Set-Location -LiteralPath $auditRepo
    $auditMetadata.head = (& git rev-parse HEAD).Trim()
    $auditMetadata.sessionSourceSha256 = (Get-FileHash -LiteralPath (Join-Path $auditRepo 'internal/connector/terminal/session.go') -Algorithm SHA256).Hash.ToLowerInvariant()
    $auditMetadata.statusBefore = @(& git status --short)
    & go @auditArguments 1> (Join-Path $auditOutput 'raw.jsonl') 2> (Join-Path $auditOutput 'stderr.txt')
    $auditExit = $LASTEXITCODE
    $auditMetadata.exitCode = $auditExit
    $auditMetadata.statusAfter = @(& git status --short)
    $auditMetadata.finishedUtc = [DateTime]::UtcNow.ToString('o')
    [IO.File]::WriteAllText((Join-Path $auditOutput 'result.json'), ($auditMetadata | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
} finally {
    Set-Location -LiteralPath $auditPriorLocation.Path
}
Write-Output ('External backpressure audit ' + $Mode + ' exit=' + $auditExit + '; cloud=false')
exit $auditExit
