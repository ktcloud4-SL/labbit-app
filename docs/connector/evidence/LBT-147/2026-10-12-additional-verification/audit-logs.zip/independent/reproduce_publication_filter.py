from pathlib import Path
import hashlib, json, shutil, subprocess

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / 'labbit-vm-access-147'
PREFIX = 'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
PACKAGE = REPO / PREFIX
CLONE = OUT / 'publication-filter-red-clone'
subprocess.run(['git', 'clone', '--quiet', '--shared', '--local', '--no-checkout', str(REPO), str(CLONE)], check=True, capture_output=True)
target = CLONE / PREFIX
target.parent.mkdir(parents=True)
shutil.copytree(PACKAGE, target)
subprocess.run(['git', 'add', '--', PREFIX], cwd=CLONE, check=True, capture_output=True)
checksums = json.loads((target / 'artifact-checksums.json').read_text(encoding='utf-8'))['files']
differences = []
for x in checksums:
    committed = subprocess.check_output(['git', 'show', ':' + PREFIX + '/' + x['path']], cwd=CLONE)
    digest = hashlib.sha256(committed).hexdigest()
    if digest != x['sha256']:
        differences.append({'path': x['path'], 'expectedSHA256': x['sha256'], 'stagedBlobSHA256': digest,
                            'bytesBefore': x['bytes'], 'bytesAfter': len(committed)})
source = json.loads((target / 'source-manifest.json').read_text(encoding='utf-8'))
fixture_mismatches = []
for name, expected in source['fixtureSHA256'].items():
    committed = subprocess.check_output(['git', 'show', ':' + PREFIX + '/_fixtures/' + name], cwd=CLONE)
    actual = hashlib.sha256(committed).hexdigest()
    if actual != expected: fixture_mismatches.append({'path': name, 'expectedSHA256': expected, 'stagedBlobSHA256': actual})
result = {'finding': 'PUB-FILTER/P2', 'result': 'CONFIRMED', 'cloudCalls': 0, 'originalRepositoryModified': False,
          'artifactHashFailuresAfterStaging': differences, 'fixtureHashFailuresAfterStaging': fixture_mismatches}
assert len(differences) >= 2 and len(fixture_mismatches) == 2
(OUT / 'publication-filter-red.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'finding': result['finding'], 'artifactFailures': len(differences), 'fixtureFailures': [x['path'] for x in fixture_mismatches]}))
