from pathlib import Path
import hashlib, json, shutil, subprocess, sys

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / 'labbit-vm-access-147'
PREFIX = 'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
PACKAGE = REPO / PREFIX
CLONE = OUT / 'publication-filter-green-clone'
CHECKOUT = OUT / 'publication-filter-green-checkout'
PREPARED = OUT / 'publication-filter-green-prepared'
subprocess.run(['git', 'clone', '--quiet', '--shared', '--local', '--no-checkout', str(REPO), str(CLONE)], check=True, capture_output=True)
target = CLONE / PREFIX
target.parent.mkdir(parents=True)
shutil.copytree(PACKAGE, target)
inputs = {str(p.relative_to(target)).replace('\\', '/'): p.read_bytes() for p in target.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
assert inputs['.gitattributes'].strip() == b'* -text'
subprocess.run(['git', 'add', '--', PREFIX], cwd=CLONE, check=True, capture_output=True)
CHECKOUT.mkdir()
subprocess.run(['git', 'checkout-index', '--all', '--prefix=' + str(CHECKOUT).replace('\\', '/') + '/'], cwd=CLONE, check=True, capture_output=True)
checkout_package = CHECKOUT / PREFIX
checks = []
for name, before in inputs.items():
    staged = subprocess.check_output(['git', 'show', ':' + PREFIX + '/' + name], cwd=CLONE)
    checked = (checkout_package / name).read_bytes()
    assert before == staged == checked
    checks.append({'path': name, 'stagedExactBytes': True, 'checkoutExactBytes': True, 'sha256': hashlib.sha256(before).hexdigest()})
source = json.loads((checkout_package / 'source-manifest.json').read_text(encoding='utf-8'))
fixtures = {}
for name, expected in source['fixtureSHA256'].items():
    fixtures[name] = hashlib.sha256((checkout_package / '_fixtures' / name).read_bytes()).hexdigest() == expected
assert len(fixtures) == 4 and all(fixtures.values())
command = [sys.executable, str(checkout_package / 'prepare_overlays.py'), '--repo', str(REPO), '--output', str(PREPARED), '--verify-source']
run = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
assert run.returncode == 0
result = {'finding': 'PUB-FILTER/P2', 'result': 'PASS', 'originalRepositoryModified': False, 'cloudCalls': 0,
          'artifactCount': len(checks), 'stagedAndFreshCheckoutAllExactBytes': True, 'artifactChecks': checks,
          'fixtureChecks': fixtures, 'prepareFromFreshCheckout': {'command': command, 'exitCode': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr},
          'note': 'At preparation stage, current .gitattributes checksum may still await root package regeneration. This checks actual stage/checkout preservation; final exact checksums are verified separately.'}
(OUT / 'publication-filter-green.json').write_bytes((json.dumps(result, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
print(json.dumps({k:result[k] for k in ['finding','result','artifactCount','fixtureChecks','cloudCalls']}))
