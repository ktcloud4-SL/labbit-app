param(
    [Parameter(Mandatory=$true)][string]$Repo,
    [string]$Out = (Join-Path $PSScriptRoot 'ssh-reproduced'),
    [ValidateSet('Before','Current')][string]$Mode = 'Current',
    [ValidateRange(1,20)][int]$Count = 3
)
$ErrorActionPreference = 'Stop'
$auditRepo = (Resolve-Path -LiteralPath $Repo).Path
$auditOutput = [IO.Path]::GetFullPath($Out)
if ($auditOutput -eq $auditRepo -or $auditOutput.StartsWith($auditRepo + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Output must be outside repository.' }
[void][IO.Directory]::CreateDirectory($auditOutput)
$auditReplace = @{}
$auditHashes = @{}
foreach ($auditFixtureName in @('ssh_unread_lifecycle_test.go','ssh_manager_unread_test.go')) {
    $auditFixture = Join-Path $PSScriptRoot $auditFixtureName
    if (-not (Test-Path -LiteralPath $auditFixture -PathType Leaf)) { throw 'Missing external fixture dependency.' }
    $auditReplace[(Join-Path $auditRepo ('internal/connector/terminal/audit_' + $auditFixtureName))] = $auditFixture
    $auditHashes[$auditFixtureName] = (Get-FileHash -LiteralPath $auditFixture -Algorithm SHA256).Hash.ToLowerInvariant()
}
if ($Mode -eq 'Before') {
    foreach ($auditSourcePair in @(@('ssh_pty.go','ssh_pty_before_lifecycle.go'),@('session.go','session_candidate.go'))) {
        $auditSource = Join-Path $PSScriptRoot $auditSourcePair[1]
        if (-not (Test-Path -LiteralPath $auditSource -PathType Leaf)) { throw 'Missing pinned pre-fix source copy.' }
        $auditReplace[(Join-Path $auditRepo ('internal/connector/terminal/' + $auditSourcePair[0]))] = $auditSource
        $auditHashes[$auditSourcePair[1]] = (Get-FileHash -LiteralPath $auditSource -Algorithm SHA256).Hash.ToLowerInvariant()
    }
}
$auditOverlay = Join-Path $auditOutput 'overlay.json'
[IO.File]::WriteAllText($auditOverlay,(@{Replace=$auditReplace}|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
$auditPattern = '^TestIndependentAudit(UnreadSSHClose|UnreadSSHResizeShutdown|ActualManagerUnreadSSHShutdown)$'
$auditArgs = @('test','-race','-json',('-count=' + $Count),'-timeout=60s','-overlay',$auditOverlay,'-run',$auditPattern,'./internal/connector/terminal')
$auditRecord = @{mode=$Mode;cloudExecuted=$false;repositoryEditsByThisScript=$false;fixtureSha256=$auditHashes;arguments=$auditArgs;startedUtc=[DateTime]::UtcNow.ToString('o')}
$auditLocation = Get-Location
try {
    Set-Location -LiteralPath $auditRepo
    $auditRecord.head = (& git rev-parse HEAD).Trim()
    $auditRecord.statusBefore = @(& git status --short)
    $auditRecord.sourceSha256 = @{}
    foreach($auditRelativePath in @('internal/connector/terminal/session.go','internal/connector/terminal/ssh_pty.go','internal/connector/vmaccess/access.go','go.mod','go.sum')) {
        $auditRecord.sourceSha256[$auditRelativePath] = (Get-FileHash -LiteralPath (Join-Path $auditRepo $auditRelativePath) -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    & go @auditArgs 1> (Join-Path $auditOutput 'raw.jsonl') 2> (Join-Path $auditOutput 'stderr.txt')
    $auditExit = $LASTEXITCODE
    $auditRecord.exitCode = $auditExit
    $auditRecord.statusAfter = @(& git status --short)
    $auditRecord.finishedUtc = [DateTime]::UtcNow.ToString('o')
    [IO.File]::WriteAllText((Join-Path $auditOutput 'result.json'),($auditRecord|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
} finally {Set-Location -LiteralPath $auditLocation.Path}
Write-Output ('External SSH backpressure audit ' + $Mode + ' exit=' + $auditExit + '; cloud=false')
exit $auditExit
