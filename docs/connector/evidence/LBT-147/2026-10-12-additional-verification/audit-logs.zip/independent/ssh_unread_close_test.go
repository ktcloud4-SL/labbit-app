package terminal

import (
 "context"
 "crypto/ed25519"
 "crypto/rand"
 "net"
 "sync"
 "sync/atomic"
 "testing"
 "time"
 "golang.org/x/crypto/ssh"
)

// Genuine TCP and SSH; only the synthetic peer stops reading after PTY setup.
// Observation is metadata only. No payload, private key or raw SSH error logs.
type auditSSHReadGate struct { net.Conn; pause atomic.Bool; resume chan struct{} }
func (c *auditSSHReadGate) Read(p []byte) (int,error) { if c.pause.Load() { <-c.resume }; return c.Conn.Read(p) }

func TestIndependentAuditManagedPTYCloseWithUnreadSSHTransport(t *testing.T) {
 _, key, err := ed25519.GenerateKey(rand.Reader); if err != nil { t.Fatal("key fixture") }
 signer, err := ssh.NewSignerFromKey(key); if err != nil { t.Fatal("signer fixture") }
 listener, err := net.Listen("tcp", "127.0.0.1:0"); if err != nil { t.Fatal("listener fixture") }; defer listener.Close()
 paused := make(chan struct{}); accepted := make(chan net.Conn,1); resume := make(chan struct{}); var resumeOnce sync.Once
 defer resumeOnce.Do(func(){close(resume)})
 go func(){
  raw, err := listener.Accept(); if err != nil { return }; accepted <- raw; defer raw.Close()
  _ = raw.(*net.TCPConn).SetReadBuffer(1024)
  gated := &auditSSHReadGate{Conn:raw, resume:resume}
  cfg := &ssh.ServerConfig{NoClientAuth:true}; cfg.AddHostKey(signer)
  sc, incoming, requests, err := ssh.NewServerConn(gated,cfg); if err != nil { return }; defer sc.Close(); go ssh.DiscardRequests(requests)
  ch, reqs, err := (<-incoming).Accept(); if err != nil { return }; defer ch.Close()
  for req := range reqs { if req.WantReply { _ = req.Reply(true,nil) }; if req.Type=="shell" { gated.pause.Store(true); close(paused); <-resume; return } }
 }()
 raw, err := (&net.Dialer{}).DialContext(context.Background(),"tcp",listener.Addr().String()); if err != nil { t.Fatal("dial fixture") }
 defer raw.Close(); _ = raw.(*net.TCPConn).SetWriteBuffer(1024)
 cc, chs, reqs, err := ssh.NewClientConn(raw,listener.Addr().String(),&ssh.ClientConfig{User:"fixture",HostKeyCallback:ssh.FixedHostKey(signer.PublicKey())}); if err != nil { t.Fatal("handshake fixture") }
 client := ssh.NewClient(cc,chs,reqs)
 // The managed factory passes nil client and a reservation-only close callback.
 ss, err := client.NewSession(); if err != nil { t.Fatal("channel fixture") }
 pty, err := newSSHSessionPTY(ss,nil,func()error{return nil},80,24); if err != nil { t.Fatal("pty fixture") }
 <-paused
 wrote := make(chan struct{}); go func(){defer close(wrote); _,_ = pty.Write(make([]byte,16<<20))}()
 time.Sleep(300*time.Millisecond)
 select { case <-wrote: t.Fatal("SSH write did not remain blocked"); default: }
 closed := make(chan struct{}); go func(){_ = pty.Close(); close(closed)}()
 select {
 case <-closed: t.Log("unreadSSH=true PTYCloseReturned=true")
 case <-time.After(750*time.Millisecond):
  t.Error("managed PTY close stayed blocked on unread SSH transport; shared manager Close cannot be reached")
  _ = raw.Close()
 }
 resumeOnce.Do(func(){close(resume)})
 select { case <-closed: case <-time.After(time.Second): t.Error("fixture PTY close did not recover after socket close") }
 select { case serverRaw := <-accepted: _ = serverRaw.Close(); default: }
 _ = client.Close()
}
