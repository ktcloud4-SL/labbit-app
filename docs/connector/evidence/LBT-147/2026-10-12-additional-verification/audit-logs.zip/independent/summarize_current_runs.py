from pathlib import Path
import json,hashlib,datetime
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent/'labbit-vm-access-147';RUN=ROOT.parent/'LBT-147-additional-verification-20261012'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def counts(p):
 actions={'pass':0,'fail':0,'skip':0};skips=[];metadata=[]
 for line in p.read_text(encoding='utf-8-sig').splitlines():
  try:e=json.loads(line)
  except ValueError:continue
  if e.get('Test') and e.get('Action')in actions:
   actions[e['Action']]+=1
   if e['Action']=='skip':skips.append(e['Test'])
  out=e.get('Output','')
  if any(x in out for x in ['cleanup verify GET/404','Baseline counts:','Matching-prefix residuals:','managementSG','keyPair','actualVM=true']):metadata.append(out.strip())
 return {'testActions':actions,'skipTests':skips,'metadata':metadata}
runs={}
for name in ['go-unit','go-race','regression-repeat','go-vet','go-build','gofmt','web-install','web-typecheck','web-lint','web-test','web-build','contracts','reset-schema']:
 meta=RUN/'final-checks'/f'{name}-run.json';log=RUN/'final-checks'/f'{name}.log'
 if meta.exists():runs[name]={'run':read(meta),'rawSha256':hashlib.sha256(log.read_bytes()).hexdigest() if log.exists()else None,'observations':counts(log) if name.startswith('go-')and name in ('go-unit','go-race')or name=='regression-repeat'else None}
pinChecks=[]
for name in ['failure-tested-source.json','final-checks/tested-source.json']:
 snap=read(RUN/name);mismatches=[];tested=0;allGoMismatches=[];allGoTested=0
 for item in snap['files']:
  path=item['path'];expected=item.get('sha256',item.get('sha256Bytes'))
  if path.endswith('.go') and not path.startswith('docs/'):
   allGoTested+=1
   if expected!=hashlib.sha256((REPO/path).read_bytes()).hexdigest():allGoMismatches.append(path)
  if (path.endswith('.go') and not path.endswith('_test.go') and not path.startswith('docs/'))or path in ('go.mod','go.sum','runtime/contract.yaml','runtime/README.md'):
   tested+=1;current=hashlib.sha256((REPO/path).read_bytes()).hexdigest()
   if expected!=current:mismatches.append(path)
 pinChecks.append({'snapshot':name,'head':snap['head'],'productionDependencyContractFilesCompared':tested,'mismatches':mismatches,'allGoFilesCompared':allGoTested,'allGoMismatches':allGoMismatches})
cloud={'runs':read(RUN/'real-failure-results.json'),'raw':counts(RUN/'real-failures.jsonl'),'child':counts(RUN/'actual-runtime.jsonl'),'finalInventory':counts(RUN/'failure-final-inventory.jsonl') if (RUN/'failure-final-inventory.jsonl').exists()else None,'finalSource':read(RUN/'failure-final-source-state.json')}
result={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':runs,'sourcePinComparisons':pinChecks,'actualLatest':cloud,'independentPortableSSH':read(ROOT/'portable-ssh-current/result.json')}
(ROOT/'independent-run-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'runExitCodes':{k:v['run']['exitCode']for k,v in runs.items()},'counts':{k:v['observations']['testActions']for k,v in runs.items()if v['observations']},'sourcePins':pinChecks,'cloudCounts':cloud['raw']['testActions'],'childCounts':cloud['child']['testActions']},ensure_ascii=False,indent=2))
