from pathlib import Path
import atexit
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

out = Path(__file__).resolve().parent/'publication-harness-repeat'
out.mkdir(exist_ok=True)
repo = out.parent.parent/'labbit-vm-access-147'
package = repo/'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
scratch = Path(tempfile.mkdtemp(prefix='package-validation-', dir=out))
atexit.register(shutil.rmtree, scratch, ignore_errors=True)
prepared = scratch/'prepared-reproduction'
script = package/'prepare_overlays.py'
records = []
def run(label, arguments, expected):
    result = subprocess.run([sys.executable, str(script), *arguments], cwd=repo, capture_output=True)
    records.append({'case': label, 'exitCode': result.returncode, 'expected': expected, 'stdout': result.stdout.decode('utf-8', errors='replace'), 'stderr': result.stderr.decode('utf-8', errors='replace')})
    assert (result.returncode == 0) == expected, label
run('matching-pins-and-external-output', ['--repo', str(repo), '--output', str(prepared), '--verify-source'], True)
run('nonempty-output-rejected', ['--repo', str(repo), '--output', str(prepared)], False)
run('repository-output-rejected', ['--repo', str(repo), '--output', str(repo/'should-not-be-created')], False)

# Independent checkout fixture tests the pinned-source rejection with no cloud.
isolated = scratch/'pinned-source-guard-fixture'; isolated.mkdir()
subprocess.run(['git', 'init', '-q', str(isolated)], check=True)
manifest = json.loads((package/'source-manifest.json').read_text(encoding='utf-8'))
for item in manifest['productFiles']:
    target = isolated/item['path']; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes((repo/item['path']).read_bytes())
changed = isolated/'internal/connector/terminal/ssh_pty.go'
changed.write_bytes(changed.read_bytes()+b'\n// guard fixture mutation\n')
rejected_output = scratch/'rejected-source-output'
run('source-mutation-rejected', ['--repo', str(isolated), '--output', str(rejected_output), '--verify-source'], False)
assert not rejected_output.exists()
assert not (repo/'should-not-be-created').exists()
env = dict(os.environ)
for name in list(env):
    if name.startswith('LABBIT_OPENSTACK_') and (name.endswith('_TEST') or name.endswith('_AUDIT') or name.endswith('_INTEGRATION')): env[name] = '0'
env['LABBIT_OPENSTACK_RESIDUAL_AUDIT'] = '0'
env['LABBIT_LBT147_ADDITIONAL_REAL_TEST'] = '0'
command = ['go', 'test', '-race', '-json', '-overlay', str(prepared/'real-failure-overlay.json'), '-count=1', '-run', '^TestLBT147ReadOnlyResiduals$', './internal/connector/provider/openstack']
with (out/'prepared-fixture-compile.jsonl').open('wb') as stdout, (out/'prepared-fixture-compile.stderr.txt').open('wb') as stderr:
    result = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr)
assert result.returncode == 0
rows = [json.loads(line) for line in (out/'prepared-fixture-compile.jsonl').read_text(encoding='utf-8').splitlines() if line.startswith('{')]
assert sum(x.get('Action') == 'skip' and bool(x.get('Test')) for x in rows) == 1
data = {'prepareHelperSHA256': hashlib.sha256(script.read_bytes()).hexdigest(), 'cases': records, 'prepareCallsGoTestOrCloud': 0,
    'overlayCompile': {'command': command, 'exitCode': result.returncode, 'optInSkipped': 1, 'cloudMutations': 0},
    'scope': 'Pinned-file identity and fixture preparation; does not claim an exhaustive ignored/untracked source guard.'}
(out/'reproduction-checks.json').write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print('Source/fixture/output preparation checks PASS; explicit overlay compile PASS, cloud0')
