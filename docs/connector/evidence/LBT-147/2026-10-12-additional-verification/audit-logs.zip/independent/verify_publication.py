from pathlib import Path
import datetime, hashlib, json, os, re, shutil, subprocess, sys, zipfile

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / 'labbit-vm-access-147'
P = REPO / 'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
WORK = OUT / 'publication-verification'
WORK.mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def git(*args): return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()
def counts(b):
    events = []
    for line in b.decode('utf-8-sig').splitlines():
        try: events.append(json.loads(line))
        except ValueError: pass
    result = {a: sum(bool(e.get('Test')) and e.get('Action') == a for e in events) for a in ('pass', 'fail', 'skip')}
    result['skippedTests'] = sorted(e['Test'] for e in events if e.get('Test') and e.get('Action') == 'skip')
    return result

all_files = {str(p.relative_to(P)).replace('\\', '/'): p.read_bytes() for p in P.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
assert len(all_files) == 20
artifact = read(P / 'artifact-checksums.json')['files']
assert len(artifact) == 19 and {x['path'] for x in artifact} == set(all_files) - {'artifact-checksums.json'}
assert all(len(all_files[x['path']]) == x['bytes'] and sha(all_files[x['path']]) == x['sha256'] for x in artifact)
source = read(P / 'source-manifest.json')
head, main = git('rev-parse', 'HEAD'), git('rev-parse', 'origin/main')
assert head == source['codeCommit'] and main == source['main']
source_checks = []
for x in source['productFiles']:
    data = (REPO / x['path']).read_bytes()
    working_blob = git('hash-object', '--path', x['path'], str(REPO / x['path']))
    committed_blob = git('rev-parse', head + ':' + x['path'])
    raw_commit = subprocess.check_output(['git', 'show', head + ':' + x['path']], cwd=REPO)
    source_checks.append({'path': x['path'], 'byteSHA256Match': sha(data) == x['byteSHA256'],
                          'workingCleanBlobMatch': working_blob == x['gitBlob'], 'committedBlobMatch': committed_blob == x['gitBlob'],
                          'exactCommittedBytes': data == raw_commit})
assert len(source_checks) == 39 and all(x['byteSHA256Match'] and x['workingCleanBlobMatch'] and x['committedBlobMatch'] for x in source_checks)
fixture_checks = {name: sha(all_files['_fixtures/' + name]) == expected for name, expected in source['fixtureSHA256'].items()}
assert all(fixture_checks.values())

archive = zipfile.ZipFile(P / 'audit-logs.zip')
info = archive.infolist()
assert len(info) == 355 and len({x.filename for x in info}) == len(info)
assert archive.testzip() is None
entries = read(P / 'archive-manifest.json')['entries']
assert {x.filename for x in info} == {x['path'] for x in entries}
entry_checks = []
for x in entries:
    z = archive.getinfo(x['path']); data = archive.read(z)
    ok = len(data) == x['bytes'] and sha(data) == x['sha256'] and f'{z.CRC:08x}' == x['crc32']
    assert ok
    entry_checks.append({'path': x['path'], 'match': ok})
for name in fixture_checks:
    assert archive.read('root/' + name) == all_files['_fixtures/' + name]
assert archive.read('independent/independent-review.md') == all_files['independent-review.md'] == (OUT / 'independent-review.md').read_bytes()

summary = read(P / 'validation-summary.json')
raw_results = {}
for key, file in [('go', 'go-unit.log'), ('relatedRace', 'go-race.log'), ('regression20', 'regression-repeat.log')]:
    raw = counts(archive.read('root/final-checks/' + file))
    assert raw == summary[key]
    raw_results[key] = raw
cloud_checks = []
for group, runs in [('cloud4', summary['cloud4']['runs']), ('actual2VM', summary['actual2VM']), ('latestActualVM', summary['latestActualVM'])]:
    for run in runs:
        raw = counts(archive.read('root/' + run['label'] + '.jsonl'))
        assert {k: raw[k] for k in ('pass', 'fail', 'skip')} == run['counts']
        assert run['exitCode'] == 0
        cloud_checks.append({'group': group, 'label': run['label'], 'counts': raw})
assert counts(archive.read('root/actual-runtime.jsonl')) == summary['actualRunControlChild']
assert source['cloud4Source'] == summary['cloud4']['head'] == 'da6b6701f13ba17c38b0778983545da62ac07212'
assert source['latestActualVMSource']['head'] == head
pin_checks = []
for label, snapshot in [('finalGoSource', source['finalGoSource']), ('actual2VMSource', source['actual2VMSource']), ('latestActualVMSource', source['latestActualVMSource'])]:
    mismatches = []
    for x in snapshot['files']:
        if x['path'].startswith('docs/'): continue
        if sha((REPO / x['path']).read_bytes()) != x.get('sha256', x.get('byteSHA256')): mismatches.append(x['path'])
    assert mismatches == ([] if label != 'actual2VMSource' else ['internal/connector/terminal/ssh_backpressure_test.go'])
    pin_checks.append({'snapshot': label, 'head': snapshot['head'], 'nonEvidenceByteDifferences': mismatches})
initial_logs = {}
for name in ['root/initial-real-fixture-failure/real-failures.jsonl', 'root/final-checks/initial-before-tracing-test-fix/go-unit.log', 'independent/unread-shutdown-before.jsonl', 'independent/ssh-unread-lifecycle-before.jsonl', 'independent/ssh-unread-lifecycle-candidate.jsonl', 'independent/portable-ssh-before/raw.jsonl']:
    result = counts(archive.read(name)); assert result['fail'] > 0
    initial_logs[name] = result
required = git('diff', '--name-only', main + '...HEAD').splitlines()
review = all_files['file-review.md'].decode('utf-8')
assert all('| ' + path + ' |' in review for path in required)
assert all('| docs/connector/evidence/LBT-147/2026-10-12-additional-verification/' + path + ' |' in review for path in all_files)

# Scan private values only in memory; report only filenames/kinds, never values.
config = Path('C:/Users/user/.config/openstack/clouds.yaml').read_bytes()
known = []
for line in config.splitlines():
    match = re.match(rb'\s*(?:password|token|client_secret|secret)\s*:\s*(.+?)\s*$', line, re.I)
    if match:
        value = match.group(1).strip(b'\"\'')
        if len(value) >= 8: known.append(value)
private = Path('C:/Users/user/.ssh/dandelion.pem').read_bytes()
known += [private, b'\n'.join(line for line in private.splitlines() if not line.startswith(b'-----'))]
payloads = [(k, v) for k, v in all_files.items() if not k.endswith('.zip')]
payloads += [(z.filename, archive.read(z)) for z in info]
hits = []
for name, data in payloads:
    if any(value and value in data for value in known): hits.append({'file': name, 'kind': 'known-secret'})
    if re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC |)PRIVATE KEY-----\r?\n[A-Za-z0-9+/]{30}', data): hits.append({'file': name, 'kind': 'private-key-pattern'})
    if re.search(rb'(?i)authorization[\"\s:]+bearer\s+[A-Za-z0-9_.-]{24,}', data): hits.append({'file': name, 'kind': 'bearer-pattern'})
assert hits == []

# Independent functional preparation only; no test or cloud requests.
helper = P / 'prepare_overlays.py'
helper_results = []
def prepare(label, output, expected, repo=REPO, script=helper):
    command = [sys.executable, str(script), '--repo', str(repo), '--output', str(output), '--verify-source']
    run = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
    helper_results.append({'case': label, 'command': command, 'exitCode': run.returncode,
                           'stdout': run.stdout, 'stderr': run.stderr, 'expectedAccept': expected})
    assert (run.returncode == 0) == expected
prepare('valid-current-source-and-empty-external-output', WORK / 'prepared', True)
prepare('nonempty-output-rejected', WORK / 'prepared', False)
prepare('repo-output-rejected-without-creating-it', REPO / 'independent-prohibited-output', False)
clone = WORK / 'source-clone'
subprocess.run(['git', 'clone', '--quiet', '--shared', '--no-checkout', '--local', str(REPO), str(clone)], check=True, capture_output=True)
subprocess.run(['git', 'config', 'core.autocrlf', 'true'], cwd=clone, check=True)
subprocess.run(['git', 'checkout', head, '--'] + [x['path'] for x in source['productFiles']], cwd=clone, check=True, capture_output=True)
prepare('isolated-source-clone-valid', WORK / 'clone-prepared', True, clone)
changed = clone / 'internal/connector/terminal/ssh_pty.go'
changed.write_bytes(changed.read_bytes() + b'\n// external guard-only mutation\n')
prepare('changed-pinned-source-rejected', WORK / 'changed-source-output', False, clone)
missing = clone / 'internal/connector/terminal/session.go'
missing.rename(missing.with_suffix('.guard-missing'))
prepare('missing-pinned-source-rejected', WORK / 'missing-source-output', False, clone)
corrupt_package = WORK / 'corrupt-fixture-package'
corrupt_package.mkdir()
shutil.copy2(helper, corrupt_package / helper.name)
shutil.copy2(P / 'source-manifest.json', corrupt_package / 'source-manifest.json')
shutil.copytree(P / '_fixtures', corrupt_package / '_fixtures')
corrupt = corrupt_package / '_fixtures/real_failure_test.go'
corrupt.write_bytes(corrupt.read_bytes() + b'\n// guard-only corruption\n')
prepare('corrupt-fixture-rejected-before-output', WORK / 'corrupt-output', False, script=corrupt_package / helper.name)
prepared = WORK / 'prepared'
overlay = {}
for name in ['real-failure-overlay.json', 'actual-runtime-overlay.json']:
    data = read(prepared / name); overlay.update(data['Replace'])
    assert not (prepared / name).read_bytes().startswith(b'\xef\xbb\xbf')
    assert all(Path(v).is_file() for v in data['Replace'].values())
(WORK / 'compile-overlay.json').write_text(json.dumps({'Replace': overlay}), encoding='utf-8')
env = dict(os.environ)
for name in list(env):
    if name.startswith('LABBIT_OPENSTACK_') and (name.endswith('_TEST') or name.endswith('_AUDIT') or name.endswith('_INTEGRATION')): env[name] = '0'
env['LABBIT_LBT147_ADDITIONAL_REAL_TEST'] = '0'
env.pop('LABBIT_ADDITIONAL_RUNTIME_METADATA_FILE', None)
command = ['go', 'test', '-race', '-json', '-run', '^$', '-overlay', str(WORK / 'compile-overlay.json'), './internal/connector/provider/openstack', './internal/connector/app']
with (WORK / 'compile.jsonl').open('wb') as stdout, (WORK / 'compile.stderr.txt').open('wb') as stderr:
    compiled = subprocess.run(command, cwd=REPO, env=env, stdout=stdout, stderr=stderr)
assert compiled.returncode == 0 and counts((WORK / 'compile.jsonl').read_bytes())['fail'] == 0
assert all(all_files[k] == (P / k).read_bytes() for k in all_files)
result = {'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'result': 'PASS',
          'codeCommit': head, 'main': main, 'filesRead': sorted(all_files),
          'artifactFiles': len(all_files), 'artifactTargets': len(artifact), 'artifactSHA256': {k: sha(v) for k, v in all_files.items()},
          'sourceChecks': source_checks, 'fixtureChecks': fixture_checks, 'sourceExecutionComparisons': pin_checks,
          'archiveEntries': len(info), 'archiveChecks': entry_checks, 'countsFromRaw': raw_results,
          'cloudCountsFromRaw': cloud_checks, 'initialFailuresFromRaw': initial_logs,
          'secretScan': {'itemsChecked': len(payloads), 'knownValuesChecked': len(known), 'matches': hits,
                         'scope': 'Known local values plus actual key/PEM/Bearer; unknown secrets/all history excluded'},
          'helperSHA256': sha(helper.read_bytes()), 'independentHelperCases': helper_results,
          'independentCompile': {'command': command, 'exitCode': compiled.returncode, 'rawSHA256': sha((WORK / 'compile.jsonl').read_bytes()), 'testsSelected': 0, 'cloudCalls': 0},
          'repositoryOrEvidenceMutationsByReviewer': False, 'packageBytesUnchangedDuringReview': True}
(OUT / 'publication-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: result[k] for k in ['result', 'codeCommit', 'artifactFiles', 'artifactTargets', 'archiveEntries', 'secretScan']}, ensure_ascii=False))
