from pathlib import Path
import datetime, hashlib, json, re, subprocess, zipfile

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / 'labbit-vm-access-147'
P = REPO / 'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
PREFIX = P.relative_to(REPO).as_posix()
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def git(*args): return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()
def counts(data):
    events = []
    for line in data.decode('utf-8-sig').splitlines():
        try: events.append(json.loads(line))
        except ValueError: pass
    return {**{a:sum(bool(e.get('Test')) and e.get('Action') == a for e in events) for a in ('pass','fail','skip')},
            'skippedTests': sorted(e['Test'] for e in events if e.get('Test') and e.get('Action') == 'skip')}
files = {x.relative_to(P).as_posix():x.read_bytes() for x in P.rglob('*') if x.is_file() and '__pycache__' not in x.parts and x.suffix != '.pyc'}
assert len(files) == 20 and files['.gitattributes'].strip() == b'* -text'
checksums = read(P/'artifact-checksums.json')['files']
assert len(checksums) == 19 and {x['path'] for x in checksums} == set(files)-{'artifact-checksums.json'}
assert all(sha(files[x['path']]) == x['sha256'] and len(files[x['path']]) == x['bytes'] for x in checksums)
publication_blob_checks = []
for path, data in files.items():
    raw_blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    clean_blob = git('hash-object','--path',PREFIX+'/'+path,str(P/path))
    assert raw_blob == clean_blob
    publication_blob_checks.append({'path':path,'rawSHA256':sha(data),'rawAndGitCleanBlob':clean_blob,'bytesPreservedByGitFilter':True})
source = read(P/'source-manifest.json')
assert source['codeCommit'] == git('rev-parse','HEAD') and source['main'] == git('rev-parse','origin/main')
source_checks=[]
for x in source['productFiles']:
    data=(REPO/x['path']).read_bytes()
    committed=subprocess.check_output(['git','show',source['codeCommit']+':'+x['path']],cwd=REPO)
    assert sha(data)==x['byteSHA256']
    assert git('hash-object','--path',x['path'],str(REPO/x['path'])) == git('rev-parse',source['codeCommit']+':'+x['path']) == x['gitBlob']
    assert data.replace(b'\r\n',b'\n') == committed.replace(b'\r\n',b'\n')
    source_checks.append({'path':x['path'],'rawSHA256':sha(data),'committedBlob':x['gitBlob'],'exactBytes':data==committed})
assert len(source_checks)==39 and sum(x['exactBytes'] for x in source_checks)==32
assert {x['path'] for x in source_checks if not x['exactBytes']} == {'contracts/http/openapi.yaml','go.mod','go.sum','runtime/README.md','runtime/contract.yaml','web/package-lock.json','web/package.json'}
fixture_checks={name:sha(files['_fixtures/'+name])==value for name,value in source['fixtureSHA256'].items()}
assert len(fixture_checks)==4 and all(fixture_checks.values())
z=zipfile.ZipFile(P/'audit-logs.zip'); infos=z.infolist(); entries=read(P/'archive-manifest.json')['entries']
assert len(infos)==len({x.filename for x in infos}) and z.testzip() is None
assert {x.filename for x in infos}=={x['path'] for x in entries}
for x in entries:
    data=z.read(x['path']); info=z.getinfo(x['path'])
    assert sha(data)==x['sha256'] and len(data)==x['bytes'] and f'{info.CRC:08x}'==x['crc32']
assert len(infos)==read(P/'publication-checks.json')['archive']['entries']
assert files['independent-review.md']==(OUT/'independent-review.md').read_bytes()==z.read('independent/independent-review.md')
for name in fixture_checks: assert files['_fixtures/'+name]==z.read('root/'+name)
summary=read(P/'validation-summary.json'); raw_counts={}
for name,file in [('go','go-unit.log'),('relatedRace','go-race.log'),('regression20','regression-repeat.log')]:
    actual=counts(z.read('root/final-checks/'+file)); assert actual==summary[name]; raw_counts[name]=actual
cloud=[]
for group,runs in [('cloud4',summary['cloud4']['runs']),('actual2VM',summary['actual2VM']),('latestActualVM',summary['latestActualVM'])]:
    for run in runs:
        actual=counts(z.read('root/'+run['label']+'.jsonl'))
        assert {k:actual[k] for k in ['pass','fail','skip']}==run['counts'] and run['exitCode']==0
        cloud.append({'group':group,'label':run['label'],'counts':actual})
assert counts(z.read('root/actual-runtime.jsonl'))==summary['actualRunControlChild']
ssot=read(P/'ssot-summary.json'); raw_ssot=json.loads(z.read('root/latest-ssot.json'))
assert sha(json.dumps(raw_ssot['LBT-147']['fields']['description'],ensure_ascii=False,sort_keys=True).encode()) == ssot['jira']['descriptionSHA256']
for page in ssot['confluence']:
    raw=raw_ssot[page['pageId']]
    assert sha(raw['body'].encode())==page['bodySHA256'] and raw['version']['number']==page['version']
secret_values=[]
for line in Path('C:/Users/user/.config/openstack/clouds.yaml').read_bytes().splitlines():
    m=re.match(rb'\s*(?:password|token|client_secret|secret)\s*:\s*(.+?)\s*$',line,re.I)
    if m:
        value=m.group(1).strip(b'\"\'')
        if len(value)>=8:secret_values.append(value)
private=Path('C:/Users/user/.ssh/dandelion.pem').read_bytes()
secret_values += [private,b'\n'.join(line for line in private.splitlines() if not line.startswith(b'-----'))]
payloads=[(name,data) for name,data in files.items() if not name.endswith('.zip')]+[(x.filename,z.read(x)) for x in infos]
hits=[]
for name,data in payloads:
    if any(v and v in data for v in secret_values):hits.append({'file':name,'kind':'known-secret'})
    if re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC |)PRIVATE KEY-----\r?\n[A-Za-z0-9+/]{30}',data):hits.append({'file':name,'kind':'private-key-pattern'})
    if re.search(rb'(?i)authorization[\"\s:]+bearer\s+[A-Za-z0-9_.-]{24,}',data):hits.append({'file':name,'kind':'bearer-pattern'})
assert not hits
prior=read(OUT/'publication-verification.json')
assert prior['helperSHA256']==sha(files['prepare_overlays.py'])
assert read(P/'reproduction-checks.json')['prepareHelperSHA256']==prior['helperSHA256']
assert read(OUT/'publication-filter-green.json')['result']=='PASS'
required=git('diff','--name-only',source['main']+'...HEAD').splitlines()
file_review=files['file-review.md'].decode()
assert all('| '+path+' |' in file_review for path in required)
assert all('| '+PREFIX+'/'+path+' |' in file_review for path in files)
assert all(data==(P/name).read_bytes() for name,data in files.items())
result={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS','codeCommit':source['codeCommit'],'main':source['main'],
        'artifactFiles':len(files),'artifactTargets':len(checksums),'artifactChecks':publication_blob_checks,'sourceChecks':source_checks,
        'exactGoBytes':32,'contextEOLOnly':7,'fixtureChecks':fixture_checks,'archiveEntries':len(infos),'archiveExactCRCSizeSHA256':'PASS',
        'countsFromRaw':raw_counts,'cloudCountsFromRaw':cloud,'ssotBodyAndVersionSummaryMapping':'PASS',
        'secretScan':{'itemsChecked':len(payloads),'knownValuesChecked':len(secret_values),'matches':hits},
        'helper7CasesAndRaceCompileFromInitialReview':{'json':'publication-verification.json','helperSHA256':prior['helperSHA256'],'cloudCalls':0},
        'stageAndFreshCheckoutRegression':'publication-filter-green.json','acceptedPublicationFindings':['PUB-SOURCE-EOL/P3','PUB-FILTER/P2'],
        'packageUnchangedDuringFinalReview':True,'repositoryOrEvidenceMutationsByReviewer':False}
(OUT/'publication-final-verification.json').write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({k:result[k] for k in ['result','codeCommit','artifactFiles','artifactTargets','archiveEntries','secretScan']}))
