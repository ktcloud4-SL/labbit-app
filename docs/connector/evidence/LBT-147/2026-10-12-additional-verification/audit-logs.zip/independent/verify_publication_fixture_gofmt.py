from pathlib import Path
import hashlib, json, subprocess

out = Path(__file__).resolve().parent
root = out.parent/'LBT-147-additional-verification-20261012'
repo = out.parent/'labbit-vm-access-147'
package = repo/'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
sha = lambda b: hashlib.sha256(b).hexdigest()
raw = json.loads((root/'publication-format-red/remote-go-format-failure.json').read_text(encoding='utf-8-sig'))
checks = []
for name in ['integration_metadata_test.go', 'read_only_residual_test.go']:
    old = root/'publication-format-red'/name
    current = (package/'_fixtures'/name).read_bytes()
    canonical = (root/name).read_bytes()
    formatted = subprocess.check_output(['gofmt', str(old)])
    old_list = subprocess.check_output(['gofmt', '-l', str(old)])
    assert formatted == current == canonical
    assert old_list.strip() and b'\r\n' not in current
    checks.append({'file':name, 'originalSHA256':sha(old.read_bytes()), 'gofmtResultAndCurrentSHA256':sha(current),
                   'originalDetectedByGofmt':True, 'originalFormattedEqualsCurrentCanonicalAndPackage':True})
# Reproduce Makefile:25's file universe, including hidden/underscore fixture dirs.
files = [p for p in repo.rglob('*.go') if not p.relative_to(repo).as_posix().startswith('vendor/')]
unformatted = []
for start in range(0, len(files), 25):
    result = subprocess.run(['gofmt', '-l', *map(str, files[start:start+25])], capture_output=True, check=True)
    unformatted.extend(result.stdout.decode().splitlines())
assert not unformatted
summary = {'result':'PASS', 'fixtureChecks':checks, 'remoteGoFormatFailureRaw':raw,
           'makefileEquivalent':{'filesChecked':len(files), 'vendorExcluded':True,
                                 'hiddenAndUnderscoreDirectoriesIncluded':True, 'unformatted':unformatted},
           'cloudCalls':0, 'repositoryMutationsByReviewer':False}
(out/'publication-fixture-format-verification.json').write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'result':'PASS','fixtures':2,'makefileEquivalentGoFiles':len(files),'unformatted':0,'cloudCalls':0}))
