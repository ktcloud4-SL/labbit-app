from pathlib import Path
import hashlib, json

out = Path(__file__).resolve().parent
root = out.parent / 'LBT-147-additional-verification-20261012'
summary = json.loads((root / 'final-harness-repeat/summary.json').read_text(encoding='utf-8-sig'))
assert len(summary) == 2
checks = []
for index, record in enumerate(summary, 1):
    log = root / f'final-harness-repeat/run-{index}.log'
    data = log.read_bytes()
    assert record['run'] == index and record['exitCode'] == 0 and record['cloudCalls'] == 0
    assert b'Source/fixture/output preparation checks PASS; explicit overlay compile PASS, cloud0' in data
    checks.append({**record, 'logSHA256': hashlib.sha256(data).hexdigest()})
script = (root / 'validate_package.py').read_bytes()
assert b'tempfile.mkdtemp' in script and b'atexit.register(shutil.rmtree, scratch' in script
assert b"prepared = scratch/'prepared-reproduction'" in script
assert b"isolated = scratch/'pinned-source-guard-fixture'" in script
reproduction = json.loads((root / 'reproduction-checks.json').read_text(encoding='utf-8-sig'))
assert reproduction['prepareCallsGoTestOrCloud'] == 0
assert reproduction['overlayCompile']['exitCode'] == 0 and reproduction['overlayCompile']['cloudMutations'] == 0
assert all((c['exitCode'] == 0) == c['expected'] for c in reproduction['cases'])
result = {'result': 'PASS', 'runs': checks, 'externalHarnessSHA256': hashlib.sha256(script).hexdigest(),
          'externalHarnessChange': 'fixed scratch replaced by per-run temporary directory with cleanup',
          'scope': 'two recorded helper preparation/opt-out compile runs, no product or cloud mutation; package prepare helper unchanged',
          'repositoryMutationsByReviewer': False}
(out / 'publication-harness-repeat-verification.json').write_bytes((json.dumps(result, ensure_ascii=False, indent=2)+'\n').encode())
print(json.dumps({'result': 'PASS', 'runs': len(checks), 'cloudCalls': 0}))
