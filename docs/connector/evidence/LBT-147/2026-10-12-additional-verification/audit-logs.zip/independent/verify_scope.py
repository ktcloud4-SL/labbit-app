from pathlib import Path
import json,subprocess,hashlib,zipfile,datetime
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'labbit-vm-access-147'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO).decode('utf-8').strip()
def sha(data):return hashlib.sha256(data).hexdigest()
changed=set(git('diff','--name-only','origin/main...HEAD').splitlines())
local=set(git('diff','--name-only','HEAD').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
files=[]
for name in sorted(changed|local):
 p=REPO/name
 if not p.is_file():continue
 role=('pending-publication' if name.startswith('docs/connector/evidence/LBT-147/2026-10-12-additional-verification/') else 'historical-evidence' if name.startswith('docs/connector/evidence/') else 'runtime-contract' if name.startswith('runtime/') else 'test' if name.endswith('_test.go') else 'production')
 files.append({'path':name,'role':role,'localChange':name in local,'sha256':sha(p.read_bytes()),'gitBlob':git('hash-object','--',name),'bytes':p.stat().st_size})
historical=[]
for directory in sorted((REPO/'docs/connector/evidence/LBT-147').iterdir()):
 if not (directory/'artifact-checksums.json').exists():continue
 data=json.loads((directory/'artifact-checksums.json').read_text(encoding='utf-8-sig'))
 checks=data.get('artifacts') if isinstance(data,dict) and 'artifacts' in data else [{'file':k,'sha256':v} for k,v in data.items()]
 mismatches=[]
 for entry in checks:
  p=directory/entry['file'];blob=p.read_bytes()
  if sha(blob)!=entry['sha256'] or ('bytes'in entry and len(blob)!=entry['bytes']):mismatches.append(entry['file'])
 archives=[]
 for zpath in directory.glob('*.zip'):
  with zipfile.ZipFile(zpath)as z:
   bad=z.testzip();zm=[]
   manifest=directory/'archive-manifest.json'
   if manifest.exists():
    records=json.loads(manifest.read_text(encoding='utf-8-sig'))['entries']
    expected={r.get('path',r.get('entry')):r for r in records};actual={i.filename:i for i in z.infolist() if not i.is_dir()}
    zm.extend(sorted(set(expected)^set(actual)))
    for name,r in expected.items():
     if name in actual:
      body=z.read(name)
      if sha(body)!=r['sha256'] or len(body)!=r['bytes']:zm.append(name)
   archives.append({'file':zpath.name,'entries':len(z.infolist()),'crcFailure':bad,'manifestMismatches':zm,'sha256':sha(zpath.read_bytes())})
 historical.append({'directory':directory.name,'artifactCount':len(checks),'artifactMismatches':mismatches,'archives':archives})
manifest={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repo':str(REPO),'head':git('rev-parse','HEAD'),'originMain':git('rev-parse','origin/main'),'mergeBase':git('merge-base','origin/main','HEAD'),'prFiles':len(changed),'localFiles':len(local),'unionFiles':len(files),'files':files,'historicalEvidence':historical,'upstreamMainContextFiles':git('diff','--name-only','e850567066134edc87b2ba543d0eb42a21f406b8','origin/main').splitlines(),'workingTree':git('status','--short')}
(ROOT/'independent-current-source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items()if k not in ('files','workingTree','repo')},ensure_ascii=False,indent=2))
