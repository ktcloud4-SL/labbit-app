from pathlib import Path
import hashlib, json, subprocess, tempfile

out = Path(__file__).resolve().parent
repo = out.parent / 'labbit-vm-access-147'
package = repo / 'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
prefix = package.relative_to(repo).as_posix()
sha = lambda b: hashlib.sha256(b).hexdigest()
files = {p.relative_to(package).as_posix(): p.read_bytes() for p in package.rglob('*')
         if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], cwd=repo).decode().strip('\0').split('\0')
assert set(staged) == {prefix+'/'+name for name in files} and len(staged) == 21
checks = []
for name, data in sorted(files.items()):
    index = subprocess.check_output(['git', 'show', ':'+prefix+'/'+name], cwd=repo)
    assert index == data
    checks.append({'path': name, 'stagedAndWorkingSHA256': sha(data), 'exactBytes': True})
probe = Path(tempfile.mkdtemp(prefix='publication-whitespace-probe-', dir=out))
subprocess.run(['git', 'init', '-q', str(probe)], check=True)
(probe/'.gitattributes').write_bytes(files['.gitattributes'])
(probe/'probe.txt').write_bytes(b'normal\r\n')
subprocess.run(['git', 'add', '.gitattributes', 'probe.txt'], cwd=probe, check=True)
clean = subprocess.run(['git', 'diff', '--cached', '--check'], cwd=probe, capture_output=True)
assert clean.returncode == 0
(probe/'probe.txt').write_bytes(b'trailing space \r\n')
subprocess.run(['git', 'add', 'probe.txt'], cwd=probe, check=True)
trailing = subprocess.run(['git', 'diff', '--cached', '--check'], cwd=probe, capture_output=True)
assert trailing.returncode != 0 and b'trailing whitespace' in trailing.stdout+trailing.stderr
result = {'result': 'PASS', 'stagedExactFileSet': 21, 'stagedAndWorkingChecks': checks,
          'attributes': files['.gitattributes'].decode().strip(), 'isolatedProbe': str(probe),
          'cleanCRLFCheck': {'exitCode': clean.returncode},
          'realTrailingSpaceCheck': {'exitCode': trailing.returncode, 'stdout': trailing.stdout.decode(errors='replace'), 'stderr': trailing.stderr.decode(errors='replace')},
          'repositoryMutationsByReviewer': False, 'cloudCalls': 0}
(out/'publication-staged-byte-whitespace-verification.json').write_bytes((json.dumps(result, ensure_ascii=False, indent=2)+'\n').encode())
print(json.dumps({'result': result['result'], 'stagedExactFileSet': 21, 'cleanCRLFExit': clean.returncode, 'trailingSpaceExit': trailing.returncode}))
