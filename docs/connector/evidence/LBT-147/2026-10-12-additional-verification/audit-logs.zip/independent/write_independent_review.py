from pathlib import Path
import json,hashlib,re,datetime
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent/'labbit-vm-access-147';RUN=ROOT.parent/'LBT-147-additional-verification-20261012'
manifest=json.loads((ROOT/'independent-current-source-manifest.json').read_text(encoding='utf-8'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def raw_counts(p):
 counts={'pass':0,'fail':0,'skip':0}
 if not p.exists():return None
 for line in p.read_text(encoding='utf-8-sig').splitlines():
  try:event=json.loads(line)
  except ValueError:continue
  if event.get('Test') and event.get('Action') in counts:counts[event['Action']]+=1
 return counts
purpose={
 'app.go':'엄격한 VM access factory wiring, production fail-closed, Terminal→shared SSH→Control 종료 순서',
 'runtime_provider.go':'context-aware shared lazy initialization, 실패 공유/후속 retry, Provider affinity',
 'vm_access.go':'idle 설정 parsing, Reset/Cleanup 부분 파괴 실패 generation fencing, query interface forwarding',
 'terminal_target.go':'실제 Server metadata와 management NIC 검증, typed invalid/unavailable, pinned host key',
 'session.go':'종료 admission, 안전한 외부 error, Data writer/old attachment release, Resize state lock 경계',
 'ssh_pty.go':'managed PTY 채널 ownership, setup context, Close delegation/legacy socket first, Resize serialization',
 'access.go':'VM별 shared SSH, generation fence, canceled independent channel, bounded worker/cleanup/idle',
 'handler.go':'authenticated envelope 보존, Control error mapping/redaction, lifecycle consumer',
 'reconnect.go':'process shutdown hook를 current Control close 전에 실행; 일반 reconnect와 분리',
 'runtime_test.go':'최신 main tracing deadline 테스트의 잘못된 elapsed 하한만 수정; production 변경 없음',
}
rows=[]
for item in manifest['files']:
 p=Path(item['path']); role=item['role']
 if role=='test':
  names=re.findall(r'^func (Test\w+)\(', (REPO/p).read_text(encoding='utf-8'),re.M)
  detail='동작/회귀/fixture 테스트: '+', '.join(names[:4])+(' …'if len(names)>4 else '')
 elif role=='production':detail=purpose.get(p.name,'영향 구현 및 호출/consumer 검토')
 elif role=='runtime-contract':detail='기본1m 양수 SSH idle 설정 producer/consumer; PTY60s grace와 분리'
 elif role=='pending-publication':detail='새 Evidence 생성 중; source snapshot 목록만 확인. 게시 내용/재현/ZIP/secret/checksum 감사는 별도 요청 후 수행'
 else:detail='과거 실행/요약/source/재현/원본 무결성 및 당시 범위 한계 확인; 최신 소스 PASS로 확대하지 않음'
 rows.append(f"| `{item['path']}` | {'local' if item['localChange'] else 'PR'} / {role} | {detail} |")
historic=[]
for h in manifest['historicalEvidence']:
 for z in h['archives']:
  historic.append(f"| {h['directory']} | {h['artifactCount']} hashed artifacts | {z['file']}: {z['entries']} entries, CRC PASS | SHA/size/manifest mismatch {len(h['artifactMismatches'])+len(z['manifestMismatches'])} |")
raws=['unread-shutdown-before.jsonl','runcontrol-unread-before.jsonl','ownership-close-only.jsonl','final-frame-before.jsonl','candidate-green.jsonl','final-frame-and-healthy-green.jsonl','ssh-unread-close.jsonl','ssh-unread-lifecycle-before.jsonl','ssh-unread-lifecycle-candidate.jsonl','ssh-unread-lifecycle-candidate-green.jsonl','ssh-manager-unread-before.jsonl','ssh-manager-unread-final.jsonl']
rawrows=[]
for name in raws:
 p=ROOT/name
 if p.exists():rawrows.append(f"| `{name}` | `{digest(p)}` | {json.dumps(raw_counts(p))} |")
text=f'''# LBT-147 추가 검증 독립 리뷰

기록 UTC: {datetime.datetime.now(datetime.timezone.utc).isoformat()}. 이 리뷰는 구현 agent와 분리된 reviewer가 수행했다. 저장소 source/test/Evidence 수정, 실제 Cloud mutation, 원격 push/PR/Jira/메시지 변경은 하지 않았다. 외부 overlay와 synthetic TCP/SSH/WSS fixture만 작성/실행했다. 개인 PRE_MERGE_AUDIT.md와 repo AGENTS/CONTRIBUTING/TESTING를 직접 읽고 적용했다.

## 1. 현재 판정과 소스

**진행 중 검증이 있어 현재 전체 최종 판정은 보완 필요.** 새로 재현된 Data WSS/SSH Close/Resize 결함은 root가 수정했고, 현재 최소 production diff와 독립 회귀는 충족했다. 현재 SSH 수정 소스의 전체 자동 검증과 actual VM 재실행 결과/cleanup/source identity가 아직 최종 고정되지 않았다. 아래 이전 PASS는 수정된 소스 전체 PASS로 대체하지 않는다. 새 Evidence publication은 이 보고서 시점에 검토 대상이 아니다.

- repo: `{REPO}`; branch feat/LBT-147-vm-access.
- PR 기준 최신 origin/main 및 merge base: `{manifest['originMain']}`. HEAD `{manifest['head']}`.
- 이전 published HEAD da6b6701f13ba17c38b0778983545da62ac07212, R1/R2/R3 code b191ecdbe87f28c2c2e34d28877f5de84b18f082. 이번 HEAD는 최신 main 통합 후이며 미커밋 변경은 별도 byte SHA로 식별한다.
- 전체 PR 변경 {manifest['prFiles']}파일 + local {manifest['localFiles']}파일, 중복 제거 union {manifest['unionFiles']}파일. 정확 파일/role/byte SHA/Git blob은 `independent-current-source-manifest.json`.
- 최신 main e850→7aaa의6개 context 파일(go.mod/go.sum, tracing production/test, web package/package-lock)도 따로 검토했다. OTel/Prometheus/gRPC/xNet/web minor updates 포함; Gorilla1.5.3, x/crypto0.57, Gophercloud2.15 유지. Connector는 SDK/exporter를 초기화하지 않으며 기존 propagation consumer다. fresh npm lock install 및 frontend checks는 root 원본으로 확인한다.

## 2. 최신 SSOT 직접 확인과 추적성

Atlassian read-only 원문: Jira LBT-147/LBT-145/LBT-21 및 Confluence D18(page7241730), D21(6848516), D20(6881283), 테스트전략(9666637), MVP계획(12845071). 직접 읽은 body는 `independent-latest-ssot.json`/`independent-ssot-normalized.json`에 보존했다. connector structured read가 Confluence numeric version을 생략하므로 reviewer 직접 확인은 body이며, v5/v10/v7/v3/v19 version metadata는 root raw 최신 snapshot 근거다. 본문/AC 변화 없음. KT/LBT-145 선행 조건 미완료와 LBT-147 로컬 PR 범위를 분리한다.

| 요구사항/계약 | 구현 | 자동 검증/관찰 | 실제 Evidence 범위 | 공백/판정 |
| --- | --- | --- | --- | --- |
| LBT147 strict LabInstance/generation/logicalVM/Server affinity, 접속 전 stale/잘못된 대상 거절 | terminal_target.go ResolveVMAccess/resolveServerAddress; handler.go VMPTY factory; access.go generation | ownership/terminal_target/Control typed error tests, delayed resolve/setup invalidation | 기존 real VM gen1/gen2 및 추가 real affinity wronggen/wrongVM/unknownserver | 로컬 OpenStack 충족; KT 미검증 |
| management NIC private access, local user/key, 기존 server별 pin 재사용; 무검증 fallback 금지 | management network/project/device-owner/fixedIP validation; SSHHostKeyCallback existing knownhosts; production factory fail closed | ambiguity/wrongowner/pin/auth/privatekey safe failures | authenticated/pinned actual VM PTY, synthetic wrong-key actual callback rejection | hostile actual host-key rotation은 실행하지 않음 |
| VM별 lazy shared SSH, 독립 PTY/SFTP | access.go entries+users; NewManagedSSHPTY; raw SFTP Session boundary | simultaneous single handshake, A 유지+B cancel/close, SFTP independence | 기존 actual SSH_CONNECTION 메모리 비교/PTY close 후 SFTP REALPATH; 추가2VM60cycle | production File operations LBT149; load 자체가 conn identity 재비교를 하지 않음 |
| configurable no-channel idle close, PTY grace와 분리 | vm_access.go parser; runtime0.1.7 env; releaseLocked timer token | invalid/positive env, idle/open race, timer retirement | 기존 actual no-channel idle 후 다른 SSH_CONNECTION | 모든 duration별 load는 아님 |
| auth/unreachable/handshake cancel/deadline/socket cleanup | dialSSH, safeError, endpoint resolver | handshake/auth/pin/context timer ordering redaction | 실제 auth/pin 정상; additional real shell sleep cancel/deadline 각10 | remote blackhole/auth rejection은 loopback fault; 실제 shell Wait cancel이 stalled PTY request ACK와 동일하지 않음 |
| canceled B 작업이 active A를 죽이지 않음(R1) | channelOperation capacity1, late result ownership, queued channel close | activeA echo after B PTY/SFTP/open timeout/cancel; no-close-ack dependency overlay | additional actual A IO after B sleep cancel/deadline20cases | 무응답 contextless SSH request worker1은 peer reply 또는 idle/invalidate/managerClose까지 유지 |
| resolver API503은 ATTACH_FAILED, invalid ownership404는 INVALID_SESSION(R2), raw error 외부 비노출 | typed ResolveVMAccess mapping + handler safe literal | HTTP provider fixtures + Control envelope assertions | actual SDK Nova/Neutron exact GET503 fault injection + actual nonmatching affinity | 503은 실제 cloud 장애 발생이 아니라 지정 HTTP response 주입 |
| preflight FAILED 보존, 부분 mutation/UNKNOWN/first destructive rejection은 old generation fence | accessLifecycleProvider/lifecycleInvalidatesAccess | first/partial/replacement FAILED; active channel EOF; delayed resolve/setup old reject; otherLab preserve | prior actual API proxy partial worker DELETE+workspace409, preflight missingflavor, replacement actual cleanup/Neutron+Nova409 | fault-injected failures를 native provider occurrence로 주장하지 않음 |
| R3 reason/once/admission 및 Terminal→shared SSH→current Control close | app.runControl shutdown once, Supervisor hook, SessionManager.Shutdown | accepted delayed open rejection; normal reconnect hook 미호출; healthy ENDED reason once | additional actual runControl healthy/unread(mock WSS + actual provider/SSH/PTY) | 실제 Browser/SaaS multi-process routing은 미검증 |
| blocked/unread Data WSS가 cleanup을 영구 지연하지 않음 | Session.Close TryLock / final1s deadline; Attach/Detach concurrent old Close | genuine unreadTCP red3→current green; finalFrame native deadline; recovery new actual WS output/resumed | actual VM synthetic output→mock unread Data WSS branch |1s는 final frame 내부 per-session budget; whole connector shutdown guarantee 아님 |
| blocked/unread SSH INPUT/Resize에서도 manager socket close까지 도달 | managed PTY Close callback delegation; legacy client first; separate resizeMu/state lock snapshot | original genuineTCP red3 + race; current actualManager INPUT/Resize green3, worker return/serverEOF/closed admission | 이번 최종 source actual2VM run은 진행 중; unread SSH peer 자체는 synthetic fault | 실제 VM SSH daemon blackhole를 만들지 않음 |
| D18/D21 Terminal/Live control/data 분리,60s grace/resume, 내용 비저장 | Session lifetime, Data pumps, safe ended messages | replace/detach-reattach actual new binary consumer output, grace PTY alive, once explicit close | actual synthetic shell observation 메모리만; source/log는 metadata | terminal contents/privatekey/rawSSHerror를 Evidence에 보존하지 않음 |
| D20 immutable snapshot/partial failure/reconciliation/owned cleanup | existing Provider Reset/Cleanup producer + new access wrapper | lifecycle producer exact observed states, no blind mutation retry | 추가 M2/M3/Control lifecycle/Internet ON/OFF 실제 suite, exact-ID cleanup + final inventory | durable SaaS restart/Postgres integration은 이번 diff 변경 없음/대상 아님 |

Git owning SSOT: contracts/connector README + terminal-control/data schemas, contracts/realtime README/terminal-live schema, runtime contract/README 및 backend 책임 경계를 읽었다. wire fields/schema와 DB migration/HTTP API 변경 없음; tracing test-only 수정은 기존 runtime exporter shutdown 상한 의미를 유지한다. backend Terminal Control ENDED consumer의 correlation/idempotent 처리와 Relay Data disconnect grace를 확인했다. best-effort Data final frame 생략은 건강한 Control ENDED로 종료를 전달하며 둘 다 손실된 peer에서 delivery를 보장한다고 주장하지 않는다.

## 3. 수정 전 findings와 현재 상태

| ID/severity | 정확한 수정 전 위치 | 재현/관찰/영향 | 수정/회귀 상태 |
| --- | --- | --- | --- |
| F-SLOW / P1 High | da6 terminal/session.go386-387; app/app.go252/254; wss/reconnect.go164/166 | Data TCP peer attach ACK 후 읽기중단, real production PTY output write blocked; Shutdown750ms 초과3회, PTYclosedfalse/ended0. runControl real loopback SSH fixture는 Control open/SSH open 유지. 타이머/취소없어 peer가영원히읽지않으면 cleanup 무기한 대기 가능 | writeMu.TryLock busy→socketClose; lock 획득→exclusive final1s deadline. nativeTCP/red→green, healthy reason/once 및 actual runControl 검증 |
| F-SLOW-ownership / P2 Medium | da6 session.go265/333 oldConn.Close 앞 writeMu | Close-only candidate에서 currentconn 교체/분리후 oldwriter/socket/Attach/Detach750msblocked. 외부 peerforceclose후만회복 | oldConn.Close concurrent허용. replace+detach-reattach oldwrite해제, 새실제WSSbinaryoutput, 같은PTY유지/20ms grace/resumedtrue -race3PASS |
| F-SSH-CLOSE / P1 High | a5 ssh_pty.go188-194/160; app.shutdown Terminal→VMAccess.Close | managedclient=nil; peer shell ACK후읽기중단, real TCP blocked INPUT16MiB. Close stdinEOF/sessionClose 동기write에서750msblocked3회. 첫 -race는 xCrypto channel.CloseWrite624 vs WriteExtended258 sentEOF race도검출. managerClose가그뒤라소켓정리까지막힘 | managercallback만호출; shared rawchannelClose는기존worker. legacy ownclient socketfirst/stdinClose생략. actualManager realTCP before3FAIL→current3PASS, workers+serverEOF |
| F-SSH-RESIZE / P1 High | a5 session.go447-457, ssh_pty.go165-173 | WindowChange 무컨텍스트write가state s.mu/p.mu보유; genuineTCP3회 ManagerShutdown750msblocked, transportforceClose후에만회복 | 별도resizeMu로순서보존; state snapshot뒤network호출/Close는resizeMu미획득. current actualManager input/resize 두분기3회PASS |
| F-TRACE-TEST / P2 Medium (test-only) | upstream7aaa tracing/runtime_test.go648; helpers_test.go256/258 | WithTimeout 생성후time.Now로elapsed측정; 정상 DeadlineExceeded299.7157ms를budget300ms하한이실패처리. product deadline 오작동아님 | errors.Is(DeadlineExceeded) + 기존 budget+700ms 상한 + export_timeout 유지. production tracing diff없음. 초기 full Go FAIL 보존, test-only rerun은 별도소스 식별 |

원래 R1/R2/R3와 P1 partial-failure fencing/P2 lazy initialization fix는 byte unchanged 부분과 새 Terminal Close 변경 영향을 다시 검토했다. 최신 최소 production 변경은 Session/SSHPTY 두파일 안에 있으며 별도runtime option/wire/protocol을 추가하지 않는다. 기존 legacy own-client Close도 socketfirst로마무리하여 CloseWrite/dataWrite race를 피한다. 현재 추가 production 결함은 확인하지 못했다.

## 4. 원본/실행 정합성 및 실행 범위

독립 실행은 genuine TCP/Gorilla/SSH kernel backpressure이며 Cloud0이다. synthetic peer/key/PTY/relay를 actual cloud로 표기하지 않는다. finalFrame test의16MiB padding은 TCP deadline branch를 실행하기 위한 명시적 write fault injection이며 정상 Data framing acceptance가 아니다. raw 원본은 아래 해시로 보존했다.

| 원본 | SHA256 | test action counts (nested/repeats 포함) |
| --- | --- | --- |
{chr(10).join(rawrows)}

- `portable-current-recovery/result.json`: HEADa5, Datafix-only terminal SHA49141d09..., selected5tests -race count3 PASS. 이후 SSH 수정 전 결과다.
- `portable-ssh-current/result.json`: 최신 SSH/Session source SHA + fixture/dependency SHA + arguments + before/after git status를 기록하는 actualManager 포함 선택3test -race3 실행. 최종 결과를 그대로 확인해야 한다.
- `reproduce_backpressure.ps1` 및 `reproduce_ssh_backpressure.ps1`: Repo/외부Out/Count/Mode 인자; generated overlay는UTF8 BOM없음; cloud opt-in ActualVM test를 선택하지 않는 anchored names; rawjson/stderr/소스hash 기록; finally위치복원. 필요한 동료fixture와 sourcecopies를 같은외부dir에준비. Go1.27.1, race native toolchain, repo go.mod/go.sum 의존성이 필요하다. Before mode는 예상FAIL이다. 키는t.TempDir 생성뿐이며 내용을로그하지않는다.
- SSH early candidate의 최초FAIL은 shutdown은반환했으나 reservation-only fake callback 뒤의 별도 shared socketClose를 테스트가 호출하지 않은 fixture 오류다. 원본 `ssh-unread-lifecycle-candidate.jsonl` 보존; 다음 green fixture는 그다음 owner socketClose를 명시적으로모델링했고, 이후 real VMAccessManager fixture로 whole ownership을 강화했다.
- 첫 SSH repro 실행은 PowerShell result writer의 `$false` 오타로 별도 result metadata 쓰기만실패했다. Go -race rawFAIL/실제timeout/race원본은 완결되어있다. 이후 corrected wrapper/portable runner를 사용한다.
- actualManager before 원본의 끝 cleanup log는 forced transportClose후 관찰이다. Test FAIL action/750ms error가판정원본이며, 이를 normal shutdown PASS로확대하지않는다. final fixture는 normalShutdownReturned/forcedFixtureCleanup 명시.

Root 실제 실행 추가 suite 원본검토: M2Provision, M3Lifecycle, ControlWSS lifecycle, Internet ON/OFF 모두 실제로실행(이전 opt-in skip4개 해소). 이4개는 HEADda6/source pin이며 runtime shutdown 신규수정전체 검증으로확대하지않는다. actual2VM R1sleep cancel/deadline10회씩+AIO, R2 actualSDK GET503 fault+actualaffinity, actualhostpin callback rejection,60channelcycles, managerclosedadmission은 HEADa5 Datafix-only로PASS12 + childactual3, skip0/fail0. root는 SSH 최신수정 소스로 같은 suite를 다시실행중이다. Cloud 소유리소스 Cleanup등록은 Provision outcome assertion 전에하며 returned exact-ID ledger만삭제; aux key/managementSG도fixture별정리. before-SSH run actual10tracked GET404와 최종readonlymatchingprefix0를직접확인했다. 최신3rd run cleanup은 완료후별도확인해야 한다.

초기 actual fixture FAIL(childcwd/VM SSH readiness) 및 initial fullGo tracing falsefailure는 root 별도 initial directory에보존되어있다. 수정된 fixture의후속PASS로 원래FAIL을지우지않는다. 실제OpenStackcredentials/private local endpoints/keys/terminalpayload는이보고서에복사하지않았다.

## 5. 전체 파일 coverage와 과거 Evidence

| 과거 package | checksum | ZIP | 현재 검증 |
| --- | --- | --- | --- |
{chr(10).join(historic)}

2026-10-10 ZIP은 separate archive manifest가 없어 CRC와 whole artifact checksum까지만재검증했다. 나머지ZIP은exact entryset/CRC/SHA/size를대조했다. 당시 source identity/요약은당시 snapshot이고 새 source에대해새결과를주장하지 않는다. 역사 package의실환경로그/초기failure/SSOT/reproducer가마침표시된당시검증기록임을유지한다. 새 Evidence 추가시 exactartifacts/zip/secret scan/portable guard/publication source mapping은별도최종게시리뷰를해야한다.

| 파일 | scope/role | 독립 검토 목적/경계 |
| --- | --- | --- |
{chr(10).join(rows)}

추가 호출자/SSOT(context): app/dependencies_test.go; Provider lifecycle/provision/SSH hostpin enrollment/knownhosts lock; terminal/client.go pumps; wss/client.go boundedControlSend; backend terminal/service.go ControlENDED correlation/idempotence; realtime/data/relay.go grace/end consumer; contracts connector/realtime; runtime; upstream6files. HTTP/OpenAPI 및DBmigration은 변경없고 durable operation flow를새requestscope synchronousmutation으로바꾸지않았다. 기존 DB physical state/Migration의재실행은 이번connector변경의필수경로가아니며 실제Postgres integration은이번PASS라고주장하지않는다.

## 6. 잔여 한계와 남은 최종 단계

- KT Cloud/LBT145미완료, real Browser↔actual SaaS ingress/routing/drain, LBT148CC02/LBT149productionFile acceptance는미검증/후속이다. MockWSS+actualVM은그전체E2E대체가아니다.
- canceled contextlessSSH request는sharedactiveA를보존하기위해transport당pendingoperation1을유지할수있다. peerreply/idle/invalidate/managerClose가해제경계이며 즉시모든goroutine소멸을약속하지않는다. 기존 unacked B close fixture는dependencycopyoverlay의fault로준비/license/해시가과거package에포함되었다.
- finalDataframe1s는session당best-effortbudget, sessions순차close와Control기존send10s는별도다. runtime전체1sSLA/SaaS LABBIT_SHUTDOWN_GRACE 구현이라고주장하지않는다. activewrite일때DataENDED는생략가능하나healthyControlENDED reason/once를검증한다.
- 현재 최신SSHfix 전체Go/race20/freshmain contextcheck/actualVM/cleanup결과및sourcepins 최종고정이남았다. 현재report는그완료를선행해서승인하지않는다. 생산소스바이트변경시관련검증을다시한다.
- 새Evidence publication package는아직검토하지않았다. source mapping/reproducer opt-in guard/dependencies/원본failure preservation/secret exclusion/ZIPexactset/checksums가최종게시전독립확인대상이다. Audit통과는외부mutation승인이아니다.
'''
text=text.replace('**진행 중 검증이 있어 현재 전체 최종 판정은 보완 필요.** 새로 재현된 Data WSS/SSH Close/Resize 결함은 root가 수정했고, 현재 최소 production diff와 독립 회귀는 충족했다. 현재 SSH 수정 소스의 전체 자동 검증과 actual VM 재실행 결과/cleanup/source identity가 아직 최종 고정되지 않았다. 아래 이전 PASS는 수정된 소스 전체 PASS로 대체하지 않는다. 새 Evidence publication은 이 보고서 시점에 검토 대상이 아니다.', '**코드/동작 검증 범위는 통과.** 새로 재현된 Data WSS/SSH Close/Resize 결함은 수정 후 독립 회귀 및 최신 source actual VM/전체 자동 검증까지 충족했다. 검토 범위에서 미해결 confirmed product defect는 없다. 새 Evidence publication은 아직 생성 중이므로 최종 게시 판정은 별도 감사 후에 한다. 이 판정은 LBT-147 Jira 전체 완료나 KT/Browser/File acceptance를 뜻하지 않는다.')
text=text.replace('이번 최종 source actual2VM run은 진행 중; unread SSH peer 자체는 synthetic fault','최종 source actual2VM+runtime healthy/unread run PASS; unread SSH peer 자체는 synthetic fault')
text=text.replace('Root 실제 실행 추가 suite 원본검토:', '최신 최종 자동 검증 원본을 독립 집계했다: 전체 Go2885 PASS/7 opt-in skips, 관련6package race482 PASS/6 skips, 핵심 race20회940 PASS/skip0, Web13files/163tests 및 fresh npm11.21 lock install/typecheck/lint/build PASS, gofmt/vet/build/Contracts/Reset schema PASS. 전체Go07:30:06→07:30:31UTC, repeat07:30:53→07:32:06UTC. 기본skip은 Cloud opt-in이며 별도 actual run과 분리한다. `independent-run-summary.json`은 명령/시간/원본해시/action/skip 목록을 기록한다. failure-tested-source와 final-checks/tested-source의 production/dependency/runtime13/11파일(각 snapshot 포함 범위)은 현재 byte mismatch0이다. 전체 목록/source blob은 독립 manifest로 별도 고정했다.\n\nRoot 실제 실행 추가 suite 원본검토:')
text=text.replace('root는 SSH 최신수정 소스로 같은 suite를 다시실행중이다.', 'SSH 최신수정 소스로 같은 suite 재실행이07:23:48→07:28:54UTC exit0/12PASS/no skip/fail로 끝났고 actual child healthy/unread3PASS를 다시 확인했다. tracked10개 independent GET404와 최종readonlymatchingTestResidualTotal0, servers0/images3/flavors4/networks4를07:29:04UTC 직접 확인했다. `failure-final-source-state.json`의 changedProductionFiles=[] 및 independent source comparison mismatch0이다.')
text=text.replace('최신3rd run cleanup은 완료후별도확인해야 한다.', '최신3rd run의 소유 ledger10개 cleanup과 matching aux key/managementSG 포함최종재고0를 확인했다. 서로 다른실행의resource수를합쳐단일ledger처럼표시하지않는다.')
text=text.replace('현재 최신SSHfix 전체Go/race20/freshmain contextcheck/actualVM/cleanup결과및sourcepins 최종고정이남았다. 현재report는그완료를선행해서승인하지않는다. 생산소스바이트변경시관련검증을다시한다.', '현재 최신SSHfix 전체Go/race20/freshmain contextcheck/actualVM/cleanup결과및실행production source pins를확인했다. 새 Evidence 문서/요약이이결과와source identity를정확히연결하는지게시감사만남았다. 생산소스바이트변경시관련검증을다시한다.')
text=text.replace("'pending':True", "'pendingPublication':True")
text=text.replace('전체 Go2885 PASS/7 opt-in skips', '전체 Go2885 PASS/7 skips(Cloud opt-in6개+Windows에서POSIX0600 assertion1개)')
text=text.replace('기본skip은 Cloud opt-in이며 별도 actual run과 분리한다.', 'race skip6개는Cloud opt-in이며 별도 actual run과 분리한다. Windows의POSIX0600 assertion은이플랫폼에서해당없음으로skip; 실제 credential 생성/비노출 동작은다른subtest로검증한다.')
text=text.replace('production/dependency/runtime13/11파일(각 snapshot 포함 범위)', 'production/dependency/runtime11/13파일(각 snapshot 포함 범위)')
text=text.replace('전체 목록/source blob은 독립 manifest로 별도 고정했다.', '전체 목록/source blob은 독립 manifest로 별도 고정했다. final-checks의32개Go파일모두currentbyte일치; actualsnapshot31개Go파일중ssh_backpressure_test.go는실환경실행뒤standalone/log보완이추가됐고, 나머지와production는일치한다. 해당test-only보완은최종전체자동검증에포함되며actualharnessbyte는바뀌지않았다.')
text=text.replace('기존 actual SSH_CONNECTION 메모리 비교/PTY close 후 SFTP REALPATH; 추가2VM60cycle', '이전 SSHClose source actual SSH_CONNECTION 비교/PTY close후SFTP REALPATH; 최신source2VM60cycle 및A/B취소20case')
text=text.replace('production File operations LBT149; load 자체가 conn identity 재비교를 하지 않음', 'production File operations LBT149; load자체identity재비교없음. 최신Close delegation의realSFTP-after-PTY-close는normalVM test 재실행 권장/현재미실행')
text=text.replace('현재 추가 production 결함은 확인하지 못했다.', '현재 추가 production 결함은 확인하지 못했다. 다만최신Close delegation의actualSFTP-after-PTY-close/idleidentity는oldnormalVMsource기록과구분하며현재source TestOpenStackVMAccessIntegration 재실행을root에게요청했다.')
(ROOT/'independent-review.md').write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'report':str(ROOT/'independent-review.md'),'sha256':digest(ROOT/'independent-review.md'),'files':manifest['unionFiles'],'pending':True},ensure_ascii=False))
