from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone

out = Path(__file__).resolve().parent
repo = out.parent/'labbit-vm-access-147'
gaps = out.parent/'LBT-147-validation-gaps-20261012'
package = repo/'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
package.mkdir(exist_ok=True)
fixtures = package/'_fixtures'; fixtures.mkdir(exist_ok=True)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, stderr=subprocess.DEVNULL).decode('utf-8').strip()
def save(name, data):
    (package/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def sha(data): return hashlib.sha256(data).hexdigest()
def events(path):
    result = []
    for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
        if line.startswith('{'):
            try: result.append(json.loads(line))
            except json.JSONDecodeError: pass
    return result
def counts(path):
    rows = events(path)
    return {**{action: sum(bool(row.get('Test')) and row.get('Action') == action for row in rows) for action in ['pass', 'fail', 'skip']},
            'skippedTests': sorted(set(row['Test'] for row in rows if row.get('Test') and row.get('Action') == 'skip'))}

fixture_names = ['integration_metadata_test.go', 'read_only_residual_test.go', 'real_failure_test.go', 'actual_runtime_shutdown_test.go']
for name in fixture_names: (fixtures/name).write_bytes((out/name).read_bytes())
source_names = sorted(set(git('diff', '--name-only', 'origin/main').splitlines()+git('ls-files', '--others', '--exclude-standard').splitlines()))
product_names = [name for name in source_names if not name.startswith('docs/connector/evidence/')]
product_names = sorted(set(product_names+['go.mod', 'go.sum', 'web/package.json', 'web/package-lock.json', 'contracts/http/openapi.yaml', 'runtime/contract.yaml']))
product_files = [{'path': name, 'byteSHA256': sha((repo/name).read_bytes()), 'gitBlob': git('hash-object', '--path', name, name)} for name in product_names]
code_commit = git('rev-parse', 'HEAD')
manifest = {'recordedAt': datetime.now(timezone.utc).isoformat(), 'codeCommit': code_commit,
    'main': git('rev-parse', 'origin/main'), 'branch': git('branch', '--show-current'),
    'currentWorkingTree': git('status', '--porcelain'), 'productFiles': product_files,
    'fixtureSHA256': {name: sha((fixtures/name).read_bytes()) for name in fixture_names},
    'cloud4Source': 'da6b6701f13ba17c38b0778983545da62ac07212',
    'finalGoSource': json.loads((out/'final-checks/tested-source.json').read_text(encoding='utf-8')),
    'actual2VMSource': json.loads((out/'failure-tested-source.json').read_text(encoding='utf-8')),
    'latestActualVMSource': json.loads((out/'latest-vm-tested-source.json').read_text(encoding='utf-8')),
    'cloud4Applicability': 'Subsequent changes only Terminal close/resize and tracing test; original Provider integration_test.go, control_integration_test.go and relevant lifecycle algorithms unchanged. Go deps main update is distinct; do not relabel old execution as current-source cloud4 PASS.',
    'sourceChangesAfterActual2VM': 'Test metadata and standalone unread regression only; production bytes unchanged (failure-final-source-state.json).'}
save('source-manifest.json', manifest)
checks = out/'final-checks'
summary = {'dateKST': '2026-10-12', 'countsIncludeSubtests': True, 'go': counts(checks/'go-unit.log'),
    'relatedRace': counts(checks/'go-race.log'), 'regression20': counts(checks/'regression-repeat.log'),
    'cloud4': json.loads((out/'cloud-results.json').read_text(encoding='utf-8')),
    'actual2VM': json.loads((out/'real-failure-results.json').read_text(encoding='utf-8')),
    'latestActualVM': json.loads((out/'latest-vm-results.json').read_text(encoding='utf-8')),
    'actualRunControlChild': counts(out/'actual-runtime.jsonl'),
    'checks': {p.stem: json.loads(p.read_text(encoding='utf-8')) for p in sorted(checks.glob('*-run.json')) if not p.name.startswith('initial-')},
    'web': {'testFiles': 13, 'tests': 163, 'install': 'npm ci using npm11.21.0 via pnpm dlx npm@11; package-lock unchanged'},
    'contracts': {'openAPI': 'PASS', 'jsonSchemas': 8, 'runtimeMigrationMetadata': 'PASS', 'resetSchemaTests': 11},
    'initialFailuresPreserved': ['initial-real-fixture-failure', 'final-checks/initial-before-tracing-test-fix', 'final-checks/initial-gofmt-crlf*', 'reviewer red/initial candidate fixture'],
    'remaining': ['KTCloud gen2 Reset/owned Tier2 absence', 'Browser/deployed SaaS CC02/routing/reconnect/Live', 'production SFTP/File WSS', 'real VM SSH packet-stall fault/actual key rotation/natural outage/packet loss/hard restart/long soak/large load', 'actual VM runControl child server-side SSH EOF not independently observed'],
    'postgresLocal': 'Not run; no DB/application SQL changes. New remote head Go CI PostgreSQL16 integration must be inspected after push.'}
save('validation-summary.json', summary)
assert summary['go']['fail'] == summary['relatedRace']['fail'] == summary['regression20']['fail'] == 0
assert all(record['exitCode'] == 0 for record in summary['checks'].values())

raw_ssot = json.loads((out/'latest-ssot.json').read_text(encoding='utf-8'))
jira = raw_ssot['LBT-147']
save('ssot-summary.json', {
    'readAtKST': '2026-10-12',
    'jira': {'key': 'LBT-147', 'url': jira['webUrl'], 'updated': jira['fields']['updated'],
             'statusId': jira['fields']['status']['id'], 'commentCount': jira['fields']['comment']['total'],
             'descriptionSHA256': sha(json.dumps(jira['fields']['description'], ensure_ascii=False, sort_keys=True).encode())},
    'confluence': [{'pageId': key, 'title': raw_ssot[key]['title'], 'url': raw_ssot[key]['webUrl'],
                    'version': raw_ssot[key]['version']['number'], 'bodySHA256': sha(raw_ssot[key]['body'].encode())}
                   for key in ['7241730', '6881283', '6848516', '9666637', '12845071']],
    'gitSSOT': {'openapi': 'contracts/http/openapi.yaml', 'connectorRealtimeJSONSchemas': 8,
                'runtime': 'runtime/contract.yaml version 0.1.7', 'db': 'db/migrations; no PR DB diff'},
    'rawSnapshots': 'audit-logs.zip root/latest-ssot.json and independent reviewer snapshots',
})
save('reproduction-checks.json', json.loads((out/'reproduction-checks.json').read_text(encoding='utf-8')))

lines = ['# 전체 PR diff 파일 검토', '', '최신 main 기준 코드/설정/테스트/이전 Evidence와 이번 새 Evidence를 포함한다. 이전 감사의 파일별 설명에 현재 call boundary와 추가 종료/회귀 검토를 합쳤다. 아래 주요 라인은 현재 파일의 함수/시험이며 line range가 아니다. 새 Evidence는 최종 publication 검사에서 다시 검토한다.', '', '| 파일 | 목적·영향·검토 근거 | 주요 라인 |', '| --- | --- | --- |']
for name in source_names:
    path = repo/name
    if name.startswith('docs/connector/evidence/'):
        purpose = '이번 감사/fixture/재현/artifact 게시 검토' if '/2026-10-12-additional-verification/' in name else '과거 source/result·skip/초기실패·archive/hash·재현 의존성 보존 검토'
        location = 'artifact'
    else:
        text = path.read_text(encoding='utf-8')
        funcs = [(number, line.strip()) for number, line in enumerate(text.splitlines(), 1) if line.startswith('func ') and (line.startswith('func Test') or any(word in line for word in ['Close(', 'Resize(', 'OpenSession(', 'ResolveVMAccess(', 'Setup(', 'Shutdown(', 'Run(']))]
        location = '<br>'.join(f'{number}: {line.split("{")[0].strip()}' for number, line in funcs[:5]) or '전체 파일'
        if 'backpressure' in name: purpose = '실제 TCP unread peer·종료/교체/분리/복구·exact-once 및 자원해제 회귀'
        elif name.startswith('internal/observability/tracing/'): purpose = '승인된 테스트 판정만: deadline 오류·상한·export_timeout 유지; production 변경 없음'
        elif name.startswith('internal/connector/terminal/'): purpose = '관리 SSH PTY 채널 소유권·ENDED·grace·네트워크 대기와 state mutex 분리·Resize 직렬화'
        elif name.startswith('internal/connector/vmaccess/'): purpose = '공유 pinned SSH·독립 채널·idle·bounded cancellation/late result·generation fencing'
        elif name.startswith('internal/connector/provider/'): purpose = 'strict target/management endpoint·pin·invalid/unavailable 분류·partial resource cleanup provenance'
        elif name.startswith('internal/connector/app/'): purpose = 'production wiring·lazy Provider cancellation/cache·partial generation fence·Terminal/SSH/Control shutdown'
        elif name.startswith('internal/connector/wss/'): purpose = 'authenticated envelope→target·safe error enums·normal reconnect vs process lifecycle hook'
        elif name.startswith('runtime/'): purpose = 'owning runtime0.1.7 idle1m positive duration; Terminal grace 독립'
        else: purpose = '전체 diff 검토'
    lines.append(f'| {name} | {purpose} | {location} |')
(package/'file-review.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')

with zipfile.ZipFile(package/'audit-logs.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for root, prefix in [(out, 'root'), (gaps, 'independent')]:
        for path in sorted(root.rglob('*')):
            scratch = {'publication-verification', 'publication-filter-red-clone', 'publication-filter-green-clone',
                       'publication-filter-green-checkout', 'publication-filter-green-prepared',
                       'prepared-reproduction', 'pinned-source-guard-fixture', 'rejected-source-output'}
            if (not path.is_file() or '__pycache__' in path.parts or scratch.intersection(path.parts)
                    or path.suffix.lower() not in ['.json', '.jsonl', '.log', '.txt', '.py', '.go', '.diff', '.yaml', '.ps1', '.md']):
                continue
            archive.write(path, prefix+'/'+path.relative_to(root).as_posix())
    for name in product_names:
        if name.endswith('.go'): archive.write(repo/name, 'final-source/'+name)
entries = []
with zipfile.ZipFile(package/'audit-logs.zip') as archive:
    assert archive.testzip() is None
    for item in archive.infolist():
        data = archive.read(item)
        entries.append({'path': item.filename, 'bytes': len(data), 'crc32': format(item.CRC, '08x'), 'sha256': sha(data)})
save('archive-manifest.json', {'entries': entries, 'count': len(entries), 'crc': 'PASS'})

# Scoped known-value scan; never print actual credentials or private-key data.
config_bytes = Path('C:/Users/user/.config/openstack/clouds.yaml').read_bytes()
values = []
for line in config_bytes.splitlines():
    match = re.match(rb'\s*(?:password|token|client_secret|secret)\s*:\s*(.+?)\s*$', line, re.I)
    if match:
        value = match.group(1).strip(b'\"\'')
        if len(value) >= 8: values.append(value)
key = Path('C:/Users/user/.ssh/dandelion.pem').read_bytes()
values.extend([key, b'\n'.join(line for line in key.splitlines() if not line.startswith(b'-----'))])
payloads = [(str(p.relative_to(package)), p.read_bytes()) for p in package.rglob('*') if p.is_file() and p.suffix != '.zip']
with zipfile.ZipFile(package/'audit-logs.zip') as archive:
    payloads += [(item.filename, archive.read(item)) for item in archive.infolist()]
hits = []
for name, data in payloads:
    if any(value and value in data for value in values): hits.append({'file': name, 'kind': 'known-secret'})
    if re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC |)PRIVATE KEY-----\r?\n[A-Za-z0-9+/]{30}', data): hits.append({'file': name, 'kind': 'private-key-pattern'})
    if re.search(rb'(?i)authorization[\"\s:]+bearer\s+[A-Za-z0-9_.-]{24,}', data): hits.append({'file': name, 'kind': 'bearer-pattern'})
save('secret-scan.json', {'itemsChecked': len(payloads), 'knownValuesChecked': len(values), 'matches': hits, 'result': 'PASS' if not hits else 'FAIL', 'scope': 'Known local cloud password/token and actual key plus PEM/Bearer patterns; not unknown secrets/all Git history'})
if hits: raise SystemExit('Secret scan rejected artifacts; names recorded without secret values')
print(json.dumps({'productFiles': len(product_files), 'diffFiles': len(source_names), 'archiveEntries': len(entries), 'go': summary['go'], 'race': summary['relatedRace'], 'repeat': summary['regression20'], 'secretMatches': len(hits)}, ensure_ascii=False))
