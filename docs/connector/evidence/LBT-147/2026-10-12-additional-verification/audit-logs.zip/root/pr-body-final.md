## 변경 요약

LBT-147의 VM Access 기반 전체를 구현합니다. 인증된 LabInstance/generation/VM key/Provider Server에 맞는 Management SSH를 연결하고, 같은 VM의 PTY/SFTP가 SSH transport를 공유하되 채널 수명은 독립적으로 관리합니다.

- Provider 소유 metadata·project·현재 generation·논리 VM key·Server 및 Management NIC/private IP를 검증하고, 잘못된 대상과 stale generation을 SSH 전에 거절합니다. 고객 로컬 key와 기존 Server별 host-key pin을 재사용합니다.
- VM별 lazy shared SSH manager와 독립 PTY/SFTP 채널을 production app/Terminal에 연결합니다. 마지막 채널 종료 뒤 runtime 0.1.7의 `1m` idle timeout으로 transport를 정리합니다.
- target 교체, Reset/Cleanup 부분 실패, 인증·접속·handshake/setup timeout/cancel, disconnect/shutdown과 지연된 이전 generation 요청을 처리합니다. raw Provider/SSH 오류·개인키·VM 주소를 Control/Data 오류에 노출하지 않고 Terminal/SFTP 내용을 저장하지 않습니다.
- 최신 `main` `7aaa5ca`를 feature branch에 통합했습니다. main 자체를 push/merge하지 않았습니다.

## 리뷰 및 추가 감사 수정

[CODEOWNER review](https://github.com/ktcloud4-SL/labbit-app/pull/84#pullrequestreview-5486377783)와 전체 pre-merge audit에서 확인한 문제를 모두 수정했습니다.

| Finding | 변경과 회귀 |
| --- | --- |
| R1 / P1: B open/setup 취소가 A의 공유 SSH 종료 | 취소는 B 채널만 해제합니다. transport당 context 없는 SSH 작업1개와 cleanup worker1개로 제한하고 late result를 소유해 닫습니다. active A + B open/PTY/SFTP timeout/cancel6분기, late accept/reuse,24 canceled waiters, close-ACK 무응답 fixture를 검증했습니다. |
| R2 / P2: Provider 운영 장애를 INVALID_SESSION으로 분류 | 명시적 target/ownership/stale/server404만 INVALID_SESSION입니다. Nova/Neutron503/401·malformed·설정·context·BUILD/no IP는 safe ATTACH_FAILED입니다. Adapter→Manager→Control17분기 및 redaction을 검증했습니다. |
| R3 / P2: shutdown 순서 때문에 reason 경쟁·ENDED 누락 | Terminal admission 차단 → SERVICE_RESTARTING 종료/ENDED → VMAccess close → Control close 순서로 고정했습니다. ordinary reconnect에는 shutdown hook을 실행하지 않습니다. wire/enum/schema 변경은 없습니다. |
| Data backpressure / P1·P2 | unread Data TCP write가 writeMu를 보유해 shutdown·connection replace/detach를 막았습니다. active write는 socket Close로 끊고, final Data ENDED를 쓸 수 있는 경우만 session당1초 deadline으로 제한합니다. replace/detach 뒤 PTY 생존·새 peer output·grace resume를 검증했습니다. |
| SSH Close/Resize backpressure / P1 | unread SSH peer에서 stdin/session Close와 WindowChange가 network write를 기다리며 shutdown을 막고 Write/Close race를 만들었습니다. managed PTY Close는 shared manager에 channel release만 위임하고, standalone은 own client socket을 먼저 닫습니다. Resize는 순서를 직렬화하되 state mutex 밖에서 network 호출합니다. actual VMAccessManager→Terminal shutdown과 server EOF까지 회귀를 추가했습니다. |
| tracing runtime test / P2(test) | timeout context는 elapsed 측정보다 먼저 시작하므로 `elapsed >= budget` 하한이 정상 deadline을 false fail했습니다. production runtime timeout은 변경하지 않고 `context.DeadlineExceeded`, 기존 상한, `export_timeout` 진단을 검증하도록 test assertion만 수정했습니다. |

## 관련 Jira

- Jira: [LBT-147](https://samsunglions.atlassian.net/browse/LBT-147)
- 상위 [LBT-21](https://samsunglions.atlassian.net/browse/LBT-21), 선행 [LBT-145](https://samsunglions.atlassian.net/browse/LBT-145)
- 후속: LBT-148 PTY/CC02, LBT-149 SFTP, LBT-150 File WSS, C2 LBT-22/26/27

## 최종 검증

최신 Jira LBT-147와 D-18 v5, D-20 v7, D-21 v10, 테스트 전략 v3, MVP v19를 다시 확인했습니다. 전체 PR diff와 consumer, 실패·보안·수명주기, 이전 Evidence까지 독립 reviewer가 별도로 검토했습니다.

| 실행 | 결과·범위 |
| --- | --- |
| 전체 Go | fmt/mod download/vet/unit/build PASS.2885 test/subtest PASS,fail0,7SKIP(cloud opt-in6 + Windows POSIX0600 assertion1) |
| 관련6패키지 race | VMAccess/Provider/App/Terminal/WSS/tracing482 PASS,fail0,6 cloud opt-in SKIP |
| 핵심 회귀 race20회 |940 test/subtest records PASS,fail0,skip0.20회 반복 기록이며940개 독립 기능이라는 뜻은 아닙니다. |
| Web | fresh npm11 `npm ci`, typecheck/lint/test/build PASS.13파일163tests. package-lock 변경 없음 |
| Contracts | OpenAPI,8JSONSchema,runtime/migration metadata,Reset schema11 PASS |
| 로컬 OpenStack 누락4suite | source `da6b670`: M2 Provision,M3 Lifecycle,Control WSS full lifecycle,Internet ON/OFF 전부 PASS. 실행별 exact-ID cleanup assertion + 사후 inventory matching0. 이후 Provider/cloud4 production logic은 불변이지만 최신 source 실행으로 바꿔 부르지 않습니다. |
| 최신 source 실제 VM | code `bd8071d`, race PASS214.69s. authenticated/pinned shared SSH, strict target, PTY IO/resize, PTY close 뒤 같은 shared SSH SFTP INIT/VERSION/REALPATH, idle 전후 SSH_CONNECTION identity 변화, gen2 Reset/new target/stale1 거절. tracked14 exact-ID absence + final matching0 |
| 최신 source 실제2VM/fault |12 parent/subtest PASS + child runControl healthy/unread3PASS. 실제 VM별30 open/exec/close, healthy A와 B exec cancel/deadline 각10, scoped Nova/Neutron503, affinity/404, hostile signer 거절/정상 pin 복구. tracked10 및 보조SG/keypair 정리 + final matching0 |
| 독립 reviewer | Data/SSH red→green, actual TCP/WSS/SSH manager, portable current race3, 전체84 committed files 및 실행 source mapping 검토. 미해결 confirmed product defect 없음 |
| Evidence publication | source39 Git blobs, ZIP334 entries CRC/entry SHA, artifact checksums, known local secret/key+PEM/Bearer scoped scan0, 재현 준비 source/fixture/output guard 및 opt-out overlay compile cloud0 PASS |

초기 실패도 원본에 보존했습니다. 실제 fixture 첫 실행의 child cwd/readiness budget 문제, 최신 main tracing false failure, CRLF gofmt 진단, 수정 전 Data/SSH red와 첫 candidate fixture 오류를 최종 PASS로 덮어쓰지 않았습니다.

Evidence: [요약](EVIDENCE_BASE/README.md), [전체 audit·AC 추적](EVIDENCE_BASE/AUDIT.md), [전체 파일 검토](EVIDENCE_BASE/file-review.md), [독립 코드 검토](EVIDENCE_BASE/independent-review.md), [독립 게시 검토](EVIDENCE_BASE/publication-review.md), [실행 요약](EVIDENCE_BASE/validation-summary.json), [게시 검증](EVIDENCE_BASE/publication-checks.json).

## 남은 미검증 범위와 제약

- KTCloud의 LBT-145 gen2 전체 Reset 및 소유 Tier2 실제 부재 검증은 미완료입니다. 로컬 OpenStack PASS를 KT acceptance 완료로 확대하지 않습니다.
- 실제 Browser↔배포 SaaS↔Connector↔VM CC02, public routing/reconnect/Live는 LBT-148 및 C2 후속입니다.
- production SFTP/File WSS CRUD는 LBT-149/150 후속입니다. 이번 최신 실제 SFTP 범위는 INIT/VERSION/REALPATH 및 PTY 종료 뒤 채널 독립성입니다.
- 실제 VM의 unacknowledged pty-req/close-ACK packet fault, 실제 key rotation/MITM, 자연 provider outage, packet loss, hard process restart, 장시간 soak/대규모 load는 미검증입니다.2VM×30은 짧은 동시 부하입니다.
- actual VM runControl child의 server-side SSH EOF는 독립 관측하지 않았습니다. 별도 actual TCP/production VMAccessManager fixture에서는 EOF를 관측했습니다.
- 응답하지 않는 contextless SSH open/setup은 transport당1개로 제한하고 기존 active channel은 유지합니다. peer reply/idle/invalidate/manager close 전까지 같은 VM의 새 open/setup은 대기/timeout할 수 있습니다.
- Data ENDED는 backpressure에서 best effort입니다. final frame1초는 session별 경계이며 전체 N-session shutdown1초 보장이 아닙니다. 단절된 Control/Data peer의 전달도 보장하지 않습니다.
- PostgreSQL build-tag integration은 로컬 미실행입니다(DB/SQL 변경 없음). 새 remote HEAD의 Go CI PostgreSQL16 결과를 아래에서 별도 확인합니다.
- scoped secret scan은 unknown secret이나 전체 Git history 검사가 아닙니다. cloud 재현은 실제 VM/network를 만들고 지우므로 외부 config/key와 명시적 opt-in이 필요합니다.

## 확인

- [x] LBT-147 전체 변경과 모든 review/audit finding을 기록했습니다.
- [x] 요구사항→구현→자동 테스트→실환경 Evidence 추적과 독립 검토를 수행했습니다.
- [x] Secret/Credential/Token 원문을 추가하지 않았습니다.
- [ ] 새 remote HEAD Go·PostgreSQL/Web/Contracts CI
- [ ] CODEOWNER 최종 승인
