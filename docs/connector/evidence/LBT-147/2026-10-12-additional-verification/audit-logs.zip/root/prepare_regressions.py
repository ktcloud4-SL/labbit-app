from pathlib import Path

out = Path(__file__).resolve().parent
repo = out.parent / 'labbit-vm-access-147'
gaps = out.parent / 'LBT-147-validation-gaps-20261012'
for source, destination in [
    ('unread_shutdown_test.go', 'internal/connector/terminal/backpressure_test.go'),
    ('replacement_unread_test.go', 'internal/connector/terminal/data_connection_backpressure_test.go'),
]:
    text = (gaps/source).read_text(encoding='utf-8')
    text = text.replace('TestIndependentAuditUnreadDataPreventsTerminalShutdown', 'TestSessionShutdownWithUnreadDataPeer')
    text = text.replace('TestIndependentAuditUnreadOldConnectionOwnership', 'TestSessionReleasesUnreadDataConnectionOnReplaceAndDetach')
    text = text.replace('auditObservedTCP', 'observedDataTCP').replace('auditStreamingPTY', 'streamingDataPTY').replace('auditUnreadPair', 'unreadDataPair')
    (repo/destination).write_text(text, encoding='utf-8', newline='\n')

text = (gaps/'runcontrol_unread_test.go').read_text(encoding='utf-8')
start = text.index('// This opt-in variant')
end = text.index('func auditRunControlUnread(', start)
text = text[:start] + text[end:]
text = text.replace('\n\tosprovider "github.com/ktcloud4-SL/labbit-app/internal/connector/provider/openstack"', '')
text = text.replace('TestIndependentAuditRunControlUnreadDataShutdown', 'TestRunControlShutdownWithUnreadDataPeer')
text = text.replace('auditRunControlUnread', 'runControlWithUnreadDataPeer')
text = text.replace('auditTerminalTCPWriteBlocked', 'terminalTCPWriteBlocked')
text = text.replace('auditServiceRestartEnded', 'serviceRestartEndedCount')
(repo/'internal/connector/app/backpressure_test.go').write_text(text, encoding='utf-8', newline='\n')
