from pathlib import Path
import json

out = Path(__file__).resolve().parent
repo = out.parent / 'labbit-vm-access-147'
gaps = out.parent / 'LBT-147-validation-gaps-20261012'
actual = out/'actual_runtime_shutdown_test.go'
actual.write_bytes((gaps/'runcontrol_unread_test.go').read_bytes())
app_overlay = out/'actual-runtime-overlay.json'
app_overlay.write_text(json.dumps({'Replace': {
    str(repo/'internal/connector/app/additional_actual_runtime_test.go'): str(actual)
}}, indent=2), encoding='utf-8')

source = out/'real_failure_test.go'
text = source.read_text(encoding='utf-8')
text = text.replace('\n\t"os"', '\n\t"os"\n\t"os/exec"\n\t"path/filepath"')
anchor = '\n\tfor _, kind := range []string{"cancel", "deadline"} {'
assert text.count(anchor) == 1
bridge = '''
	t.Run("R3-actual-runtime-healthy-and-unread", func(t *testing.T) {
		metadata, err := json.Marshal(struct {
			Provision ProvisionConfig `json:"provision"`
			Target vmaccess.Target `json:"target"`
		}{a.provision, workspace})
		if err != nil { t.Fatal("runtime metadata encoding failed") }
		metadataFile := filepath.Join(t.TempDir(), "runtime.json")
		if err := os.WriteFile(metadataFile, metadata, 0600); err != nil { t.Fatal("runtime metadata write failed") }
		outputDir := os.Getenv("LABBIT_ADDITIONAL_OUTPUT_DIR")
		overlay := os.Getenv("LABBIT_ADDITIONAL_APP_OVERLAY")
		if outputDir == "" || overlay == "" { t.Fatal("runtime child fixture not configured") }
		stdout, err := os.Create(filepath.Join(outputDir, "actual-runtime.jsonl"))
		if err != nil { t.Fatal("runtime child log unavailable") }; defer stdout.Close()
		stderr, err := os.Create(filepath.Join(outputDir, "actual-runtime.stderr.txt"))
		if err != nil { t.Fatal("runtime child error log unavailable") }; defer stderr.Close()
		childCtx, stop := context.WithTimeout(ctx, 2*time.Minute); defer stop()
		command := exec.CommandContext(childCtx, "go", "test", "-race", "-json", "-count=1", "-timeout=90s", "-overlay", overlay,
			"-run", "^TestIndependentAuditRunControlActualVMShutdown$", "./internal/connector/app")
		command.Env = append(os.Environ(), "LABBIT_ADDITIONAL_RUNTIME_METADATA_FILE="+metadataFile)
		command.Stdout, command.Stderr = stdout, stderr
		if err := command.Run(); err != nil { t.Fatal("actual runtime healthy/unread shutdown failed; preserved child logs") }
		t.Log("Actual VM: production runControl/Keystone/target resolution/pinned SSH/PTY/Data WSS; healthy and unread peer shutdown, Control ENDED exactly once. Control/Data SaaS peers are mock; VM server-side SSH EOF not independently observed")
	})
'''
text = text.replace(anchor, bridge+anchor)
source.write_text(text, encoding='utf-8', newline='\n')

regression = repo/'internal/connector/app/backpressure_test.go'
text = regression.read_text(encoding='utf-8')
text = text.replace('&chunks, false)', '&chunks)')
text = text.replace(', actual bool) {', ') {')
start = text.index('\tif actual {')
end = text.index('\n\tdeadline :=', start)
text = text[:start] + '\tbegin()\n' + text[end:]
text = text.replace('actualVM=%t TCPWriteBlocked=', 'TCPWriteBlocked=').replace(', actual, terminalTCPWriteBlocked()', ', terminalTCPWriteBlocked()')
regression.write_text(text, encoding='utf-8', newline='\n')
