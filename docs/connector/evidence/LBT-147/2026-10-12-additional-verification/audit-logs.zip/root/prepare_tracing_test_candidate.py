from pathlib import Path
import json
import subprocess

out = Path(__file__).resolve().parent
repo = out.parent/'labbit-vm-access-147'
path = repo/'internal/observability/tracing/runtime_test.go'
before = path.read_text(encoding='utf-8')
after = before.replace('\n\t"encoding/hex"', '\n\t"encoding/hex"\n\t"errors"')
old = '''	if err == nil {
		t.Fatal("응답하지 않는 Collector인데 Shutdown이 성공함")
	}
	if elapsed < budget || elapsed > budget+700*time.Millisecond {'''
new = '''	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("응답하지 않는 Collector의 Shutdown error = %v, want context deadline exceeded", err)
	}
	// Context timeout and the elapsed measurement start at different times.
	// Check the deadline error and upper bound without a false early-return failure.
	if elapsed > budget+700*time.Millisecond {'''
assert after.count(old) == 1
after = after.replace(old, new)
candidate = out/'tracing_runtime_test_candidate.go'
candidate.write_text(after, encoding='utf-8', newline='\n')
subprocess.run(['gofmt', '-w', str(candidate)], check=True)
(out/'tracing-test-candidate-overlay.json').write_text(json.dumps({'Replace': {str(path): str(candidate)}}, indent=2), encoding='utf-8')
diff = subprocess.run(['git', 'diff', '--no-index', '--', str(path), str(candidate)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
assert diff.returncode == 1
(out/'tracing-test-candidate.diff').write_bytes(diff.stdout)
print('External test-only candidate ready; repository source unchanged')
