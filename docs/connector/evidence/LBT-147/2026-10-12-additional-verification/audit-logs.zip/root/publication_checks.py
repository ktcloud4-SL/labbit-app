from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

out = Path(__file__).resolve().parent
repo = out.parent/'labbit-vm-access-147'
package = repo/'docs/connector/evidence/LBT-147/2026-10-12-additional-verification'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=repo).decode('utf-8').strip()
def read(name): return json.loads((package/name).read_text(encoding='utf-8'))

manifest = read('source-manifest.json')
assert manifest['codeCommit'] == git('rev-parse', 'HEAD')
source_errors = []
for item in manifest['productFiles']:
    path = repo/item['path']
    blob = git('hash-object', '--path', item['path'], item['path'])
    commit_blob = git('rev-parse', manifest['codeCommit']+':'+item['path'])
    if blob != item['gitBlob'] or commit_blob != item['gitBlob'] or sha(path.read_bytes()) != item['byteSHA256']:
        source_errors.append(item['path'])
assert not source_errors
changed = git('diff', '--name-only', 'HEAD').splitlines()
untracked = git('ls-files', '--others', '--exclude-standard').splitlines()
assert all(name.startswith('docs/connector/evidence/LBT-147/2026-10-12-additional-verification/') for name in changed+untracked)

summary = read('validation-summary.json')
assert summary['go']['fail'] == summary['relatedRace']['fail'] == summary['regression20']['fail'] == 0
assert summary['go']['pass'] == 2885 and summary['relatedRace']['pass'] == 482 and summary['regression20']['pass'] == 940
assert summary['actualRunControlChild']['fail'] == 0
assert all(x['exitCode'] == 0 for x in summary['cloud4']['runs'])
assert all(x['exitCode'] == 0 for x in summary['actual2VM'])
assert all(x['exitCode'] == 0 for x in summary['latestActualVM'])
assert all(x['exitCode'] == 0 for x in summary['checks'].values())
assert read('secret-scan.json')['result'] == 'PASS'
reproduction = read('reproduction-checks.json')
assert reproduction['overlayCompile']['exitCode'] == 0 and reproduction['prepareCallsGoTestOrCloud'] == 0

archive_manifest = read('archive-manifest.json')
with zipfile.ZipFile(package/'audit-logs.zip') as archive:
    assert archive.testzip() is None
    current = [{'path': item.filename, 'bytes': len(archive.read(item)), 'crc32': format(item.CRC, '08x'),
                'sha256': sha(archive.read(item))} for item in archive.infolist()]
assert current == archive_manifest['entries']

required = {'.gitattributes', '.gitignore', 'README.md', 'AUDIT.md', 'file-review.md', 'independent-review.md',
            'publication-review.md',
            'source-manifest.json', 'validation-summary.json', 'ssot-summary.json', 'reproduction-checks.json',
            'archive-manifest.json', 'secret-scan.json', 'audit-logs.zip', 'prepare_overlays.py',
            '_fixtures/integration_metadata_test.go', '_fixtures/read_only_residual_test.go',
            '_fixtures/real_failure_test.go', '_fixtures/actual_runtime_shutdown_test.go'}
existing = {p.relative_to(package).as_posix() for p in package.rglob('*') if p.is_file() and p.name not in {'publication-checks.json', 'artifact-checksums.json'}}
assert required == existing, {'missing': sorted(required-existing), 'extra': sorted(existing-required)}

checks = {'result': 'PASS', 'codeCommit': manifest['codeCommit'], 'main': manifest['main'],
    'productFilesVerified': len(manifest['productFiles']), 'onlyEvidenceUncommitted': True,
    'runResultsVerified': {'go': summary['go'], 'relatedRace': summary['relatedRace'], 'regression20': summary['regression20'],
                           'cloud4Runs': len(summary['cloud4']['runs']), 'actual2VMRuns': len(summary['actual2VM']),
                           'latestActualVMRuns': len(summary['latestActualVM'])},
    'archive': {'entries': len(current), 'crcAndEntrySHA256': 'PASS'}, 'secretScan': 'PASS',
    'reproductionPreparation': 'PASS; preparation Go/cloud calls0; explicit opt-out overlay compile1SKIP cloud0',
    'expectedArtifactSetBeforePublicationFiles': sorted(required)}
(package/'publication-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

checksums = []
for path in sorted(package.rglob('*')):
    if path.is_file() and path.name != 'artifact-checksums.json':
        checksums.append({'path': path.relative_to(package).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())})
(package/'artifact-checksums.json').write_text(json.dumps({'files': checksums, 'count': len(checksums)}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'result': 'PASS', 'sourceFiles': len(manifest['productFiles']), 'artifacts': len(checksums), 'archiveEntries': len(current)}))
