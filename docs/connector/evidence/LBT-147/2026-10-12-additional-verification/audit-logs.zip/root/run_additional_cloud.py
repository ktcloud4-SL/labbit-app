"""Explicit local OpenStack verification; sequential owned-resource fixtures."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys

OUT = Path(__file__).resolve().parent
REPO = OUT.parent/'labbit-vm-access-147'
PRIOR = OUT.parent/'LBT-147-review-followup-20261012'
FLAGS = ['LABBIT_OPENSTACK_INTEGRATION', 'LABBIT_OPENSTACK_MUTATION_TEST',
         'LABBIT_OPENSTACK_M2_TEST', 'LABBIT_OPENSTACK_M3_TEST',
         'LABBIT_OPENSTACK_INTERNET_POLICY_TEST', 'LABBIT_OPENSTACK_M2_WSS_TEST',
         'LABBIT_OPENSTACK_M3_WSS_TEST', 'LABBIT_OPENSTACK_VM_ACCESS_TEST',
         'LABBIT_OPENSTACK_APP_AUDIT', 'LABBIT_OPENSTACK_RESIDUAL_AUDIT']

def save(name, data):
    (OUT/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode('utf-8').strip()

assert git('rev-parse', 'HEAD') == 'da6b6701f13ba17c38b0778983545da62ac07212'
assert not git('status', '--porcelain')
files = git('diff', '--name-only', 'origin/main...HEAD').splitlines()
save('tested-source.json', {'head': git('rev-parse', 'HEAD'),
    'originMain': git('rev-parse', 'origin/main'), 'workingTree': 'clean',
    'recordedAt': datetime.now(timezone.utc).isoformat(),
    'files': [{'path': p, 'gitBlob': git('hash-object', '--path', p, p),
               'sha256': hashlib.sha256((REPO/p).read_bytes()).hexdigest()} for p in files]})

# Test-only overlay adds exact-ID cleanup metadata. The original behavior and
# assertions remain unchanged; production/repository files are never edited.
integration = REPO/'internal/connector/provider/openstack/integration_test.go'
source = integration.read_text(encoding='utf-8')
anchor = 'func cleanupM2Resources(t *testing.T, adapter *Adapter, resources []coreprovider.ResourceResult) {\n\tt.Helper()'
assert source.count(anchor) == 1
source = source.replace(anchor, anchor+'\n\tt.Logf("Additional exact-ID cleanup scheduled: %+v", resources)')
anchor = '\tfor _, resource := range resources {\n\t\tif err := verifyM2ResourceDeleted(ctx, adapter, resource); err != nil {'
assert source.count(anchor) == 1
source = source.replace(anchor, '\tif !t.Failed() { t.Logf("Additional cleanup verify GET/404: resources=%d", len(resources)) }\n'+anchor)
fixture = OUT/'integration_metadata_test.go'
fixture.write_text(source, encoding='utf-8')
residual = OUT/'read_only_residual_test.go'
residual_source = (PRIOR/'read_only_residual_test.go').read_text(encoding='utf-8')
residual_source = residual_source.replace('strings.HasPrefix(name, "labbit-lbt147")',
    'strings.HasPrefix(name, "labbit-lbt147") || strings.HasPrefix(name, "labbit-m2-") || strings.HasPrefix(name, "labbit-m3-") || strings.HasPrefix(name, "labbit-internet-policy-")')
residual.write_text(residual_source, encoding='utf-8')
overlay = OUT/'cloud-overlay.json'
save(overlay.name, {'Replace': {str(integration): str(fixture),
    str(REPO/'internal/connector/provider/openstack/lbt147_additional_residual_test.go'): str(residual)}})
save('overlay-source.json', {'purpose': 'test-only exact owned-ID cleanup metadata and read-only inventory names',
    'productionChanged': False,
    'files': [{'file': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in [fixture, residual]]})

env = dict(os.environ)
for key in FLAGS:
    env[key] = '0'
env.update({'LABBIT_PROVIDER_CONFIG_FILE': 'C:/Users/user/.config/openstack/clouds.yaml',
    'OS_CLOUD': 'labbit-test', 'LABBIT_OPENSTACK_SSH_PRIVATE_KEY_FILE': 'C:/Users/user/.ssh/dandelion.pem',
    'LABBIT_OPENSTACK_SSH_USERNAME': 'ubuntu', 'LABBIT_OPENSTACK_TEST_IMAGE': 'ubuntu',
    'LABBIT_OPENSTACK_TEST_FLAVOR': 'm1.small', 'LABBIT_OPENSTACK_TEST_MANAGEMENT_NETWORK': 'sharednet1',
    'LABBIT_OPENSTACK_TEST_SSH_CIDR': '172.16.8.1/32', 'LABBIT_OPENSTACK_TEST_LAB_CIDR': '198.20.0.0/24'})
results = []

def run(label, selection, flags, timeout):
    child_env = dict(env)
    child_env.update({key: '1' for key in flags})
    command = ['go', 'test', '-race', '-overlay', str(overlay), '-json', '-count=1',
               '-timeout='+timeout, '-run', '^('+selection+')$', './internal/connector/provider/openstack']
    print(json.dumps({'started': label, 'cloud': 'local labbit-test', 'selectedFlags': flags}), flush=True)
    start = datetime.now(timezone.utc).isoformat()
    with (OUT/(label+'.jsonl')).open('wb') as stdout, (OUT/(label+'.stderr.txt')).open('wb') as stderr:
        completed = subprocess.run(command, cwd=REPO, env=child_env, stdout=stdout, stderr=stderr)
    events = []
    for line in (OUT/(label+'.jsonl')).read_text(encoding='utf-8', errors='replace').splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    counts = {name: sum(1 for item in events if item.get('Test') and item.get('Action') == name)
              for name in ['pass', 'fail', 'skip']}
    record = {'label': label, 'command': command, 'startedAt': start,
        'endedAt': datetime.now(timezone.utc).isoformat(), 'exitCode': completed.returncode,
        'counts': counts, 'selectedFlags': flags}
    results.append(record)
    save('cloud-results.json', {'head': git('rev-parse', 'HEAD'), 'runs': results})
    print(json.dumps({'completed': label, 'exitCode': completed.returncode, 'counts': counts}), flush=True)
    return completed.returncode

if run('pre-inventory', 'TestOpenStackM1Integration|TestLBT147ReadOnlyResiduals',
       ['LABBIT_OPENSTACK_INTEGRATION', 'LABBIT_OPENSTACK_RESIDUAL_AUDIT'], '3m'):
    raise SystemExit('Read-only baseline failed; no mutation started')

cases = [
    ('m2-provision', 'TestOpenStackM2ProvisionIntegration', ['LABBIT_OPENSTACK_M2_TEST'], '18m'),
    ('m3-lifecycle', 'TestOpenStackM3LifecycleIntegration', ['LABBIT_OPENSTACK_M3_TEST'], '24m'),
    ('control-wss-full-lifecycle', 'TestOpenStackM2ControlWSSIntegration',
     ['LABBIT_OPENSTACK_M2_WSS_TEST', 'LABBIT_OPENSTACK_M3_WSS_TEST'], '20m'),
    ('internet-policy', 'TestOpenStackInternetPolicyIntegration', ['LABBIT_OPENSTACK_INTERNET_POLICY_TEST'], '28m'),
]
failed = False
try:
    for label, selection, flags, timeout in cases:
        code = run(label, selection, flags, timeout)
        residual_code = run(label+'-post-inventory', 'TestLBT147ReadOnlyResiduals',
                            ['LABBIT_OPENSTACK_RESIDUAL_AUDIT'], '3m')
        if code or residual_code:
            failed = True
            break
finally:
    final_code = run('final-inventory', 'TestOpenStackM1Integration|TestLBT147ReadOnlyResiduals',
                     ['LABBIT_OPENSTACK_INTEGRATION', 'LABBIT_OPENSTACK_RESIDUAL_AUDIT'], '3m')
    failed = failed or bool(final_code)
    save('final-source-state.json', {'head': git('rev-parse', 'HEAD'),
        'workingTree': git('status', '--porcelain'),
        'changedPinnedFiles': [item['path'] for item in json.loads((OUT/'tested-source.json').read_text(encoding='utf-8'))['files']
                              if hashlib.sha256((REPO/item['path']).read_bytes()).hexdigest() != item['sha256']]})
if failed:
    raise SystemExit('Additional cloud verification failed; inspect preserved logs and final inventory')
print('Additional local cloud suites PASS; exact-ID cleanup and inventories checked', flush=True)
