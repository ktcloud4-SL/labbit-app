from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path(os.environ.get('LABBIT_EVIDENCE_REPO', str(root.parent/'labbit-vm-access-147')))
out = root/'final-checks'; out.mkdir(exist_ok=True)
deps = Path(os.environ['LABBIT_EVIDENCE_DEPS'])
def save(name, data):
    (out/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo).decode('utf-8').strip()
def run(label, command, cwd=repo, env=None):
    start = datetime.now(timezone.utc).isoformat()
    print(json.dumps({'started': label}), flush=True)
    with (out/(label+'.log')).open('wb') as stdout, (out/(label+'.stderr.txt')).open('wb') as stderr:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
    save(label+'-run.json', {'command': command, 'startedAt': start, 'endedAt': datetime.now(timezone.utc).isoformat(), 'exitCode': result.returncode})
    print(json.dumps({'completed': label, 'exitCode': result.returncode}), flush=True)
    if result.returncode: raise SystemExit(result.returncode)

mode = sys.argv[1]
if mode == 'go':
    for key in list(os.environ):
        if key.startswith('LABBIT_OPENSTACK_') and (key.endswith('_TEST') or key.endswith('_AUDIT') or key.endswith('_INTEGRATION')):
            os.environ[key] = '0'
    names = sorted(set(git('diff', '--name-only', 'origin/main...HEAD').splitlines()) | set(git('diff', '--name-only', 'HEAD').splitlines()) | set(git('ls-files', '--others', '--exclude-standard').splitlines()))
    names = sorted(set(names + ['go.mod', 'go.sum', 'web/package.json', 'web/package-lock.json']))
    save('tested-source.json', {'head': git('rev-parse', 'HEAD'), 'main': git('rev-parse', 'origin/main'), 'workingTree': git('status', '--porcelain'),
        'files': [{'path': p, 'sha256': hashlib.sha256((repo/p).read_bytes()).hexdigest(), 'gitBlob': git('hash-object', '--path', p, p)} for p in names]})
    files = subprocess.check_output(['rg', '--files', '-g', '*.go', '-g', '!vendor', '-g', '!node_modules'], cwd=repo).decode('utf-8').splitlines()
    check = subprocess.run(['gofmt', '-l', *files], cwd=repo, capture_output=True)
    (out/'gofmt.log').write_bytes(check.stdout+check.stderr)
    save('gofmt-run.json', {'exitCode': check.returncode, 'filesChecked': len(files), 'unformatted': check.stdout.decode().splitlines()})
    if check.returncode or check.stdout.strip(): raise SystemExit('gofmt failed')
    run('go-mod-download', ['go', 'mod', 'download'])
    run('go-vet', ['go', 'vet', './...'])
    run('go-unit', ['go', 'test', '-json', '-count=1', './...'])
    run('go-build', ['go', 'build', './...'])
    packages = ['./internal/connector/vmaccess', './internal/connector/provider/openstack', './internal/connector/app', './internal/connector/terminal', './internal/connector/wss', './internal/observability/tracing']
    run('go-race', ['go', 'test', '-race', '-json', '-count=1', *packages])
    tests = 'TestCanceledChannelLeavesActivePTYUsable|TestCanceledOpenClosesLateChannelAndReusesTransport|TestStalledOpenDoesNotAccumulateCanceledSSHRequests|TestVMAccessProviderFailuresAndTargetMismatchControlCodes|TestLatestMainControlProviderAndTerminalShareRuntime|TestTerminalShutdownRejectsDelayedOpensAndEndsOnce|TestSupervisor_LifecycleAndReconnect|TestSessionShutdownWithUnreadDataPeer|TestSessionReleasesUnreadDataConnectionOnReplaceAndDetach|TestSessionRecoversFromUnreadDataConnectionWithoutEndingPTY|TestSessionBoundsFinalDataEndedWrite|TestRunControlShutdownWithUnreadDataPeer|TestSSHPTYCloseWithUnreadPeer|TestSessionShutdownWithUnreadSSHResize|TestManagedSSHShutdownWithUnreadPeer|TestShutdownIsBoundedByTheGivenBudgetWhenCollectorHangs'
    run('regression-repeat', ['go', 'test', '-race', '-json', '-count=20', '-timeout=5m', '-run', tests, *packages])
elif mode == 'web':
    env = dict(os.environ); env['PATH'] = str(deps/'node/bin')+os.pathsep+env['PATH']
    pnpm = str(deps/'bin/fallback/pnpm.cmd')
    run('npm-version', [pnpm, 'dlx', 'npm@11', '--version'], cwd=repo/'web', env=env)
    run('web-install', [pnpm, 'dlx', 'npm@11', 'ci', '--no-audit', '--no-fund'], cwd=repo/'web', env=env)
    for label in ['typecheck', 'lint', 'test', 'build']:
        run('web-'+label, [pnpm, 'run', label], cwd=repo/'web', env=env)
elif mode == 'contracts':
    libs = os.environ.get('LABBIT_EVIDENCE_VALIDATOR_LIBS')
    if libs: sys.path.insert(0, libs)
    import yaml
    from openapi_spec_validator import validate
    validate(yaml.safe_load((repo/'contracts/http/openapi.yaml').read_text(encoding='utf-8')))
    workflow = yaml.safe_load((repo/'.github/workflows/contracts.yml').read_text(encoding='utf-8'))
    os.chdir(repo)
    with (out/'contracts.log').open('w', encoding='utf-8') as log:
        previous = sys.stdout
        try:
            sys.stdout = log
            print('OpenAPI: PASS')
            for step in workflow['jobs']['validate']['steps']:
                script = step.get('run', '')
                if "python <<'PY'" in script:
                    exec(compile(script.split("python <<'PY'", 1)[1].rsplit('\nPY', 1)[0], '<contract-workflow>', 'exec'), {})
        finally: sys.stdout = previous
    save('contracts-run.json', {'exitCode': 0, 'scope': 'OpenAPI and exact current workflow JSON Schema/Runtime/Migration validators'})
    env = dict(os.environ)
    if libs: env['PYTHONPATH'] = libs+os.pathsep+env.get('PYTHONPATH', '')
    run('reset-schema', [sys.executable, str(repo/'contracts/connector/tests/test_reset_schema.py'), '-v'], env=env)
else:
    raise SystemExit('select go, web or contracts; no implicit cloud execution')
