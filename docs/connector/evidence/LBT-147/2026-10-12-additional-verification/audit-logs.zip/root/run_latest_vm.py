from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

out = Path(__file__).resolve().parent
repo = out.parent/'labbit-vm-access-147'
env = dict(os.environ)
for name in list(env):
    if name.startswith('LABBIT_OPENSTACK_') and (name.endswith('_TEST') or name.endswith('_AUDIT') or name.endswith('_INTEGRATION')):
        env[name] = '0'
env['LABBIT_LBT147_ADDITIONAL_REAL_TEST'] = '0'
env.update({'LABBIT_PROVIDER_CONFIG_FILE': 'C:/Users/user/.config/openstack/clouds.yaml', 'OS_CLOUD': 'labbit-test',
    'LABBIT_OPENSTACK_SSH_PRIVATE_KEY_FILE': 'C:/Users/user/.ssh/dandelion.pem', 'LABBIT_OPENSTACK_SSH_USERNAME': 'ubuntu',
    'LABBIT_OPENSTACK_TEST_IMAGE': 'ubuntu', 'LABBIT_OPENSTACK_TEST_FLAVOR': 'm1.small', 'LABBIT_OPENSTACK_TEST_MANAGEMENT_NETWORK': 'sharednet1',
    'LABBIT_OPENSTACK_TEST_SSH_CIDR': '172.16.8.1/32', 'LABBIT_OPENSTACK_TEST_LAB_CIDR': '198.20.0.0/24'})
def save(name, data): (out/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def git(*args): return subprocess.check_output(['git', *args], cwd=repo).decode('utf-8').strip()
paths = [p for p in git('diff', '--name-only', 'origin/main').splitlines() if not p.startswith('docs/connector/evidence/')]+['go.mod', 'go.sum']
save('latest-vm-tested-source.json', {'head': git('rev-parse', 'HEAD'), 'main': git('rev-parse', 'origin/main'),
    'files': [{'path': p, 'sha256': hashlib.sha256((repo/p).read_bytes()).hexdigest()} for p in sorted(set(paths))]})
records = []
def run(label, test, flag):
    child = dict(env); child[flag] = '1'
    command = ['go', 'test', '-race', '-overlay', str(out/'cloud-overlay.json'), '-json', '-count=1', '-timeout=24m', '-run', '^'+test+'$', './internal/connector/provider/openstack']
    start = datetime.now(timezone.utc).isoformat()
    print(json.dumps({'started': label, 'flag': flag}), flush=True)
    with (out/(label+'.jsonl')).open('wb') as stdout, (out/(label+'.stderr.txt')).open('wb') as stderr:
        result = subprocess.run(command, cwd=repo, env=child, stdout=stdout, stderr=stderr)
    events = [json.loads(line) for line in (out/(label+'.jsonl')).read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    counts = {a: sum(bool(x.get('Test')) and x.get('Action') == a for x in events) for a in ['pass', 'fail', 'skip']}
    records.append({'label': label, 'command': command, 'selectedFlag': flag, 'startedAt': start,
        'endedAt': datetime.now(timezone.utc).isoformat(), 'exitCode': result.returncode, 'counts': counts})
    save('latest-vm-results.json', records)
    print(json.dumps({'completed': label, 'exitCode': result.returncode, 'counts': counts}), flush=True)
    return result.returncode
if run('latest-vm-pre-inventory', 'TestLBT147ReadOnlyResiduals', 'LABBIT_OPENSTACK_RESIDUAL_AUDIT'):
    raise SystemExit('pre-inventory failed; no mutation')
failed = True
try:
    failed = bool(run('latest-vm-access', 'TestOpenStackVMAccessIntegration', 'LABBIT_OPENSTACK_VM_ACCESS_TEST'))
finally:
    failed = bool(run('latest-vm-final-inventory', 'TestLBT147ReadOnlyResiduals', 'LABBIT_OPENSTACK_RESIDUAL_AUDIT')) or failed
    source = json.loads((out/'latest-vm-tested-source.json').read_text(encoding='utf-8'))
    save('latest-vm-final-source-state.json', {'head': git('rev-parse', 'HEAD'), 'changedSourceFiles': [x['path'] for x in source['files'] if hashlib.sha256((repo/x['path']).read_bytes()).hexdigest() != x['sha256']]})
if failed: raise SystemExit('latest actual VM/SFTP/idle verification failed; raw logs preserved')
