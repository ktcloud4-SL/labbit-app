from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

out = Path(__file__).resolve().parent
repo = out.parent/'labbit-vm-access-147'
def save(name, data):
    (out/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo).decode('utf-8').strip()
paths = sorted(set(git('diff', '--name-only', 'origin/main').splitlines() + git('ls-files', '--others', '--exclude-standard').splitlines()))
save('failure-tested-source.json', {'head': git('rev-parse', 'HEAD'), 'main': git('rev-parse', 'origin/main'),
    'workingTree': git('status', '--porcelain'), 'startedAt': datetime.now(timezone.utc).isoformat(),
    'files': [{'path': p, 'sha256': hashlib.sha256((repo/p).read_bytes()).hexdigest()} for p in paths],
    'fixtures': [{'path': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in
                 [out/'real_failure_test.go', out/'actual_runtime_shutdown_test.go', out/'integration_metadata_test.go', out/'read_only_residual_test.go']]})
env = dict(os.environ)
for key in ['LABBIT_OPENSTACK_INTEGRATION', 'LABBIT_OPENSTACK_MUTATION_TEST', 'LABBIT_OPENSTACK_M2_TEST',
            'LABBIT_OPENSTACK_M3_TEST', 'LABBIT_OPENSTACK_INTERNET_POLICY_TEST', 'LABBIT_OPENSTACK_M2_WSS_TEST',
            'LABBIT_OPENSTACK_M3_WSS_TEST', 'LABBIT_OPENSTACK_VM_ACCESS_TEST', 'LABBIT_OPENSTACK_APP_AUDIT',
            'LABBIT_OPENSTACK_RESIDUAL_AUDIT', 'LABBIT_LBT147_ADDITIONAL_REAL_TEST']:
    env[key] = '0'
env.update({'LABBIT_PROVIDER_CONFIG_FILE': 'C:/Users/user/.config/openstack/clouds.yaml', 'OS_CLOUD': 'labbit-test',
    'LABBIT_OPENSTACK_SSH_PRIVATE_KEY_FILE': 'C:/Users/user/.ssh/dandelion.pem', 'LABBIT_OPENSTACK_SSH_USERNAME': 'ubuntu',
    'LABBIT_ADDITIONAL_APP_OVERLAY': str(out/'actual-runtime-overlay.json'), 'LABBIT_ADDITIONAL_OUTPUT_DIR': str(out),
    'LABBIT_ADDITIONAL_REPO_DIR': str(repo)})
records = []
def run(label, test, flags, overlay, timeout):
    child = dict(env); child.update({key: '1' for key in flags})
    command = ['go', 'test', '-race', '-overlay', str(out/overlay), '-json', '-count=1', '-timeout='+timeout,
               '-run', '^('+test+')$', './internal/connector/provider/openstack']
    print(json.dumps({'started': label, 'selectedFlags': flags}), flush=True)
    start = datetime.now(timezone.utc).isoformat()
    with (out/(label+'.jsonl')).open('wb') as stdout, (out/(label+'.stderr.txt')).open('wb') as stderr:
        result = subprocess.run(command, cwd=repo, env=child, stdout=stdout, stderr=stderr)
    events = [json.loads(line) for line in (out/(label+'.jsonl')).read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    counts = {action: sum(item.get('Test') is not None and item.get('Action') == action for item in events) for action in ['pass', 'fail', 'skip']}
    records.append({'label': label, 'command': command, 'selectedFlags': flags, 'startedAt': start,
                    'endedAt': datetime.now(timezone.utc).isoformat(), 'exitCode': result.returncode, 'counts': counts})
    save('real-failure-results.json', records)
    print(json.dumps({'completed': label, 'exitCode': result.returncode, 'counts': counts}), flush=True)
    return result.returncode
if run('failure-pre-inventory', 'TestLBT147ReadOnlyResiduals', ['LABBIT_OPENSTACK_RESIDUAL_AUDIT'], 'cloud-overlay.json', '3m'):
    raise SystemExit('baseline inventory failed; no mutations started')
failed = True
try:
    failed = bool(run('real-failures', 'TestLBT147AdditionalRealFailures', ['LABBIT_LBT147_ADDITIONAL_REAL_TEST'], 'real-failure-overlay.json', '24m'))
finally:
    failed = bool(run('failure-final-inventory', 'TestLBT147ReadOnlyResiduals', ['LABBIT_OPENSTACK_RESIDUAL_AUDIT'], 'cloud-overlay.json', '3m')) or failed
    source = json.loads((out/'failure-tested-source.json').read_text(encoding='utf-8'))
    save('failure-final-source-state.json', {'head': git('rev-parse', 'HEAD'), 'workingTree': git('status', '--porcelain'),
        'changedProductionFiles': [item['path'] for item in source['files'] if not item['path'].endswith('_test.go')
                                  and hashlib.sha256((repo/item['path']).read_bytes()).hexdigest() != item['sha256']]})
if failed: raise SystemExit('actual failure/lifecycle verification failed; retained all logs')
print('Actual R1/R2/R3/host-key/two-VM verification PASS with owned cleanup', flush=True)
