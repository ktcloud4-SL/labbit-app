"""External local metadata-only proof: no cloud or Go tests executed."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

sys.dont_write_bytecode = True
repo = Path(sys.argv[1]).resolve(strict=True)
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
fixture = out / 'fixture'
fixture.mkdir()
(fixture/'go.mod').write_text('module auditfixture\n\ngo 1.27.0\n', encoding='utf-8')
(fixture/'doc.go').write_text('package auditfixture\n', encoding='utf-8')
(fixture/'.gitignore').write_text('web/node_modules/\n', encoding='utf-8')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=fixture, stderr=subprocess.PIPE).decode().strip()
git('init', '-q')
git('add', 'go.mod', 'doc.go', '.gitignore')
git('-c', 'user.name=Independent Audit', '-c', 'user.email=audit@example.invalid', 'commit', '-qm', 'Metadata fixture')
manifest = {'head': git('rev-parse', 'HEAD'), 'localChangedFiles': [], 'files': [
    {'path': p, 'gitBlob': git('hash-object', '--path', p, p)} for p in ['go.mod', 'doc.go', '.gitignore']]}
for relative, content in [('web/node_modules/visible/audit.go', 'package visible\n'), ('web/node_modules/.pnpm/example/audit.go', 'package example\n')]:
    path = fixture/relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')
script = repo/'docs/connector/evidence/LBT-147/2026-10-12-review-followup/reproduce.py'
namespace = {'__name__': 'external_guard_probe', '__file__': str(script)}
exec(compile(script.read_text(encoding='utf-8'), str(script), 'exec'), namespace)
namespace['verify_source'](fixture, manifest)
listed = subprocess.check_output(['go', 'list', './...'], cwd=fixture, stderr=subprocess.PIPE).decode().splitlines()
assert 'auditfixture/web/node_modules/visible' in listed
assert not any('.pnpm' in p for p in listed)
result = {'reproducerSHA256': hashlib.sha256(script.read_bytes()).hexdigest(), 'guard': 'ACCEPTED_UNAUDITED_VISIBLE_GO', 'goListPackages': listed, 'goTestCalls': 0, 'cloudCalls': 0, 'ignoredGo': git('ls-files', '--others', '--ignored', '--exclude-standard', '--', '*.go').splitlines()}
(out/'result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result))
