"""Read-only Evidence environment regression. All Go/cloud children are stubs."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import types
import zipfile

sys.dont_write_bytecode = True
repo = Path(sys.argv[1]).resolve(strict=True)
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
evidence = repo / 'docs/connector/evidence/LBT-147/2026-10-12-review-followup'
spec = importlib.util.spec_from_file_location('audited_reproducer', evidence / 'reproduce.py')
outer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(outer)
flags = outer.CLOUD_FLAGS
inherited = {name: '1' for name in flags}
inherited['PATH'] = os.environ.get('PATH', '')
inherited['AUDIT_UNRELATED_SENTINEL'] = 'preserved'
observations = []
for cloud in [False, True]:
    env = outer.reproduction_environment(repo, cloud=cloud, inherited=inherited)
    assert all(env[name] == '0' for name in flags)
    assert env['AUDIT_UNRELATED_SENTINEL'] == 'preserved'
    assert env['LABBIT_EVIDENCE_REPO'] == str(repo)
    assert all(inherited[name] == '1' for name in flags), 'Caller environment mutated'
    observations.append({'case': 'outer-cloud-selected' if cloud else 'outer-default', 'flags': {name: env[name] for name in flags}, 'result': 'PASS'})

# Confirm main uses the audited environment builder for actual child processes.
outer_tree = ast.parse((evidence / 'reproduce.py').read_text(encoding='utf-8'))
main = next(n for n in outer_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
assert any(isinstance(n, ast.Assign) and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name) and n.value.func.id == 'reproduction_environment' for n in ast.walk(main))
with zipfile.ZipFile(evidence / 'audit-logs.zip') as archive:
    portable_bytes = archive.read('portable_run.py')
portable = portable_bytes.decode('utf-8')
tree = ast.parse(portable)
assert isinstance(tree.body[-1], ast.Expr), 'Expected portable dispatch at final expression'
tree.body = tree.body[:-1]  # Do not run dispatch or any real tool.
os.environ['LABBIT_EVIDENCE_REPO'] = str(repo)
namespace = {'__file__': str(out / 'portable_run.py')}
exec(compile(tree, '<audited-portable-run>', 'exec'), namespace)
calls = []
def recording_run(command, **kwargs):
    effective = kwargs.get('env') or os.environ
    calls.append({'tool': command[0], 'commandPrefix': command[:4], 'flags': {name: effective.get(name) for name in flags}})
    return types.SimpleNamespace(returncode=0, stdout=b'', stderr=b'')
namespace['subprocess'] = types.SimpleNamespace(run=recording_run)
os.environ.update({name: '1' for name in flags})
namespace['auto']()
assert calls and all(all(value == '0' for value in call['flags'].values()) for call in calls)
observations.append({'case': 'direct-portable-auto', 'recordedChildren': calls.copy(), 'result': 'PASS'})
calls.clear()

# Parent explicit --cloud initializes all flags to 0; only cloud() opts in to
# its own M1/VMAccess/app/residual suites. No real process or config is read.
env = outer.reproduction_environment(repo, cloud=True, inherited=inherited)
env.update({'LABBIT_PROVIDER_CONFIG_FILE': 'audit-placeholder-config', 'LABBIT_OPENSTACK_SSH_PRIVATE_KEY_FILE': 'audit-placeholder-key', 'OS_CLOUD': 'audit-placeholder-cloud'})
os.environ.update(env)
namespace['cloud']()
enabled = {'LABBIT_OPENSTACK_INTEGRATION', 'LABBIT_OPENSTACK_VM_ACCESS_TEST', 'LABBIT_OPENSTACK_APP_AUDIT', 'LABBIT_OPENSTACK_RESIDUAL_AUDIT'}
assert len(calls) == 4
assert all(call['flags'][name] == ('1' if name in enabled else '0') for call in calls for name in flags)
observations.append({'case': 'explicit-cloud-selected', 'recordedChildren': calls.copy(), 'result': 'PASS'})
calls.clear()
os.environ.pop('LABBIT_PROVIDER_CONFIG_FILE', None)
try:
    namespace['cloud']()
except SystemExit as error:
    assert 'Missing explicit cloud input' in str(error)
else:
    raise AssertionError('Missing input accepted')
assert not calls
observations.append({'case': 'cloud-missing-input', 'result': 'PASS', 'childCalls': 0})
result = {
    'productionSourceModified': False, 'cloudMutationExecuted': False, 'GoExecuted': False,
    'parentReproducerSHA256': hashlib.sha256((evidence / 'reproduce.py').read_bytes()).hexdigest(),
    'portableRunnerSHA256': hashlib.sha256(portable_bytes).hexdigest(),
    'cases': observations, 'result': 'PASS',
    'limits': 'Outer environment builder plus AST wiring check and portable functions invoked with recording subprocess stubs; no actual CLI cloud run.'
}
(out / 'regression.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'result': result['result'], 'cases': len(observations), 'cloudMutationExecuted': False, 'GoExecuted': False, 'parentReproducerSHA256': result['parentReproducerSHA256'], 'portableRunnerSHA256': result['portableRunnerSHA256']}))
