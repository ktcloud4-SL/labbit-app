package vmaccess

import (
	"context"
	"errors"
	"testing"
	"time"

	"golang.org/x/crypto/ssh"
)

// Uses a real authenticated loopback SSH peer and I/O on existing channel A.
func TestIndependentReviewCanceledChannelOpenPreservesActivePeer(t *testing.T) {
	p := newSSHPeer(t)
	m := testManager(t, p, Config{IdleTimeout: 30 * time.Millisecond})
	a := openSession(t, m, testTarget())
	in, out := echoChannel(t, a, false)
	assertEcho(t, in, out)
	p.stallOpen.Store(true)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan error, 1)
	go func() {
		b, err := m.OpenSession(ctx, testTarget())
		if b != nil {
			_ = b.Close()
		}
		done <- err
	}()
	select {
	case <-p.heldOpen:
	case <-time.After(time.Second):
		t.Fatal("second channel open did not reach peer")
	}
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("cancel result: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("channel open cancel did not return promptly")
	}
	assertEcho(t, in, out)
	if p.accepted.Load() != 1 || p.active.Load() != 1 {
		t.Fatal("cancel closed or replaced A's shared transport")
	}
}

func TestIndependentReviewCanceledPTYSetupPreservesActivePeer(t *testing.T) {
	p := newSSHPeer(t)
	m := testManager(t, p, Config{IdleTimeout: 30 * time.Millisecond})
	a := openSession(t, m, testTarget())
	in, out := echoChannel(t, a, false)
	assertEcho(t, in, out)
	b := openSession(t, m, testTarget())
	p.stallRequest.Store(true)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan error, 1)
	go func() {
		done <- b.Setup(ctx, func(raw *ssh.Session) error { return raw.RequestPty("xterm", 24, 80, nil) })
	}()
	select {
	case request := <-p.heldRequest:
		if request != "pty-req" {
			t.Fatalf("unexpected request: %s", request)
		}
	case <-time.After(time.Second):
		t.Fatal("second channel setup did not reach peer")
	}
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("cancel result: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("channel setup cancel did not return promptly")
	}
	assertEcho(t, in, out)
	if p.accepted.Load() != 1 || p.active.Load() != 1 {
		t.Fatal("cancel closed or replaced A's shared transport")
	}
}
