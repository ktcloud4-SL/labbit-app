package openstackprovider

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"testing"
	"time"

	"github.com/gophercloud/gophercloud/v2/openstack/compute/v2/servers"
	"github.com/ktcloud4-SL/labbit-app/internal/connector/protocol"
	"github.com/ktcloud4-SL/labbit-app/internal/connector/terminal"
	"github.com/ktcloud4-SL/labbit-app/internal/connector/vmaccess"
	"github.com/ktcloud4-SL/labbit-app/internal/connector/wss"
)

func TestIndependentReviewProviderOutageControlClassification(t *testing.T) {
	for _, kind := range []string{"nova503", "neutron503", "targetMismatch"} {
		t.Run(kind, func(t *testing.T) {
			const raw = "private raw provider error must not reach Control"
			a := newTestAdapter(t, http.HandlerFunc(func(response http.ResponseWriter, request *http.Request) {
				switch request.URL.Path {
				case "/compute/v2/servers/server-1":
					if kind == "nova503" {
						http.Error(response, raw, 503)
						return
					}
					lab := "lab-1"
					if kind == "targetMismatch" {
						lab = "lab-other"
					}
					writeJSON(t, response, 200, map[string]any{"server": servers.Server{ID: "server-1", TenantID: "project-1", Status: "ACTIVE", Name: provisionBaseName(lab, 1) + "-workspace", Metadata: map[string]string{"labbit_lab_instance_id": lab, "labbit_generation": "1", "labbit_operation_id": "op-1", "labbit_vm_key": "workspace"}}})
				case "/network/v2.0/ports":
					http.Error(response, raw, 503)
				default:
					t.Errorf("unexpected API %s", request.URL.Path)
					response.WriteHeader(500)
				}
			}))
			a.provision.ProjectID, a.provision.ManagementNetworkID = "project-1", "management"
			manager := vmaccess.NewManager(a, vmaccess.Config{})
			defer manager.Close()
			var sent []any
			handler := wss.NewHandler(a, wss.SendMessageFunc(func(_ context.Context, message any) error { sent = append(sent, message); return nil }))
			handler.SetTerminalManager(terminal.NewSessionManager(time.Minute, nil), nil, terminal.DataWSSClientConfig{EndpointURL: "ws://localhost:1"})
			handler.SetVMPTYFactory(func(ctx context.Context, target vmaccess.Target, _, _ int) (terminal.PTYChannel, error) {
				channel, err := manager.OpenSession(ctx, target)
				if channel != nil {
					_ = channel.Close()
				}
				return nil, err
			})
			request := protocol.TerminalOpenMessage{BaseEnvelope: protocol.BaseEnvelope{Type: protocol.MessageTypeTerminalOpen, MessageID: "open-1", TerminalSessionID: "session-1", LabInstanceID: "lab-1", Generation: 1}, Payload: protocol.TerminalOpenPayload{TargetVmKey: "workspace", ProviderServerID: "server-1", Cols: 80, Rows: 24}}
			data, _ := json.Marshal(request)
			if err := handler.HandleMessage(context.Background(), data); err == nil {
				t.Fatal("failed Provider resolution was accepted")
			}
			if len(sent) != 1 {
				t.Fatalf("Control responses=%d", len(sent))
			}
			result, ok := sent[0].(protocol.TerminalOpenResultMessage)
			if !ok || result.Payload.Error == nil {
				t.Fatalf("unexpected Control result: %#v", sent[0])
			}
			want := protocol.TerminalErrAttachFailed
			if kind == "targetMismatch" {
				want = protocol.TerminalErrInvalidSession
			}
			if result.Payload.Error.Code != want {
				t.Fatalf("Control code=%s want=%s", result.Payload.Error.Code, want)
			}
			encoded, _ := json.Marshal(result)
			if strings.Contains(string(encoded), raw) {
				t.Fatal("raw Provider error reached Control")
			}
		})
	}
}
