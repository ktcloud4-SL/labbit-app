from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
REPO = Path(os.environ['LABBIT_EVIDENCE_REPO']).resolve(strict=True)
PYTHON = Path(sys.executable)
DEPS = Path(os.environ['LABBIT_EVIDENCE_DEPS']) if os.environ.get('LABBIT_EVIDENCE_DEPS') else None

def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode('utf-8').strip()

def snapshot():
    names = sorted(set(git('diff', '--name-only', 'origin/main...HEAD').splitlines()) | set(git('diff', '--name-only', 'HEAD').splitlines()) | set(git('ls-files', '--others', '--exclude-standard').splitlines()))
    changes = sorted(set(git('diff', '--name-only', 'HEAD').splitlines()) | set(git('ls-files', '--others', '--exclude-standard').splitlines()))
    files = []
    for name in names:
        p = REPO/name
        if not p.is_file(): continue
        files.append({'path':name, 'sha256Bytes':hashlib.sha256(p.read_bytes()).hexdigest(), 'gitBlob':git('hash-object','--path',name,name), 'localChange':name in changes})
        if name in changes:
            target = OUT/'source'/name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, target)
    (OUT/'working-tree.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'], cwd=REPO))
    save('source-manifest.json', {'recordedAt':datetime.now(timezone.utc).isoformat(),'head':git('rev-parse','HEAD'), 'originMain':git('rev-parse','origin/main'), 'mergeBase':git('merge-base','HEAD','origin/main'), 'executionSource':'HEAD plus listed local changes; byte SHA256 and Git blob identify tested bytes', 'files':files, 'localChangedFiles':changes})
    print(json.dumps({'snapshotFiles':len(files),'localFiles':len(changes)}))

def run(name, command, *, env=None, cwd=REPO, required=True):
    start = datetime.now(timezone.utc).isoformat()
    with (OUT/(name+'.log')).open('wb') as stdout, (OUT/(name+'.stderr.txt')).open('wb') as stderr:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
    record = {'command':command, 'startedAt':start, 'endedAt':datetime.now(timezone.utc).isoformat(), 'exitCode':result.returncode}
    save(name+'-run.json', record)
    print(json.dumps({'task':name,'exitCode':result.returncode}), flush=True)
    if required and result.returncode: raise SystemExit(result.returncode)
    return result.returncode

def auto():
    files = list(REPO.rglob('*.go'))
    files = [str(p.relative_to(REPO)) for p in files if 'node_modules' not in p.parts and 'vendor' not in p.parts and '.git' not in p.parts]
    fmt = subprocess.run(['gofmt','-l',*files],cwd=REPO,capture_output=True)
    (OUT/'gofmt.log').write_bytes(fmt.stdout+fmt.stderr)
    save('gofmt-run.json',{'exitCode':fmt.returncode,'filesChecked':len(files),'unformatted':fmt.stdout.decode('utf-8').splitlines()})
    if fmt.returncode or fmt.stdout.strip(): raise SystemExit('gofmt failed')
    run('go-vet',['go','vet','./...'])
    run('go-unit',['go','test','-json','-count=1','./...'])
    run('go-build',['go','build','./...'])
    run('go-race',['go','test','-race','-json','-count=1','./internal/connector/vmaccess','./internal/connector/provider/openstack','./internal/connector/app','./internal/connector/terminal','./internal/connector/wss'])
    run('regression-repeat',['go','test','-race','-json','-count=20','-run','TestCanceledChannelLeavesActivePTYUsable|TestCanceledOpenClosesLateChannelAndReusesTransport|TestStalledOpenDoesNotAccumulateCanceledSSHRequests|TestVMAccessProviderFailuresAndTargetMismatchControlCodes|TestLatestMainControlProviderAndTerminalShareRuntime|TestTerminalShutdownRejectsDelayedOpensAndEndsOnce|TestSupervisor_LifecycleAndReconnect','./internal/connector/vmaccess','./internal/connector/provider/openstack','./internal/connector/app','./internal/connector/terminal','./internal/connector/wss'])

def web():
    env = os.environ.copy()
    if DEPS: env['PATH'] = str(DEPS/'node/bin')+os.pathsep+env['PATH']
    pnpm = str(DEPS/'bin/fallback/pnpm.cmd') if DEPS else shutil.which('pnpm.cmd') or shutil.which('pnpm')
    if not pnpm: raise SystemExit('pnpm must be available in PATH')
    for name in ['typecheck','lint','test','build']:
        run('web-'+name,[pnpm,'run',name],env=env,cwd=REPO/'web')

def contracts():
    sys.path.insert(0, str(OUT/'validator-libs'))
    import yaml
    from openapi_spec_validator import validate
    validate(yaml.safe_load((REPO/'contracts/http/openapi.yaml').read_text(encoding='utf-8')))
    workflow = yaml.safe_load((REPO/'.github/workflows/contracts.yml').read_text(encoding='utf-8'))
    os.chdir(REPO)
    with (OUT/'contracts.log').open('w',encoding='utf-8') as log:
        previous=sys.stdout
        try:
            sys.stdout=log
            print('OpenAPI validation: OK')
            for step in workflow['jobs']['validate']['steps']:
                script = step.get('run','')
                if "python <<'PY'" in script:
                    exec(compile(script.split("python <<'PY'",1)[1].rsplit('\nPY',1)[0], '<contract-workflow>', 'exec'),{})
        finally: sys.stdout=previous
    save('contracts-run.json',{'exitCode':0,'scope':'OpenAPI + exact JSON Schema and Runtime/Migration Python from current workflow'})
    env = os.environ.copy()
    env['PYTHONPATH'] = str(OUT/'validator-libs')
    run('reset-schema',[str(PYTHON),str(REPO/'contracts/connector/tests/test_reset_schema.py'),'-v'],env=env)
    print('Contracts PASS',flush=True)

def cloud():
    # Harnesses are shipped beside this runner; no machine-local helper required.
    for name in ['LABBIT_PROVIDER_CONFIG_FILE','LABBIT_OPENSTACK_SSH_PRIVATE_KEY_FILE','OS_CLOUD']:
        if not os.environ.get(name): raise SystemExit('Missing explicit cloud input: '+name)
    app_overlay = OUT/'app-overlay.json'
    residual_overlay = OUT/'residual-overlay.json'
    save('app-overlay.json',{'Replace':{str(REPO/'internal/connector/app/lbt147_real_audit_test.go'):str(OUT/'app_real_integration_test.go')}})
    save('residual-overlay.json',{'Replace':{str(REPO/'internal/connector/provider/openstack/lbt147_residual_audit_test.go'):str(OUT/'read_only_residual_test.go')}})
    env=os.environ.copy()
    env.update({'LABBIT_OPENSTACK_SSH_USERNAME':'ubuntu','LABBIT_OPENSTACK_INTEGRATION':'1','LABBIT_OPENSTACK_MUTATION_TEST':'0','LABBIT_OPENSTACK_VM_ACCESS_TEST':'1','LABBIT_OPENSTACK_APP_AUDIT':'1','LABBIT_OPENSTACK_RESIDUAL_AUDIT':'1','LABBIT_OPENSTACK_TEST_IMAGE':'ubuntu','LABBIT_OPENSTACK_TEST_FLAVOR':'m1.small','LABBIT_OPENSTACK_TEST_MANAGEMENT_NETWORK':'sharednet1','LABBIT_OPENSTACK_TEST_SSH_CIDR':'172.16.8.1/32','LABBIT_OPENSTACK_TEST_LAB_CIDR':'198.20.0.0/24'})
    codes={}
    codes['pre']=run('pre-discovery',['go','test','-json','-count=1','-timeout=2m','-run','^TestOpenStackM1Integration$','./internal/connector/provider/openstack'],env=env,required=False)
    if codes['pre']:
        save('cloud-exit-codes.json',codes)
        raise SystemExit(codes['pre'])
    try:
        codes['vm']=run('real-vm-access',['go','test','-race','-json','-count=1','-timeout=18m','-run','^TestOpenStackVMAccessIntegration$','./internal/connector/provider/openstack'],env=env,required=False)
        if not codes['vm']:
            codes['app']=run('real-app-boundaries',['go','test','-race','-overlay',str(app_overlay),'-json','-count=1','-timeout=20m','-run','^TestLBT147RealAppBoundaries$','./internal/connector/app'],env=env,required=False)
    finally:
        codes['post']=run('post-discovery-and-residual',['go','test','-race','-overlay',str(residual_overlay),'-json','-count=1','-timeout=3m','-run','^(TestLBT147ReadOnlyResiduals|TestOpenStackM1Integration)$','./internal/connector/provider/openstack'],env=env,required=False)
        save('cloud-exit-codes.json',codes)
    if any(codes.values()) or 'app' not in codes: raise SystemExit('Cloud validation failed')

{'snapshot':snapshot,'auto':auto,'web':web,'contracts':contracts,'cloud':cloud}[sys.argv[1]]()
