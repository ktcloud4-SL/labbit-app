"""External Evidence source-guard regression: Go list only, no tests/cloud."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
repo = Path(sys.argv[1]).resolve(strict=True)
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
script = repo/'docs/connector/evidence/LBT-147/2026-10-12-review-followup/reproduce.py'
namespace = {'__name__':'external_guard_probe', '__file__':str(script)}
exec(compile(script.read_text(encoding='utf-8'), str(script), 'exec'), namespace)
prefix = 'docs/connector/evidence/LBT-147/2026-10-12-review-followup/'
results = []
for label, files, refusal in [
    ('documentation-only', [('README.md','audited documentation\n')], False),
    ('hidden-fixture', [('_fixtures/audit.go','package fixture\n')], False),
    ('visible-Go', [('visible/audit.go','package visible\n')], True),
    ('Evidence-module', [('visible/go.mod','module unaudited\n\ngo 1.27.0\n')], True),
    ('Evidence-sum', [('visible/go.sum','unaudited placeholder\n')], True),
]:
    fixture = out/label
    fixture.mkdir()
    (fixture/'go.mod').write_text('module auditfixture\n\ngo 1.27.0\n', encoding='utf-8')
    (fixture/'doc.go').write_text('package auditfixture\n', encoding='utf-8')
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=fixture, stderr=subprocess.PIPE).decode().strip()
    git('init','-q')
    git('add','go.mod','doc.go')
    git('-c','user.name=Independent Audit','-c','user.email=audit@example.invalid','commit','-qm','Metadata fixture')
    manifest = {'head':git('rev-parse','HEAD'),'localChangedFiles':[],'files':[{'path':p,'gitBlob':git('hash-object','--path',p,p)} for p in ['go.mod','doc.go']]}
    for relative, content in files:
        path = fixture/prefix/relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
    rejected = False
    try:
        namespace['verify_source'](fixture,manifest)
    except ValueError:
        rejected = True
    assert rejected == refusal, (label,rejected,refusal)
    listed = subprocess.check_output(['go','list','./...'],cwd=fixture,stderr=subprocess.PIPE).decode().splitlines()
    if label == 'hidden-fixture':
        assert listed == ['auditfixture']
    if label == 'visible-Go':
        assert 'auditfixture/'+prefix+'visible' in listed
    results.append({'case':label,'rejected':rejected,'goList':listed,'result':'PASS'})
for label, extra, missing, changed in [('complete',False,False,False),('extra',True,False,False),('missing',False,True,False),('changed',False,False,True)]:
    artifact_dir = out/('artifacts-'+label)
    artifact_dir.mkdir()
    data = b'pinned artifact\n'
    checksums = {'artifacts':[{'file':'README.md','sha256':hashlib.sha256(data).hexdigest()}]}
    if not missing:
        (artifact_dir/'README.md').write_bytes(b'changed\n' if changed else data)
    (artifact_dir/'artifact-checksums.json').write_text(json.dumps(checksums),encoding='utf-8')
    cache = artifact_dir/'__pycache__'/'ignored.pyc'
    cache.parent.mkdir()
    cache.write_bytes(b'transient cache')
    if extra:
        (artifact_dir/'extra.go').write_text('package extra\n',encoding='utf-8')
    rejected = False
    try:
        namespace['verify_artifacts'](artifact_dir,checksums)
    except ValueError:
        rejected = True
    assert rejected == (extra or missing or changed), (label,rejected)
    results.append({'case':'artifact-'+label,'rejected':rejected,'result':'PASS'})
result = {'reproducerSHA256':hashlib.sha256(script.read_bytes()).hexdigest(),'result':'PASS','cases':results,'goTestCalls':0,'cloudCalls':0}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
