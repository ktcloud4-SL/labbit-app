"""Isolated source and Evidence guard regressions; no Go test or cloud mutation."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
REPO = OUT.parent/'labbit-vm-access-147'
EVIDENCE = Path('docs/connector/evidence/LBT-147/2026-10-12-review-followup')
CLONE = OUT/'guard-clone-final-v3'
if CLONE.exists():
    raise SystemExit('Use a fresh guard-clone path; preserving previous output')
subprocess.run(['git', 'clone', '--quiet', '--no-hardlinks', str(REPO), str(CLONE)], check=True)
manifest = json.loads((REPO/EVIDENCE/'source-manifest.json').read_text(encoding='utf-8'))
spec = importlib.util.spec_from_file_location('audit_reproducer', REPO/EVIDENCE/'reproduce.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
results = []

def check(name, expect_failure, kind='source'):
    try:
        if kind == 'source':
            module.verify_source(CLONE, manifest)
        else:
            module.verify_artifacts(artifact_dir, checksums)
        failed, message = False, 'PASS'
    except ValueError as error:
        failed, message = True, str(error)
    if failed != expect_failure:
        raise AssertionError(name+': unexpected guard outcome')
    results.append({'case': name, 'kind': kind, 'expectedRefusal': expect_failure,
                    'actualRefusal': failed, 'message': message})

check('complete pinned source', False)
dependency = CLONE/'web/node_modules/.pnpm/audit-example/node_modules/example/fixture.go'
dependency.parent.mkdir(parents=True, exist_ok=True)
dependency.write_text('package example\n', encoding='utf-8')
check('non-executable npm dependency Go example', False)
visible = CLONE/'web/node_modules/visible/audit.go'
visible.parent.mkdir(parents=True, exist_ok=True)
try:
    visible.write_text('package visible\n', encoding='utf-8')
    check('executable visible npm Go package', True)
finally:
    visible.unlink()
for name, target in [('changed audited local file', 'internal/connector/vmaccess/access.go'),
                     ('changed unrelated tracked consumer', 'internal/connector/terminal/client.go')]:
    p = CLONE/target
    original = p.read_bytes()
    try:
        p.write_bytes(original+b'\n// guard fault\n')
        check(name, True)
    finally:
        p.write_bytes(original)
p = CLONE/'internal/connector/vmaccess/guard_untracked.go'
try:
    p.write_text('package vmaccess\n', encoding='utf-8')
    check('untracked executable source', True)
finally:
    p.unlink()
exclude = CLONE/'.git/info/exclude'
original = exclude.read_bytes()
p = CLONE/'internal/connector/vmaccess/guard_ignored.go'
try:
    exclude.write_bytes(original+b'\ninternal/connector/vmaccess/guard_ignored.go\n')
    p.write_text('package vmaccess\n', encoding='utf-8')
    check('ignored executable source', True)
finally:
    p.unlink()
    exclude.write_bytes(original)
p = CLONE/'internal/connector/provider/openstack/terminal_error_test.go'
original = p.read_bytes()
try:
    p.unlink()
    check('missing pinned file', True)
finally:
    p.write_bytes(original)
check('restored source', False)
for filename in ['audit.go', 'go.mod', 'go.sum']:
    p = CLONE/EVIDENCE/'visible'/filename
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        p.write_text('package evidence\n' if filename.endswith('.go') else 'guard fixture\n', encoding='utf-8')
        check('Evidence executable '+filename+' rejected', True)
    finally:
        p.unlink()
p = CLONE/EVIDENCE/'_fixtures/independent_unacked_setup_test.go'
p.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(REPO/EVIDENCE/'_fixtures/independent_unacked_setup_test.go', p)
check('existing hidden Evidence Go fixture allowed', False)
p = CLONE/EVIDENCE/'notes.md'
try:
    p.write_text('documentation only\n', encoding='utf-8')
    check('Evidence documentation allowed by source guard', False)
finally:
    p.unlink()

artifact_dir = OUT/'guard-artifacts-final-v3'
artifact_dir.mkdir()
(artifact_dir/'_fixtures').mkdir()
(artifact_dir/'_fixtures/fixture.go').write_text('package fixture\n', encoding='utf-8')
(artifact_dir/'README.md').write_text('audited docs\n', encoding='utf-8')
(artifact_dir/'artifact-checksums.json').write_text('{}\n', encoding='utf-8')
checksums = {'artifacts': [{'file': p.relative_to(artifact_dir).as_posix(),
                          'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                         for p in sorted(artifact_dir.rglob('*'))
                         if p.is_file() and p.name != 'artifact-checksums.json']}
check('pinned artifact set including hidden fixture allowed', False, 'artifact')
for name in ['notes.md', '_fixtures/unaudited.go']:
    p = artifact_dir/name
    try:
        p.write_text('unexpected artifact\n', encoding='utf-8')
        check('extra artifact '+name+' rejected', True, 'artifact')
    finally:
        p.unlink()
p = artifact_dir/'README.md'
original = p.read_bytes()
try:
    p.unlink()
    check('missing artifact rejected', True, 'artifact')
    p.write_bytes(original+b'changed\n')
    check('changed artifact rejected', True, 'artifact')
finally:
    p.write_bytes(original)
cache = artifact_dir/'__pycache__/reproduce.pyc'
cache.parent.mkdir()
cache.write_bytes(b'generated cache')
check('generated ignored Python cache allowed', False, 'artifact')
check('restored artifact set allowed', False, 'artifact')
record = {'helperSha256': hashlib.sha256((REPO/EVIDENCE/'reproduce.py').read_bytes()).hexdigest(),
          'goInvocations': 0, 'cloudMutations': 0, 'sourceCases': 14,
          'artifactCases': 7, 'cases': results}
(OUT/'reproduce-guard-regression-v3.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'guardCases': len(results), 'passed': len(results), 'goInvocations': 0, 'cloudMutations': 0}))
