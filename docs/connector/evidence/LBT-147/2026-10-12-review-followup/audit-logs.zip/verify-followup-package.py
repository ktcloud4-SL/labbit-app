"""Read-only check of source mapping, Evidence checksums and archive entries."""
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

repo = Path(sys.argv[1]).resolve(strict=True)
out = Path(sys.argv[2]).resolve()
evidence = repo / 'docs/connector/evidence/LBT-147/2026-10-12-review-followup'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
result = {'errors': [], 'sourceFiles': 0, 'artifacts': 0, 'archiveEntries': 0, 'rawGoCounts': {}, 'mappedCommit': sys.argv[3]}
manifest = read(evidence / 'source-manifest.json')
for item in manifest['files']:
    path = repo / item['path']
    if sha(path.read_bytes()) != item['sha256Bytes']:
        result['errors'].append('source byte ' + item['path'])
    blob = subprocess.check_output(['git', 'rev-parse', sys.argv[3] + ':' + item['path']], cwd=repo).decode().strip()
    if blob != item['gitBlob']:
        result['errors'].append('commit blob ' + item['path'])
    result['sourceFiles'] += 1
checks = read(evidence / 'artifact-checksums.json')
expected_files = {item['file'] for item in checks['artifacts']}
tracked_files = set(subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '--', str(evidence.relative_to(repo))], cwd=repo).decode('utf-8').splitlines())
relative_set = {str(Path(name).relative_to(evidence.relative_to(repo))).replace('\\', '/') for name in tracked_files}
if relative_set != expected_files | {'artifact-checksums.json'}:
    result['errors'].append({'artifactSet': sorted(relative_set ^ (expected_files | {'artifact-checksums.json'}))})
for item in checks['artifacts']:
    data = (evidence / item['file']).read_bytes()
    if sha(data) != item['sha256'] or ('bytes' in item and len(data) != item['bytes']):
        result['errors'].append('artifact ' + item['file'])
    result['artifacts'] += 1
entries = read(evidence / 'archive-manifest.json')['entries']
with zipfile.ZipFile(evidence / 'audit-logs.zip') as archive:
    names = archive.namelist()
    if len(set(names)) != len(names):
        result['errors'].append('duplicate ZIP paths')
    if archive.testzip() is not None:
        result['errors'].append('ZIP CRC')
    expected_entries = {item.get('path', item.get('entry')) for item in entries}
    if set(names) != expected_entries:
        result['errors'].append({'archiveSet': sorted(set(names) ^ expected_entries)})
    for item in entries:
        name = item.get('path', item.get('entry'))
        data = archive.read(name)
        if sha(data) != item['sha256'] or len(data) != item['bytes']:
            result['errors'].append('ZIP entry ' + name)
        result['archiveEntries'] += 1
        if name.startswith('source/'):
            original = next((file for file in manifest['files'] if file['path'] == name[len('source/'):]), None)
            if original is None or sha(data) != original['sha256Bytes']:
                result['errors'].append('archived source snapshot ' + name)
        if name.endswith(('.jsonl', '.log')) and data[:1] == b'{':
            counts = collections.Counter()
            bad = 0
            for line in data.decode('utf-8-sig').splitlines():
                try:
                    event = json.loads(line)
                except ValueError:
                    bad += 1
                    continue
                if event.get('Test') and event.get('Action') in ('pass', 'fail', 'skip'):
                    counts[event['Action']] += 1
            result['rawGoCounts'][name] = {'counts': dict(counts), 'unparsedLines': bad}
fixture_manifest = read(evidence / '_fixtures/dependency-fixture-manifest.json')
for item in fixture_manifest['fixtures']:
    if sha((evidence / '_fixtures' / item['path']).read_bytes()) != item['sha256']:
        result['errors'].append('dependency fixture ' + item['path'])
summary = read(evidence / 'validation-summary.json')
for prefix, scope in [('', summary['runs']), ('latest-check/', summary['latestVerification']['runs'])]:
    for label, fields in [('go-unit', {'pass': 'pass_tests', 'skip': 'skip_tests'}), ('go-race', {'pass': 'pass_tests', 'skip': 'skip_tests'}), ('regression-repeat', {'pass': 'pass_tests'})]:
        raw = result['rawGoCounts'][prefix + label + '.log']['counts']
        reported = scope[label]['counts']
        for action, key in fields.items():
            if raw.get(action, 0) != reported.get(key, 0):
                result['errors'].append('raw summary count ' + prefix + label + ':' + action)
        if raw.get('fail', 0):
            result['errors'].append('latest raw failure ' + prefix + label)
for label in ['pre-discovery', 'real-vm-access', 'real-app-boundaries', 'post-discovery-and-residual']:
    raw = result['rawGoCounts'][label + '.log']['counts']
    if raw.get('pass', 0) != summary['runs'][label]['counts']['pass_tests'] or raw.get('fail', 0) or raw.get('skip', 0):
        result['errors'].append('cloud raw summary ' + label)
result['summaryCounts'] = 'PASS' if not any(str(item).startswith(('raw summary', 'latest raw', 'cloud raw')) for item in result['errors']) else 'FAIL'
result['result'] = 'PASS' if not result['errors'] else 'FAIL'
out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: value for k, value in result.items() if k != 'rawGoCounts'}, indent=2))
if result['errors']:
    raise SystemExit(1)
