import collections
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
read_json = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
result = {'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sourceChecks': {}, 'goLogs': {}, 'commandResults': {}, 'localFiles': {}}
manifest = read_json(root / 'reviewer-executed-source-manifest.json')
byte_errors, blob_errors = [], []
for file in manifest['files']:
    path = repo / file['path']
    if sha(path) != file['sha256Bytes']:
        byte_errors.append(file['path'])
    blob = subprocess.check_output(['git', 'hash-object', '--path', file['path'], file['path']], cwd=repo).decode().strip()
    if blob != file['gitBlob']:
        blob_errors.append(file['path'])
result['sourceChecks'] = {
    'listed': len(manifest['files']), 'byteMismatches': byte_errors, 'gitBlobMismatches': blob_errors,
    'HEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
    'originMain': subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=repo).decode().strip(),
    'GoAndRuntime': sum(not f['path'].startswith('docs/') for f in manifest['files']),
    'localGoChanges': len(manifest['localChangedFiles']),
    'unchangedSource': sum(not f['path'].startswith('docs/') and not f['localChange'] for f in manifest['files']),
}
logs = ['go-unit.log', 'go-race.log', 'regression-repeat.log', 'real-vm-access.log', 'real-app-boundaries.log', 'pre-discovery.log', 'post-discovery-and-residual.log', 'independent-before-r1.jsonl', 'independent-after-r1.jsonl', 'independent-before-r2.jsonl', 'independent-after-r2.jsonl', 'independent-before-r3.jsonl', 'independent-after-r3.jsonl', 'independent-after-unacked-setup-copy.jsonl', 'portable-unacked-run/test.jsonl', 'portable-unacked-ps5-run/test.jsonl', 'portable-unacked-ps7-final-run/test.jsonl']
for name in logs:
    path = root / name
    if not path.exists():
        continue
    counts, skips, failures, package_failures, elapsed = collections.Counter(), [], [], [], {}
    invalid = 0
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            invalid += 1
            continue
        action, test = event.get('Action'), event.get('Test')
        if test and action in ('pass', 'fail', 'skip'):
            counts[action] += 1
            if action == 'skip': skips.append({'package': event['Package'], 'test': test})
            if action == 'fail': failures.append(test)
            if action == 'pass': elapsed[test] = event.get('Elapsed')
        elif not test and action == 'fail':
            package_failures.append(event.get('Package'))
    result['goLogs'][name] = {'sha256': sha(path), 'counts': dict(counts), 'skips': skips, 'testFailures': failures, 'packageFailures': package_failures, 'invalidLines': invalid}
    if name.startswith('real-'):
        result['goLogs'][name]['elapsed'] = elapsed
for path in root.glob('*-run.json'):
    result['commandResults'][path.name] = read_json(path).get('exitCode')
for name in ['app_real_integration_test.go', 'read_only_residual_test.go', 'reproduce-independent-unacked.ps1', 'independent_unacked_setup_test.go', 'ssh-channel-no-b-close-ack.go', 'dependency-fixture-manifest.json', 'reviewer-executed-source-manifest.json']:
    path = root / name
    result['localFiles'][name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
(root / 'reviewer-verification.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
if byte_errors or blob_errors:
    raise SystemExit(1)
