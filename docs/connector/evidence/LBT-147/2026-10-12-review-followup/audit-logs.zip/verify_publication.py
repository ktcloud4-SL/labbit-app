from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import sys
import zipfile

OUT=Path(__file__).resolve().parent
REPO=OUT.parent/'labbit-vm-access-147'
DEST=REPO/'docs/connector/evidence/LBT-147/2026-10-12-review-followup'
def save(name,value):
    (DEST/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO,stderr=subprocess.PIPE).decode('utf-8').strip()
manifest=json.loads((DEST/'source-manifest.json').read_text(encoding='utf-8'))
source_errors=[]
for item in manifest['files']:
    if hashlib.sha256((REPO/item['path']).read_bytes()).hexdigest()!=item['sha256Bytes'] or git('hash-object','--path',item['path'],item['path'])!=item['gitBlob']:
        source_errors.append(item['path'])
if source_errors:raise SystemExit('Tested source identity mismatch')
entry_manifest=json.loads((DEST/'archive-manifest.json').read_text(encoding='utf-8'))['entries']
with zipfile.ZipFile(DEST/'audit-logs.zip') as archive:
    if archive.testzip() is not None:raise SystemExit('Archive CRC failed')
    if set(archive.namelist())!={x['path'] for x in entry_manifest}:raise SystemExit('Archive entry set mismatch')
    for item in entry_manifest:
        data=archive.read(item['path'])
        if hashlib.sha256(data).hexdigest()!=item['sha256'] or len(data)!=item['bytes']:raise SystemExit('Archive entry identity mismatch')
    for name in ['portable_run.py','reproduce.py']:
        compile(archive.read(name),name,'exec')
compile((DEST/'reproduce.py').read_bytes(),'reproduce.py','exec')

# Known values are read only inside the scanner; values and configuration aren't emitted.
sys.path.insert(0,str(OUT/'validator-libs'))
import yaml
config=Path('C:/Users/user/.config/openstack/clouds.yaml')
private_key=Path('C:/Users/user/.ssh/dandelion.pem')
known=[]
def secrets(value):
    if isinstance(value,dict):
        for key,item in value.items():
            if re.search(r'(password|secret|token)$',str(key),re.I) and isinstance(item,str) and len(item)>=8:
                known.append(item.encode('utf-8'))
            else:secrets(item)
    elif isinstance(value,list):
        for item in value:secrets(item)
secrets(yaml.safe_load(config.read_text(encoding='utf-8')))
key=private_key.read_bytes()
known += [key,key.replace(b'\r\n',b'\n'),b''.join(line for line in key.splitlines() if not line.startswith(b'-----'))]
patterns=[('private-key-body',re.compile(rb'-----BEGIN (?:OPENSSH |RSA |EC |DSA |ENCRYPTED )?PRIVATE KEY-----\r?\n[A-Za-z0-9+/=]{32,}')),
          ('known-token-prefix',re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|sk-(?:proj-)?[A-Za-z0-9_-]{40,})'))]
findings=[];scanned=0
def scan(data,label,depth=0):
    global scanned
    scanned+=1
    if any(value and value in data for value in known):findings.append({'path':label,'kind':'known-local-secret'})
    for name,pattern in patterns:
        if pattern.search(data):findings.append({'path':label,'kind':name})
    if data.startswith(b'PK\x03\x04') and depth<5:
        import io
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for name in archive.namelist():scan(archive.read(name),label+'!/'+name,depth+1)
for folder in [DEST,REPO/'docs/connector/evidence/LBT-147/2026-10-10',REPO/'docs/connector/evidence/LBT-147/2026-10-12']:
    for path in sorted(folder.rglob('*')):
        if path.is_file():scan(path.read_bytes(),path.relative_to(REPO).as_posix())
if findings:raise SystemExit(json.dumps({'secretFindings':findings}))
save('secret-scan.json',{'checkedAt':datetime.now(timezone.utc).isoformat(),'filesAndNestedEntriesScanned':scanned,'findings':0,'knownValueCount':len(known),'scope':'new and historical LBT-147 Evidence, nested ZIP entries; local cloud secret/private-key values + known token/PEM patterns','limitations':'Does not prove absence of unknown secrets or scan all Git history; secret values not emitted'})
save('publication-checks.json',{'checkedAt':datetime.now(timezone.utc).isoformat(),'sourceFiles':len(manifest['files']),'byteAndGitBlobMismatches':0,'archiveEntries':len(entry_manifest),'archiveCRC':'PASS','archiveEntrySetHashSize':'PASS','pythonSyntax':'PASS','sourceGuardCases':9,'goAndCloudInvocationsInGuard':0,'secretFindings':0,'latestAutomaticRerun':'validation-summary.json latestVerification','postCloudSourceIdentity':'unchanged; new bytes actually tested, historical original preserved','powershellHelperSyntax':'PASS (Parser.ParseFile)','appAndResidualHarnessRaceCompile':'PASS (no selected tests, no cloud mutations)'})
artifacts=[]
for path in sorted(DEST.rglob('*')):
    if path.is_file() and path.name!='artifact-checksums.json':
        if '__pycache__' in path.parts or path.suffix=='.pyc':continue
        data=path.read_bytes();artifacts.append({'file':path.relative_to(DEST).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
save('artifact-checksums.json',{'artifacts':artifacts})
print(json.dumps({'sourceFiles':len(manifest['files']),'archiveEntries':len(entry_manifest),'sourceMismatches':0,'artifactFiles':len(artifacts),'scanItems':scanned,'secretFindings':0}))
