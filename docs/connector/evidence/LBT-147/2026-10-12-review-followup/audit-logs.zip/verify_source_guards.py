"""Isolated source guard regressions; no Go test or cloud mutation."""
from pathlib import Path
import importlib.util
import json
import shutil
import subprocess

OUT=Path(__file__).resolve().parent
REPO=OUT.parent/'labbit-vm-access-147'
CLONE=OUT/'guard-clone-final-v2'
if CLONE.exists():
    raise SystemExit('Use a fresh guard-clone path; preserving previous output')
subprocess.run(['git','clone','--quiet','--no-hardlinks',str(REPO),str(CLONE)],check=True)
manifest=json.loads((OUT/'source-manifest.json').read_text(encoding='utf-8'))
for name in manifest['localChangedFiles']:
    target=CLONE/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(OUT/'source'/name,target)
spec=importlib.util.spec_from_file_location('audit_reproducer',OUT/'reproduce.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
results=[]
def check(name,expect_failure):
    try:
        module.verify_source(CLONE,manifest)
        failed=False;message='PASS'
    except ValueError as error:
        failed=True;message=str(error)
    if failed != expect_failure:
        raise AssertionError(name+': unexpected guard outcome')
    results.append({'case':name,'expectedRefusal':expect_failure,'actualRefusal':failed,'message':message})
check('complete pinned source',False)
dependency=CLONE/'web/node_modules/.pnpm/audit-example/node_modules/example/fixture.go'
dependency.parent.mkdir(parents=True,exist_ok=True)
dependency.write_text('package example\n',encoding='utf-8')
check('non-executable npm dependency Go example',False)
visible=CLONE/'web/node_modules/visible/audit.go'
visible.parent.mkdir(parents=True,exist_ok=True)
try:
    visible.write_text('package visible\n',encoding='utf-8')
    check('executable visible npm Go package',True)
finally:visible.unlink()
for name,target in [('changed audited local file','internal/connector/vmaccess/access.go'),('changed unrelated tracked consumer','internal/connector/terminal/client.go')]:
    p=CLONE/target;original=p.read_bytes()
    try:
        p.write_bytes(original+b'\n// guard fault\n');check(name,True)
    finally:p.write_bytes(original)
p=CLONE/'internal/connector/vmaccess/guard_untracked.go'
try:
    p.write_text('package vmaccess\n',encoding='utf-8');check('untracked executable source',True)
finally:p.unlink()
exclude=CLONE/'.git/info/exclude';original=exclude.read_bytes()
p=CLONE/'internal/connector/vmaccess/guard_ignored.go'
try:
    exclude.write_bytes(original+b'\n/ internal-invalid-line\ninternal/connector/vmaccess/guard_ignored.go\n')
    p.write_text('package vmaccess\n',encoding='utf-8');check('ignored executable source',True)
finally:
    p.unlink();exclude.write_bytes(original)
p=CLONE/'internal/connector/provider/openstack/terminal_error_test.go';original=p.read_bytes()
try:
    p.unlink();check('missing pinned file',True)
finally:p.write_bytes(original)
check('restored source',False)
(OUT/'reproduce-guard-regression.json').write_text(json.dumps({'goInvocations':0,'cloudMutations':0,'cases':results},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'guardCases':len(results),'passed':len(results),'goInvocations':0,'cloudMutations':0}))
