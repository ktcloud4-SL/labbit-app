# LBT-147 수정 후 독립 리뷰

2026-10-12 KST. 구현하지 않은 reviewer sub-agent가 기존 P1/P2 수정과 전체 base → 현재 working tree를 검토했다. **수정된 범위에서 확인된 추가 결함 없음. F-001(P1), F-002(P2)은 코드·자동 회귀·기존 외부 재현으로 해결을 확인했다.** 전체 PR 준비 최종 판정은 root의 모든 기본 검증/최종 source hash/잔여 범위 기록과 함께 한다. 원격 push·PR·Jira·외부 메시지 작업은 하지 않았다.

## 버전과 검토 방식

- Repo: C:/Users/user/Documents/ChatGPT/3차 2/tmp/labbit-vm-access-147
- Base origin/main: 6d675c74bff11f481d247267faefd4ce960dcd38
- HEAD: 399681789572487bd44469ec018e52b53f97678e (수정 미커밋)
- 전체 범위: original base→HEAD 26개 파일 + 기존 base와 같았던 runtime_provider_test.go/lifecycle_test.go 변경 2개 + 새 untracked vm_access_lifecycle_test.go 1개 = **고유 29개 파일**.
- 수정 working tree: production 2개, tests 4개 = 6개. 수정 시점 SHA256은 [reviewer-source.json](reviewer-source.json)에 고정했다. production file hash: runtime_provider.go 8483d8952eecd874668470e680fdbfb665735d997a785d31483b573c2b9b2815, vm_access.go b6081db85cb78150155d1745b0e068a80eee73479bb6ea22307bf07ff7df5cd7.
- workspace PRE_MERGE_AUDIT.md와 repo AGENTS/CONTRIBUTING/TESTING은 앞선 독립 리뷰에서 읽었으며 적용을 유지했다. 최초 독립 리뷰의 26파일 기록과 최초 findings는 [independent-review.md](../lbt147-independent-audit/independent-review.md)에 있다.
- 현재 수정 전체 diff 6개를 새로 읽고, 원래 26개 중 변경된 3개(runtime_provider.go, vm_access.go, vm_access_test.go)의 영향을 다시 검토했다. 그대로인 원래 23개는 이전 full diff 검토와 source identity를 이어 사용했다. 관련 기존 Provider lifecycle/provision 결과 생성, lazy provider callers, WSS Supervisor reconnect/reader, VMAccess OpenSession/Setup/InvalidateBefore, Terminal SessionManager/managed PTY 소비를 다시 확인했다.
- root가 직접 조회한 최신 원문 snapshot을 읽었다: Jira LBT-147 2026-10-07, D-18 v5, D-20 v7, D-21 v10, MVP 계획 v19, 테스트 전략 v3. reviewer가 원격 원문을 별도로 다시 조회했다고 주장하지 않는다.

## Findings 해결 상태

| ID | 수정과 요구 근거 | 확인한 회귀/producer 경계 | 독립 결과 |
| --- | --- | --- | --- |
| F-001/P1 | app/vm_access.go:59-94가 outcome만 보지 않고 lifecycleInvalidatesAccess로 판정. FAILED+no resources 또는 전부 DELETE_NOT_ATTEMPTED만 preflight/검증 무변경으로 보존하고, 다른 상태·첫 DELETE_FAILED·UNKNOWN/Go error/SUCCEEDED는 보수적으로 old transport를 retire/fence. D-20의 FAILED 부분 실패와 LBT-147 stale 대상 거절을 유지. | TestFailedLifecycleClosesOldChannelsAndPreservesPreflight: partial Delete, first rejection, old cleanup 뒤 replacement 실패, no-resource validation 실패, untouched preflight를 실제 in-process SSH active channel/old reopen/다른 Lab 보존으로 검증. TestFailedLifecycleRejectsDelayedOldResolutionAndSetup: mutation 후 늦은 resolve/Setup 성공 거절. OpenStack TestCleanupPartialDeleteRejectionReportsDestructiveFailure는 실제 Adapter+HTTP peer가 DELETED/DELETE_FAILED/DELETE_NOT_ATTEMPTED FAILED를 보고하고 후속 delete를 중단하며 raw error를 차단함을 검증. | 기존 외부 partial Reset/Cleanup old-channel 재현 PASS로 전환. 최신 app+Provider 회귀 독립 PASS. 해결 확인. |
| F-002/P2 | runtime_provider.go:56-101에서 mutex 밖 owner factory 실행, 한 in-flight attempt/result/completion 공유, waiter context-aware select. ctx.Err을 cache 진입·완료 후 확인; owner context만 init에 전달; 실패/nil/ConnectionID mismatch는 safe error로 공유 후 다음 요청에서 재시도. | TestLazyProvider_WaitingVMResolutionHonorsContext의 deadline/cancel waiter 즉시 반환·owner/다른 waiter 유지·cached 재사용; VMSetupTimeout 40ms 테스트; failed(error/nil/ID mismatch) result 공유와 다음 retry; owner cancel→waiters safe error/다음 retry; already canceled uninitialized/cached 요청이 Provider를 사용하지 않음. | 기존 외부 VM 40ms setup 대기 재현 PASS로 전환. 새 회귀 10회 반복 PASS. 해결 확인. |

순수 preflight 실패의 기존 transport 보존과 destructive stage의 첫 명백한 delete 거절도 retire하는 보수적 정책을 구분해 검토했다. 외부 operation/wire 결과 의미를 바꾸지 않고, 새로운 SafeError code·field·영속 상태를 추가하지 않았다. helper는 current Provider가 mutation/부분 실패 resources를 보고하고 preflight에서 DELETE_NOT_ATTEMPTED를 보고하는 실제 producer 의미에 의존한다.

F1 fixture가 처음 동일 Server ID로 상반된 상태를 표현하던 점은 root에 개선을 제안했다. root가 index별 ID/VM label, 남아 있는 gen1 workspace server-2, replacement의 old2 DELETED+newgen ACTIVE로 고쳤고 최신 형태를 재검토했다. 이 항목은 production defect가 아니었으며 해결된 test realism 제안이다.

## 추가된 diff coverage

| 파일 | 새 검토 범위 |
| --- | --- |
| internal/connector/app/vm_access.go | F1 helper와 Reset/Cleanup generation fencing, preflight 보존, result unchanged 반환, query affinity 기존 의미 |
| internal/connector/app/runtime_provider.go | F2 single-init ownership/result, lock duration, cancellation/data publication, all Query/Resolver/Mutation callers, safe error/retry |
| internal/connector/app/vm_access_test.go | outcome/state 회귀 branch와 runtime duration 기존 테스트 |
| internal/connector/app/runtime_provider_test.go | 전체 초기화 regression, context synchronization fixture, no dependent retry/leak/raw error, cached canceled requests |
| internal/connector/app/vm_access_lifecycle_test.go | 새 전체 파일; authenticated TCP/SSH peer cleanup/worker tracking, active transport 종료·다른 Lab 보존, delayed resolve/Setup |
| internal/connector/provider/openstack/lifecycle_test.go | 새 partial rejected Delete regression 및 실제 producer 상태·mutations중단·safe error |

나머지 23개의 원래 full diff coverage는 이전 독립 report에 상세히 기록했다. 새로 미검토한 diff 파일 없음. wire/HTTP/DB/schema/dependency/runtime 정책 수정 없음은 전체 changed list로 대조했다.

## 실패·동시성·보안 분석

- Initial auth 실패·nil Provider·다른 ProviderConnectionID는 모든 해당 attempt waiters에게 safe sentinel로 전달하고 Provider mutation을 실행하지 않는다. 실패 완료 뒤 새 request만 새 초기화를 시작한다.
- Waiter timeout/cancel은 공유 attempt를 해제/취소하지 않는다. owner context 취소는 실제 factory로 전파되고 실패 attempt 완료 후 다른 waiters가 해제되며 다음 request가 다시 초기화할 수 있다.
- attempt.provider/err는 done close 전에 기록되고 waiters는 채널 receive 뒤 읽으므로 publication happens-before가 성립한다. 성공 cache와 초기화 pointer 변경은 mutex 아래이며 factory 중에는 lock을 소유하지 않는다. 이전 failed attempt를 가진 waiter가 다음 attempt 결과와 섞이지 않는다.
- Completion과 cancel이 동시에 관찰될 때 final ctx.Err 확인으로 canceled waiter가 initialized Provider로 진행하지 않는다. 이미 canceled ctx는 uninitialized/cached 모두 factory/Resolver를 호출하지 않는다.
- F1은 해당 LabInstance의 old generation만 fence하고 다른 Lab transport를 건드리지 않는다. delayed resolution은 fence 재검사에서 dial 전에 거절되고 delayed Setup은 완료 후 권위 상태 재검사에서 거절된다.
- 기존 정상 PTY/SFTP close 독립성과 idle 정책, per-server pinned key, private key/local secret 경계, raw error 차단, Control/data 분리는 production 구현 변경 없이 유지한다.
- Deferred shutdown order 후보는 이전에 실제 fixture 3회 PASS로 확인되지 않았고 이번 수정 범위도 아니다. 별도 confirmed finding으로 승격하지 않았다.
- Generic future Provider가 mutation 후 resources를 누락하는 경우는 current producer invariant 범위 밖이다. 새 실제 Keystone network delay, Control reconnect E2E, cloud partial Delete rejection은 이번 독립 검증에서 실행하지 않았다.

## 실제 실행과 원본 로그 확인

Reviewer가 직접 실행:

1. 기존 외부 overlay `go test -mod=readonly -overlay ../lbt147-independent-audit/overlay.json -run '^TestAudit' -count=1 -timeout=20s ./internal/connector/app`: PASS. 최초 F1/F2 재현 3개와 shutdown fixture 1개 모두 PASS.
2. 새 회귀 `go test -mod=readonly -count=10 -timeout=2m -run '^(TestFailedLifecycle|TestLazyProvider_)' ./internal/connector/app`: PASS, 4.395s. 이 반복 후 fixture ID 현실화와 VMSetup red-fixture sync.Once 변경은 source semantics에 영향을 주지 않으며 최신 affected case도 아래 3번에서 실행했다.
3. 최신 testcase `go test -mod=readonly -count=1 -timeout=30s -run '^(TestCleanupPartialDeleteRejectionReportsDestructiveFailure|TestFailedLifecycle)' ./internal/connector/app ./internal/connector/provider/openstack`: 양 package PASS.

Root가 실행한 원본 로그를 reviewer가 파싱해 확인:

- go-unit.jsonl: test2828 PASS, SKIP7, failed0, package31 PASS, 최종 action PASS.
- go-race.jsonl: test364 PASS, SKIP6, failed0, changed5 packages PASS, 최종 action PASS.
- prior-finding-reproduction.log: 기존 외부 TestAudit 재현 green PASS.
- before-fix-regression.log: 이전 production2 파일을 overlay한 새 회귀 red 결과. 첫 실험 fixture close(entered) 중복 panic은 별도 before-fix-initial-fixture-panic.log로 보존하고 sync.Once로 fixture를 고친 뒤 behavioral regression FAIL을 확인했다. Production 문제와 fixture 문제를 구분했다.

기본 Go/race는 실제 외부 cloud가 아니라 unit/Mock/HTTP/SSH peer 경계다. opt-in tests는 SKIP이며 실제 VM 신규 생성/삭제는 reviewer가 실행하지 않았다. parent가 수행하는 계약/Web/vet/build 및 source freeze의 최종 결과는 parent 감사에 통합한다.

## Evidence와 판정 한계

Oct10 Evidence b0b5686의 실제 gen1/gen2 VM Management SSH/PTY/SFTP/idle/cleanup 기록과 artifact checksum은 앞선 독립 리뷰에서 확인했으며 유효한 과거 기록이다. 새 production 파일2/관련 tests가 변경되어 해당 실제 VM PASS를 current working tree나 새 failure/concurrency 경로의 실제 환경 성공으로 표시할 수 없다. Current source는 reviewer-source.json과 root source manifest/hash로 식별한다.

LBT-145 KT Cloud 선행조건, 새 real-cloud partial rejection, 실제 Control reconnect/Keystone 지연, production SFTP LBT-149, Browser/SaaS CC02 LBT-148 검증은 미실행/후속 범위다. 기존 Session.Setup cancel/timeout이 context 없는 SSH request를 풀기 위해 shared transport를 종료하는 정책을 향후 SFTP 작업 cancellation에서 다른 channel 보존 보장으로 확대하지 않는다.

**독립 최종 의견:** P1/P2 수정은 요구사항/실제 producer/consumer에 맞고, 이전 재현이 green으로 전환됐으며 추가 confirmed defect는 없다. 원래 full diff와 새 working tree 전체29파일의 독립 review를 완료했다. 실제 cloud 재검증 공백과 후속 task 경계를 분리하고 root의 최종 전체 기본 검증을 기록하면 로컬 구현 PR 범위의 준비 판정 근거로 사용할 수 있다. LBT-147/KT Cloud/OP02 전체 완료 또는 push/PR 승인으로 해석하지 않는다.
