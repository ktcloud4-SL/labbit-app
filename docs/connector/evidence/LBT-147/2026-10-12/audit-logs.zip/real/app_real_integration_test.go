package app

// External, opt-in audit harness. Loaded with Go -overlay; no repository source
// is changed. Requests reach the local cloud except explicitly selected faults.
import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/gophercloud/gophercloud/v2"
	"github.com/gophercloud/gophercloud/v2/openstack"
	"github.com/gophercloud/gophercloud/v2/openstack/compute/v2/keypairs"
	"github.com/gophercloud/gophercloud/v2/openstack/compute/v2/servers"
	openstackconfig "github.com/gophercloud/gophercloud/v2/openstack/config"
	"github.com/gophercloud/gophercloud/v2/openstack/config/clouds"
	"github.com/gophercloud/gophercloud/v2/openstack/identity/v3/tokens"
	"github.com/gophercloud/gophercloud/v2/openstack/networking/v2/extensions/security/groups"
	"github.com/gophercloud/gophercloud/v2/openstack/networking/v2/extensions/security/rules"
	"github.com/ktcloud4-SL/labbit-app/internal/connector/provider"
	osprovider "github.com/ktcloud4-SL/labbit-app/internal/connector/provider/openstack"
	"github.com/ktcloud4-SL/labbit-app/internal/connector/vmaccess"
	"golang.org/x/crypto/ssh"
)

// This forward proxy preserves real Keystone/Nova/Neutron/Glance responses.
// It never logs requests, headers, credentials, tokens, or VM output. Injection
// is limited to an exact test-owned server ID or the replacement VM POST phase.
type auditCloudProxy struct {
	allowed          map[string]bool
	upstream         *http.Transport
	mu               sync.Mutex
	rejectDelete     string
	rejectCreate     bool
	rejectCreateHost string
	rejectCreatePath string
	rejectCreateLab  string
	authGate         *auditAuthGate
	deleteFaults     int
	createFaults     int
}
type auditAuthGate struct {
	entered chan struct{}
	release chan struct{}
	once    sync.Once
}

func (g *auditAuthGate) unblock() { g.once.Do(func() { close(g.release) }) }

func (p *auditCloudProxy) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodConnect || r.URL.Scheme != "http" || !p.allowed[r.URL.Host] {
		http.Error(w, "audit proxy rejects nonlocal or unsupported endpoint", http.StatusBadGateway)
		return
	}
	p.mu.Lock()
	denyDelete := p.rejectDelete != "" && r.Method == http.MethodDelete && strings.HasSuffix(r.URL.Path, "/servers/"+p.rejectDelete)
	createCandidate := p.rejectCreate && r.Method == http.MethodPost && r.URL.Host == p.rejectCreateHost && r.URL.Path == p.rejectCreatePath
	createLab := p.rejectCreateLab
	gate := p.authGate
	if r.Method == http.MethodPost && strings.HasSuffix(r.URL.Path, "/auth/tokens") && gate != nil {
		p.authGate = nil
	} else {
		gate = nil
	}
	if denyDelete {
		p.deleteFaults++
	}
	p.mu.Unlock()
	denyCreate := false
	if createCandidate {
		body, err := io.ReadAll(io.LimitReader(r.Body, 1024*1024+1))
		if err != nil || len(body) > 1024*1024 {
			http.Error(w, "audit server request cannot be scoped", http.StatusBadGateway)
			return
		}
		_ = r.Body.Close()
		r.Body = io.NopCloser(bytes.NewReader(body))
		var payload struct {
			Server struct {
				Metadata map[string]string `json:"metadata"`
			} `json:"server"`
		}
		if json.Unmarshal(body, &payload) == nil {
			denyCreate = payload.Server.Metadata["labbit_lab_instance_id"] == createLab && payload.Server.Metadata["labbit_generation"] == "2"
		}
		if denyCreate {
			p.mu.Lock()
			p.createFaults++
			p.mu.Unlock()
		}
	}
	if denyDelete || denyCreate {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusConflict)
		_, _ = io.WriteString(w, `{"conflictingRequest":{"message":"audit injected rejection","code":409}}`)
		return
	}
	req := r.Clone(r.Context())
	req.RequestURI = ""
	req.Header.Del("Proxy-Connection")
	resp, err := p.upstream.RoundTrip(req)
	if err != nil {
		http.Error(w, "audit upstream request failed", http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	if gate != nil {
		// Real authentication has completed; withhold its response while app
		// waiters cancel. No replacement or fabricated token is used.
		close(gate.entered)
		select {
		case <-gate.release:
		case <-r.Context().Done():
			return
		}
	}
	for key, values := range resp.Header {
		for _, value := range values {
			w.Header().Add(key, value)
		}
	}
	w.WriteHeader(resp.StatusCode)
	_, _ = io.Copy(w, resp.Body)
}

func auditInstallProxy(t *testing.T, auth gophercloud.AuthOptions, catalog *tokens.ServiceCatalog) *auditCloudProxy {
	t.Helper()
	allowed := map[string]bool{}
	add := func(raw string) {
		u, err := url.Parse(raw)
		if err != nil || u.Scheme != "http" || u.User != nil {
			t.Fatal("audit requires local HTTP cloud endpoints")
		}
		ip := net.ParseIP(u.Hostname())
		if ip == nil || (!ip.IsPrivate() && !ip.IsLoopback()) {
			t.Fatal("audit refuses nonlocal cloud endpoints")
		}
		allowed[u.Host] = true
	}
	add(auth.IdentityEndpoint)
	for _, entry := range catalog.Entries {
		if entry.Type == "identity" || entry.Type == "compute" || entry.Type == "network" || entry.Type == "image" {
			for _, endpoint := range entry.Endpoints {
				add(endpoint.URL)
			}
		}
	}
	original := http.DefaultTransport
	transport, ok := original.(*http.Transport)
	if !ok {
		t.Fatal("unexpected default HTTP transport")
	}
	upstream := transport.Clone()
	p := &auditCloudProxy{allowed: allowed, upstream: upstream}
	s := httptest.NewServer(p)
	proxyURL, _ := url.Parse(s.URL)
	proxied := transport.Clone()
	proxied.Proxy = http.ProxyURL(proxyURL)
	http.DefaultTransport = proxied
	t.Cleanup(func() {
		http.DefaultTransport = original
		proxied.CloseIdleConnections()
		s.Close()
		upstream.CloseIdleConnections()
	})
	return p
}

type auditResolver struct {
	adapter *osprovider.Adapter
	calls   atomic.Int32
}

func (r *auditResolver) ResolveVMAccess(ctx context.Context, target vmaccess.Target) (vmaccess.Endpoint, error) {
	r.calls.Add(1)
	return r.adapter.ResolveVMAccess(ctx, target)
}

func auditSession(t *testing.T, ctx context.Context, m *vmaccess.Manager, target vmaccess.Target) (*vmaccess.Session, io.WriteCloser, io.Reader) {
	t.Helper()
	s, err := m.OpenSession(ctx, target)
	if err != nil {
		t.Fatal("real VM session open failed")
	}
	t.Cleanup(func() { _ = s.Close() })
	in, err := s.StdinPipe()
	if err != nil {
		t.Fatal("SSH stdin failed")
	}
	out, err := s.StdoutPipe()
	if err != nil {
		t.Fatal("SSH stdout failed")
	}
	if err := s.Setup(ctx, func(raw *ssh.Session) error { return raw.Shell() }); err != nil {
		t.Fatal("real SSH shell setup failed")
	}
	auditShellProbe(t, in, out, s)
	return s, in, out
}
func auditShellProbe(t *testing.T, in io.Writer, out io.Reader, s *vmaccess.Session) {
	t.Helper()
	done := make(chan bool, 1)
	go func() {
		if _, err := in.Write([]byte("printf 'AUDIT-%s\\n' 'ALIVE'\n")); err != nil {
			done <- false
			return
		}
		var collected []byte
		buf := make([]byte, 1024)
		for len(collected) < 65536 {
			n, err := out.Read(buf)
			collected = append(collected, buf[:n]...)
			if strings.Contains(string(collected), "AUDIT-ALIVE") {
				done <- true
				return
			}
			if err != nil {
				break
			}
		}
		done <- false
	}()
	select {
	case ok := <-done:
		if !ok {
			t.Fatal("real SSH shell probe failed")
		}
	case <-time.After(10 * time.Second):
		_ = s.Close()
		t.Fatal("real SSH shell probe timed out")
	}
}
func auditAssertFenced(t *testing.T, ctx context.Context, m *vmaccess.Manager, r *auditResolver, target vmaccess.Target, s *vmaccess.Session, in io.Writer, out io.Reader) {
	t.Helper()
	done := make(chan struct{})
	go func() { _, _ = io.Copy(io.Discard, out); close(done) }()
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		_ = s.Close()
		t.Fatal("obsolete actual SSH channel remained open")
	}
	if _, err := in.Write([]byte("stale\n")); err == nil {
		t.Fatal("obsolete SSH channel accepted input")
	}
	before := r.calls.Load()
	reopened, err := m.OpenSession(ctx, target)
	if reopened != nil {
		_ = reopened.Close()
	}
	if !errors.Is(err, vmaccess.ErrInvalidTarget) || r.calls.Load() != before {
		t.Fatal("old generation was not fenced before real Provider resolution")
	}
}
func auditRefs(resources []provider.ResourceResult) []provider.ResourceRef {
	refs := make([]provider.ResourceRef, 0, len(resources))
	seen := map[string]bool{}
	for _, r := range resources {
		key := r.ResourceType + ":" + r.ProviderID
		if r.ProviderID != "" && !seen[key] {
			seen[key] = true
			refs = append(refs, r.ResourceRef)
		}
	}
	return refs
}
func auditRequireResult(t *testing.T, result provider.OperationResult, err error, outcome provider.Outcome) {
	t.Helper()
	if err != nil || result.Outcome != outcome {
		t.Fatalf("unexpected lifecycle result: outcome=%s safeError=%+v", result.Outcome, result.Error)
	}
}
func auditRequirePartial(t *testing.T, result provider.OperationResult, workerID, workspaceID string) {
	t.Helper()
	states := map[string]string{}
	for _, r := range result.ProviderResources {
		states[r.ProviderID] = r.ObservedState
	}
	if states[workerID] != "DELETED" || states[workspaceID] != "DELETE_FAILED" {
		t.Fatal("real Adapter did not report DELETED + DELETE_FAILED")
	}
	count := 0
	for _, r := range result.ProviderResources {
		if r.ObservedState == "DELETE_NOT_ATTEMPTED" {
			count++
		}
	}
	if count == 0 {
		t.Fatal("later resources were not preserved as DELETE_NOT_ATTEMPTED")
	}
}

func TestLBT147RealAppBoundaries(t *testing.T) {
	if os.Getenv("LABBIT_OPENSTACK_APP_AUDIT") != "1" {
		t.Skip("opt-in local real-cloud audit")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	defer cancel()
	cfg := osprovider.ConfigFromEnvironment()
	auth, endpoint, tlsConfig, err := clouds.Parse(clouds.WithLocations(cfg.File), clouds.WithCloudName(cfg.CloudName))
	if err != nil {
		t.Fatal("local cloud configuration unavailable")
	}
	if tlsConfig != nil && tlsConfig.InsecureSkipVerify {
		t.Fatal("insecure TLS configuration")
	}
	bootstrap, err := openstackconfig.NewProviderClient(ctx, auth, openstackconfig.WithTLSConfig(tlsConfig))
	if err != nil {
		t.Fatal("real bootstrap authentication failed")
	}
	result, ok := bootstrap.GetAuthResult().(tokens.CreateResult)
	if !ok {
		t.Fatal("project-scoped authentication unavailable")
	}
	project, err := result.ExtractProject()
	if err != nil || project == nil {
		t.Fatal("real project unavailable")
	}
	catalog, err := result.ExtractServiceCatalog()
	if err != nil {
		t.Fatal("service catalog unavailable")
	}
	proxy := auditInstallProxy(t, auth, catalog)
	cfg.Provision.ProviderConnectionID = "local-app-audit"

	t.Run("P2-real-Keystone-waiter-deadline-and-cancel", func(t *testing.T) {
		gate := &auditAuthGate{entered: make(chan struct{}), release: make(chan struct{})}
		defer gate.unblock()
		proxy.mu.Lock()
		proxy.authGate = gate
		proxy.mu.Unlock()
		var factories atomic.Int32
		lazy := newLazyProvider(cfg.Provision.ProviderConnectionID, func(ctx context.Context) (runtimeProvider, error) { factories.Add(1); return osprovider.New(ctx, cfg) })
		owner := make(chan error, 1)
		go func() { _, err := lazy.ListImages(ctx); owner <- err }()
		select {
		case <-gate.entered:
		case <-time.After(10 * time.Second):
			t.Fatal("real Keystone response did not reach the gate")
		}
		waitCtx, waitCancel := context.WithTimeout(ctx, 80*time.Millisecond)
		started := time.Now()
		_, err := lazy.ListImages(waitCtx)
		elapsed := time.Since(started)
		waitCancel()
		if !errors.Is(err, context.DeadlineExceeded) || elapsed > 750*time.Millisecond {
			t.Fatal("Provider waiter ignored deadline")
		}
		manager := vmaccess.NewManager(lazy, vmaccess.Config{SetupTimeout: 40 * time.Millisecond})
		setupStarted := time.Now()
		_, setupErr := manager.OpenSession(ctx, vmaccess.Target{LabInstanceID: "audit-pending-init", Generation: 1, VMKey: "workspace", ServerID: "not-resolved-before-deadline"})
		setupElapsed := time.Since(setupStarted)
		_ = manager.Close()
		if !errors.Is(setupErr, context.DeadlineExceeded) || setupElapsed > 750*time.Millisecond {
			t.Fatal("VM manager setup deadline did not interrupt real Provider initialization wait")
		}
		cancelCtx, cancelWaiter := context.WithCancel(ctx)
		canceled := make(chan error, 1)
		go func() { _, err := lazy.ListFlavors(cancelCtx); canceled <- err }()
		select {
		case <-canceled:
			t.Fatal("live waiter completed before owner initialization")
		case <-time.After(20 * time.Millisecond):
		}
		cancelWaiter()
		select {
		case err := <-canceled:
			if !errors.Is(err, context.Canceled) {
				t.Fatal("waiter cancellation result mismatch")
			}
		case <-time.After(time.Second):
			t.Fatal("Provider waiter ignored cancellation")
		}
		alive := make(chan error, 1)
		go func() { _, err := lazy.ListFlavors(ctx); alive <- err }()
		gate.unblock()
		for _, done := range []chan error{owner, alive} {
			select {
			case err := <-done:
				if err != nil {
					t.Fatal("real Provider owner or live waiter failed")
				}
			case <-time.After(10 * time.Second):
				t.Fatal("real Provider initialization did not finish")
			}
		}
		if factories.Load() != 1 {
			t.Fatal("duplicate real Provider initialization")
		}
		if _, err := lazy.ListImages(ctx); err != nil || factories.Load() != 1 {
			t.Fatal("real Provider cache was not reused")
		}
		t.Logf("Real Keystone + Glance/Nova; injected response delay; waiter deadline=%dms VM manager setup deadline=%dms cancellation honored; owner/live waiter succeed; factoryCount=1", elapsed.Milliseconds(), setupElapsed.Milliseconds())
	})
	t.Run("P2-real-Keystone-owner-cancel-and-retry", func(t *testing.T) {
		gate := &auditAuthGate{entered: make(chan struct{}), release: make(chan struct{})}
		defer gate.unblock()
		proxy.mu.Lock()
		proxy.authGate = gate
		proxy.mu.Unlock()
		var factories atomic.Int32
		lazy := newLazyProvider(cfg.Provision.ProviderConnectionID, func(ctx context.Context) (runtimeProvider, error) { factories.Add(1); return osprovider.New(ctx, cfg) })
		ownerCtx, stopOwner := context.WithCancel(ctx)
		defer stopOwner()
		owner := make(chan error, 1)
		go func() { _, err := lazy.ListImages(ownerCtx); owner <- err }()
		select {
		case <-gate.entered:
		case <-time.After(10 * time.Second):
			t.Fatal("real Keystone response did not reach cancellation gate")
		}
		waiter := make(chan error, 1)
		go func() { _, err := lazy.ListFlavors(ctx); waiter <- err }()
		select {
		case <-waiter:
			t.Fatal("live waiter completed before cancellation")
		case <-time.After(20 * time.Millisecond):
		}
		stopOwner()
		select {
		case err := <-owner:
			if !errors.Is(err, context.Canceled) {
				t.Fatal("real initialization owner cancellation mismatch")
			}
		case <-time.After(2 * time.Second):
			t.Fatal("real initialization owner did not cancel")
		}
		select {
		case err := <-waiter:
			if !errors.Is(err, errProviderInitialization) {
				t.Fatal("live waiter did not receive shared safe failure")
			}
		case <-time.After(time.Second):
			t.Fatal("live waiter was not released after owner cancellation")
		}
		gate.unblock()
		if _, err := lazy.ListImages(ctx); err != nil || factories.Load() != 2 {
			t.Fatal("fresh real authentication retry failed")
		}
		if _, err := lazy.ListFlavors(ctx); err != nil || factories.Load() != 2 {
			t.Fatal("retried real Provider cache was not reused")
		}
		t.Log("Real Keystone response delay injected; owner cancels, live waiter receives safe shared failure; next request authenticates again, queries succeed and cache reused; factoryCount=2")
	})
	if t.Failed() {
		return
	}

	compute, err := openstack.NewComputeV2(bootstrap, endpoint)
	if err != nil {
		t.Fatal("Nova client unavailable")
	}
	computeURL, err := url.Parse(compute.Endpoint)
	if err != nil {
		t.Fatal("Nova endpoint unavailable")
	}
	network, err := openstack.NewNetworkV2(bootstrap, endpoint)
	if err != nil {
		t.Fatal("Neutron client unavailable")
	}
	keyBytes, err := os.ReadFile(cfg.Provision.SSHPrivateKeyFile)
	if err != nil {
		t.Fatal("local SSH key unavailable")
	}
	signer, err := ssh.ParsePrivateKey(keyBytes)
	if err != nil {
		t.Fatal("local SSH key invalid")
	}
	runID := uuid.NewString()
	keyName := "labbit-app-audit-" + runID
	_, err = keypairs.Create(ctx, compute, keypairs.CreateOpts{Name: keyName, PublicKey: strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))}).Extract()
	if err != nil {
		t.Fatal("temporary keypair creation failed")
	}
	t.Logf("Owned temporary keypair: %s", keyName)
	t.Cleanup(func() {
		cleanCtx, stop := context.WithTimeout(context.Background(), time.Minute)
		defer stop()
		err := keypairs.Delete(cleanCtx, compute, keyName, nil).ExtractErr()
		if err != nil && !gophercloud.ResponseCodeIs(err, 404) {
			t.Error("temporary keypair delete failed")
		}
		_, err = keypairs.Get(cleanCtx, compute, keyName, nil).Extract()
		if !gophercloud.ResponseCodeIs(err, 404) {
			t.Error("temporary keypair absence unverified")
		} else {
			t.Log("Temporary exact keypair independently ABSENT")
		}
	})
	sg, err := groups.Create(ctx, network, groups.CreateOpts{Name: "labbit-app-audit-" + runID, Description: "Temporary management SSH group for local audit"}).Extract()
	if err != nil {
		t.Fatal("temporary management security group creation failed")
	}
	t.Logf("Owned temporary management SG: %s", sg.ID)
	t.Cleanup(func() {
		cleanCtx, stop := context.WithTimeout(context.Background(), time.Minute)
		defer stop()
		err := groups.Delete(cleanCtx, network, sg.ID).ExtractErr()
		if err != nil && !gophercloud.ResponseCodeIs(err, 404) {
			t.Error("temporary management SG delete failed")
		}
		_, err = groups.Get(cleanCtx, network, sg.ID).Extract()
		if !gophercloud.ResponseCodeIs(err, 404) {
			t.Error("temporary management SG absence unverified")
		} else {
			t.Log("Temporary exact management SG independently ABSENT")
		}
	})
	for _, r := range sg.Rules {
		if err := rules.Delete(ctx, network, r.ID).ExtractErr(); err != nil {
			t.Fatal("temporary default SG rule removal failed")
		}
	}
	_, err = rules.Create(ctx, network, rules.CreateOpts{Direction: rules.DirIngress, EtherType: rules.EtherType4, SecGroupID: sg.ID, Protocol: rules.ProtocolTCP, PortRangeMin: 22, PortRangeMax: 22, RemoteIPPrefix: "172.16.8.1/32"}).Extract()
	if err != nil {
		t.Fatal("temporary management SSH rule creation failed")
	}
	query, err := osprovider.New(ctx, cfg)
	if err != nil {
		t.Fatal("real Provider unavailable")
	}
	images, err := query.ListImages(ctx)
	if err != nil {
		t.Fatal("real image discovery failed")
	}
	flavors, err := query.ListFlavors(ctx)
	if err != nil {
		t.Fatal("real flavor discovery failed")
	}
	nets, err := query.ListNetworks(ctx)
	if err != nil {
		t.Fatal("real network discovery failed")
	}
	imageID, managementID := "", ""
	var flavor provider.Flavor
	for _, i := range images {
		if i.Name == "ubuntu" {
			if imageID != "" {
				t.Fatal("ambiguous Ubuntu image")
			}
			imageID = i.ID
		}
	}
	for _, f := range flavors {
		if f.Name == "m1.small" {
			if flavor.ID != "" {
				t.Fatal("ambiguous small flavor")
			}
			flavor = f
		}
	}
	for _, n := range nets {
		if n.Name == "sharednet1" {
			if managementID != "" {
				t.Fatal("ambiguous management network")
			}
			managementID = n.ID
		}
	}
	if imageID == "" || managementID == "" || flavor.ID == "" {
		t.Fatal("real fixture selections unavailable")
	}
	cfg.Provision.ProjectID = project.ID
	cfg.Provision.ManagementNetworkID = managementID
	cfg.Provision.ManagementSecurityGroupID = sg.ID
	cfg.Provision.KeyPairName = keyName
	cfg.Provision.SSHAllowedCIDR = "172.16.8.1/32"
	cfg.Provision.LabSubnetCIDR = "198.21.0.0/24"
	cfg.Provision.SSHKnownHostsFile = filepath.Join(t.TempDir(), "known_hosts")
	cfg.Provision.PollInterval = 2 * time.Second
	adapter, err := osprovider.New(ctx, cfg)
	if err != nil {
		t.Fatal("real lifecycle Provider unavailable")
	}
	vm := provider.VMSpec{VMKey: "worker", Role: "WORKER", InstanceIndex: 1, ImageID: imageID, FlavorID: flavor.ID, FlavorSpec: provider.FlavorSpec{VCPUs: flavor.VCPUs, RAMMiB: flavor.RAMMiB, DiskGiB: flavor.DiskGiB}}
	workspace := vm
	workspace.VMKey = "workspace"
	workspace.Role = "WORKSPACE"
	workspace.InstanceIndex = 0
	snapshot := provider.CreationSnapshot{ProviderConnectionID: cfg.Provision.ProviderConnectionID, WorkspaceVMKey: "workspace", VMs: []provider.VMSpec{vm, workspace}}
	labID := "lbt147-app-" + runID
	proxy.mu.Lock()
	proxy.rejectCreateHost = computeURL.Host
	proxy.rejectCreatePath = strings.TrimSuffix(computeURL.Path, "/") + "/servers"
	proxy.rejectCreateLab = labID
	proxy.mu.Unlock()
	var tracked []provider.ResourceResult
	t.Cleanup(func() {
		proxy.mu.Lock()
		proxy.rejectDelete = ""
		proxy.rejectCreate = false
		proxy.mu.Unlock()
		cleanCtx, stop := context.WithTimeout(context.Background(), 4*time.Minute)
		defer stop()
		refs := auditRefs(tracked)
		// Observe first, and delete only the exact tracked IDs still confirmed
		// present. Never retry an uncertain mutation without fresh observation.
		for attempt := 0; attempt <= 3; attempt++ {
			observed, err := adapter.Reconcile(cleanCtx, provider.ReconcileRequest{Correlation: provider.Correlation{OperationID: labID + "-cleanup-observe", LabInstanceID: labID, Generation: 2}, KnownResources: refs, DiscoverCandidates: false})
			if err != nil || observed.Error != nil || len(observed.Observations) != len(refs) {
				t.Error("tracked resource cleanup pre-observation failed")
				return
			}
			var present []provider.ResourceRef
			for _, o := range observed.Observations {
				if o.Exists {
					for _, r := range refs {
						if r.ResourceType == o.ResourceType && r.ProviderID == o.ProviderID {
							present = append(present, r)
							break
						}
					}
				}
			}
			if len(present) == 0 {
				t.Logf("Independent Reconcile: %d exact tracked resources ABSENT after cleanup", len(refs))
				return
			}
			if attempt == 3 {
				break
			}
			clean, err := adapter.Cleanup(cleanCtx, provider.CleanupRequest{Correlation: provider.Correlation{OperationID: labID + "-cleanup", LabInstanceID: labID, Generation: 2}, ProviderResources: present})
			if err != nil {
				t.Error("tracked resource cleanup returned internal error")
				return
			}
			if clean.Outcome != provider.OutcomeSucceeded {
				t.Logf("Cleanup outcome=%s; will observe exact IDs before any retry", clean.Outcome)
			}
		}
		t.Error("tracked resource absence was not verified")
	})
	provision, err := adapter.Provision(ctx, provider.ProvisionRequest{Correlation: provider.Correlation{OperationID: labID + "-provision", LabInstanceID: labID, Generation: 1}, CreationSnapshot: snapshot})
	tracked = append(tracked, provision.ProviderResources...)
	t.Logf("Owned tracked resource ledger: %+v", auditRefs(tracked))
	auditRequireResult(t, provision, err, provider.OutcomeSucceeded)
	workerID, workspaceID := "", ""
	for _, r := range provision.ProviderResources {
		if r.ResourceType == provider.ResourceTypeServer {
			if r.LogicalName == "worker" {
				workerID = r.ProviderID
			}
			if r.LogicalName == "workspace" {
				workspaceID = r.ProviderID
			}
		}
	}
	if workerID == "" || workspaceID == "" {
		t.Fatal("two real fixture VMs unavailable")
	}
	t.Logf("Real two-VM generation ACTIVE/SSH-ready: resources=%d", len(provision.ProviderResources))
	target := vmaccess.Target{LabInstanceID: labID, Generation: 1, VMKey: "workspace", ServerID: workspaceID}
	oldRefs := auditRefs(provision.ProviderResources)
	newManager := func(t *testing.T) (*vmaccess.Manager, *auditResolver, *accessLifecycleProvider) {
		r := &auditResolver{adapter: adapter}
		m := vmaccess.NewManager(r, vmaccess.Config{})
		t.Cleanup(func() { _ = m.Close() })
		return m, r, &accessLifecycleProvider{Provider: adapter, manager: m}
	}

	t.Run("P1-real-Reset-preflight-preserves-active-SSH", func(t *testing.T) {
		m, _, p := newManager(t)
		s, in, out := auditSession(t, ctx, m, target)
		bad := snapshot
		bad.VMs = append([]provider.VMSpec(nil), snapshot.VMs...)
		bad.VMs[0].FlavorID = uuid.NewString()
		failed, err := p.Reset(ctx, provider.ResetRequest{Correlation: provider.Correlation{OperationID: labID + "-preflight", LabInstanceID: labID, Generation: 2}, CreationSnapshot: bad, ProviderResources: oldRefs})
		auditRequireResult(t, failed, err, provider.OutcomeFailed)
		if len(failed.ProviderResources) != len(oldRefs) {
			t.Fatal("preflight resources missing")
		}
		for _, r := range failed.ProviderResources {
			if r.ObservedState != "DELETE_NOT_ATTEMPTED" {
				t.Fatal("preflight performed a mutation")
			}
		}
		auditShellProbe(t, in, out, s)
		reopened, err := m.OpenSession(ctx, target)
		if err != nil {
			t.Fatal("unchanged generation fenced by real preflight")
		}
		_ = reopened.Close()
		t.Log("Real Nova missing-flavor preflight; no fault injection; DELETE_NOT_ATTEMPTED only; active SSH and generation reopen preserved")
	})
	t.Run("P1-real-Cleanup-first-delete-rejected", func(t *testing.T) {
		m, r, p := newManager(t)
		s, in, out := auditSession(t, ctx, m, target)
		proxy.mu.Lock()
		proxy.rejectDelete = workerID
		proxy.mu.Unlock()
		defer func() { proxy.mu.Lock(); proxy.rejectDelete = ""; proxy.mu.Unlock() }()
		failed, err := p.Cleanup(ctx, provider.CleanupRequest{Correlation: provider.Correlation{OperationID: labID + "-reject-first", LabInstanceID: labID, Generation: 1}, ProviderResources: oldRefs})
		auditRequireResult(t, failed, err, provider.OutcomeFailed)
		if failed.ProviderResources[0].ProviderID != workerID || failed.ProviderResources[0].ObservedState != "DELETE_FAILED" {
			t.Fatal("first owned delete was not rejected")
		}
		auditAssertFenced(t, ctx, m, r, target, s, in, out)
		if _, err := servers.Get(ctx, compute, workspaceID).Extract(); err != nil {
			t.Fatal("workspace was unexpectedly deleted")
		}
		t.Log("Injected first owned DELETE HTTP409; real workspace remains; active SSH retired and old generation rejected before Provider resolution")
	})
	if t.Failed() {
		return
	}
	t.Run("P1-real-Reset-partial-cleanup-failure", func(t *testing.T) {
		m, r, p := newManager(t)
		s, in, out := auditSession(t, ctx, m, target)
		proxy.mu.Lock()
		proxy.rejectDelete = workspaceID
		proxy.mu.Unlock()
		defer func() { proxy.mu.Lock(); proxy.rejectDelete = ""; proxy.mu.Unlock() }()
		failed, err := p.Reset(ctx, provider.ResetRequest{Correlation: provider.Correlation{OperationID: labID + "-partial-reset", LabInstanceID: labID, Generation: 2}, CreationSnapshot: snapshot, ProviderResources: oldRefs})
		tracked = append(tracked, failed.ProviderResources...)
		t.Logf("Owned tracked resource ledger after partial Reset: %+v", auditRefs(tracked))
		auditRequireResult(t, failed, err, provider.OutcomeFailed)
		auditRequirePartial(t, failed, workerID, workspaceID)
		auditAssertFenced(t, ctx, m, r, target, s, in, out)
		if _, err := servers.Get(ctx, compute, workerID).Extract(); !gophercloud.ResponseCodeIs(err, 404) {
			t.Fatal("real worker deletion not independently confirmed")
		}
		if _, err := servers.Get(ctx, compute, workspaceID).Extract(); err != nil {
			t.Fatal("workspace did not survive injected rejection")
		}
		t.Log("Actual worker DELETE + independent GET404; workspace DELETE HTTP409 injected; real Adapter FAILED/DELETED/DELETE_FAILED/NOT_ATTEMPTED; active workspace SSH retired and old generation fenced")
	})
	if t.Failed() {
		return
	}
	t.Run("P1-real-Cleanup-partial-failure-already-absent-worker", func(t *testing.T) {
		m, r, p := newManager(t)
		s, in, out := auditSession(t, ctx, m, target)
		proxy.mu.Lock()
		proxy.rejectDelete = workspaceID
		proxy.mu.Unlock()
		defer func() { proxy.mu.Lock(); proxy.rejectDelete = ""; proxy.mu.Unlock() }()
		failed, err := p.Cleanup(ctx, provider.CleanupRequest{Correlation: provider.Correlation{OperationID: labID + "-partial-cleanup", LabInstanceID: labID, Generation: 1}, ProviderResources: oldRefs})
		auditRequireResult(t, failed, err, provider.OutcomeFailed)
		auditRequirePartial(t, failed, workerID, workspaceID)
		auditAssertFenced(t, ctx, m, r, target, s, in, out)
		t.Log("Actual worker DELETE returns404 from previous Reset; workspace DELETE409 injected; real Cleanup producer + app retire/fence PASS")
	})
	if t.Failed() {
		return
	}
	t.Run("P1-real-Reset-replacement-creation-failure", func(t *testing.T) {
		m, r, p := newManager(t)
		s, in, out := auditSession(t, ctx, m, target)
		proxy.mu.Lock()
		proxy.rejectCreate = true
		proxy.mu.Unlock()
		defer func() { proxy.mu.Lock(); proxy.rejectCreate = false; proxy.mu.Unlock() }()
		failed, err := p.Reset(ctx, provider.ResetRequest{Correlation: provider.Correlation{OperationID: labID + "-replacement", LabInstanceID: labID, Generation: 2}, CreationSnapshot: snapshot, ProviderResources: oldRefs})
		tracked = append(tracked, failed.ProviderResources...)
		t.Logf("Owned tracked resource ledger after replacement: %+v", auditRefs(tracked))
		auditRequireResult(t, failed, err, provider.OutcomeFailed)
		deleted := 0
		replacement := 0
		for _, resource := range failed.ProviderResources {
			if resource.Generation == 1 && resource.ObservedState == "DELETED" {
				deleted++
			}
			if resource.Generation == 2 {
				replacement++
			}
		}
		if deleted != len(oldRefs) || replacement == 0 {
			t.Fatal("replacement failure did not retain full old deletion and new tracked resources")
		}
		auditAssertFenced(t, ctx, m, r, target, s, in, out)
		if _, err := servers.Get(ctx, compute, workspaceID).Extract(); !gophercloud.ResponseCodeIs(err, 404) {
			t.Fatal("old workspace remains after replacement attempt")
		}
		t.Logf("Actual old generation cleanup (%d resources); actual gen2 Neutron resources tracked (%d); Nova server POST409 injected; failed replacement retires/fences old generation", deleted, replacement)
	})
	proxy.mu.Lock()
	deleteFaults, createFaults := proxy.deleteFaults, proxy.createFaults
	proxy.mu.Unlock()
	if deleteFaults != 3 || createFaults != 1 {
		t.Fatalf("unexpected fault count: deletes=%d creates=%d", deleteFaults, createFaults)
	}
	t.Logf("Precisely scoped fault counts: DELETE409=%d POST409=%d; no unowned mutation was intercepted", deleteFaults, createFaults)
}
