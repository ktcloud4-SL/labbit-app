# LBT-147 current-source local OpenStack independent review

Reviewer: implementation-independent sub-agent. Date: 2026-10-12. This reviewer did not change repository files, perform cloud mutations, push, create a PR, or send external messages. This record extends the full base-to-working-tree review in `../LBT-147-premerge-fix-20261012/reviewer.md` and the original 26-file review in `../lbt147-independent-audit/independent-review.md`.

## Version and scope

- Repository: `C:/Users/user/Documents/ChatGPT/3차 2/tmp/labbit-vm-access-147`.
- HEAD: `399681789572487bd44469ec018e52b53f97678e`; original merge base: `6d675c74bff11f481d247267faefd4ce960dcd38`.
- Latest fetched main: `e850567066134edc87b2ba543d0eb42a21f406b8`. Independently read the complete old-main-to-new-main diff: only `docs/frontend/deployment-handoff.md` changed. No LBT-147 backend, runtime, connector or realtime contract change. The new document explicitly leaves real Terminal/File E2E and Gateway WSS routing to subsequent integration work.
- Working tree still contains the same six reviewed fix files, including new `vm_access_lifecycle_test.go`; implementation-source hashes must remain aligned with the fix reviewer manifest and execution manifests.
- External virtual overlay maps `internal/connector/app/lbt147_real_audit_test.go` to `app_real_integration_test.go`, and does not replace repository production code.
- Initial static-review harness SHA256: `e6fc2d5eabee5c3a6d7ea653e19ee22b1babea5106f8ba9c734fb94a971cade8`. A revised harness requires its own recorded hash and review delta.

## Existing real VM test: confirmed boundary and limit

Independently inspected `real-vm-access.jsonl`: `TestOpenStackVMAccessIntegration` passed in 229.83 seconds, package passed in 233.202 seconds, with no failure/skip action. The original output explicitly records wrong LabInstance/generation/VM-key rejection and two generations / 14 distinct tracked resources absent after cleanup.

The source test exercises actual OpenStack Provision, authenticated management SSH, pinned host-key reuse, real PTY input/output and resize, SFTP handshake/path response, shared SSH transport, channel independence, idle replacement, Reset to generation 2, stale target rejection, and cleanup. It creates `NewManager(a)` and calls `a.Reset`/`a.Cleanup` directly. Consequently it is valid current-source real VM regression evidence, but does not itself traverse the repaired app lifecycle wrapper (F1) or lazy Provider initialization (F2). It must not be presented as direct real-backend proof of either fix.

## App fault harness: independent static review

The external test is opt-in and serial. It uses actual `osprovider.New`, real adapter producer methods, the app `accessLifecycleProvider` wrapper, `lazyProvider`, VM manager, and real workspace SSH. Cloud traffic passes through a loopback HTTP forward proxy; only selected faults are synthesized. Bootstrap-derived independent Nova GET clients retain the original transport, so worker absence/workspace presence are checked outside the injected proxy response path.

| Scenario | Actual boundary | Injected boundary | Required observation |
| --- | --- | --- | --- |
| F2 deadline/cancel | Real Keystone authentication and subsequent Glance/Nova queries, app shared initialization attempt | Real Keystone response is withheld after upstream RoundTrip returns | Short waiter and VM-manager setup deadlines return promptly; canceled waiter does not cancel owner; owner/live waiter succeed; one cached factory |
| F2 owner cancel/retry | Real Keystone plus app attempt publication/failure | Withheld authentication response while owner context is canceled | Owner receives cancellation; joined waiter receives safe shared failure; next request authenticates and succeeds; cached retry reused |
| F1 untouched preflight | Real Reset preflight with a missing flavor | None | FAILED with only DELETE_NOT_ATTEMPTED; established SSH remains usable; old target can reopen |
| F1 first delete rejection | Actual two-VM Provider result handling, app wrapper, real live workspace SSH | Exact tracked worker DELETE returns HTTP 409 | FAILED/DELETE_FAILED; old SSH closes, old generation rejects before resolver; workspace still exists |
| F1 partial Reset | Actual worker DELETE and independent GET404, real Adapter result producer, app wrapper, real workspace SSH | Exact tracked workspace DELETE returns HTTP 409 | DELETED + DELETE_FAILED + NOT_ATTEMPTED; still-live workspace channel retires and generation fences before resolver |
| F1 partial Cleanup | Actual repeated worker DELETE/404 and real Adapter cleanup result, app wrapper | Exact tracked workspace DELETE returns HTTP 409 | Same FAILED shape and retire/fence behavior |
| F1 replacement failure | Actual old cleanup and actual generation-2 Neutron creation, real Adapter/app result handling | Replacement Nova server POST returns HTTP 409 | All old resources reported DELETED, new resources remain tracked, old channel/target retired, exact cleanup verifies absence |

No confirmed new production defect was found during this harness review. In particular, partial Reset with a still-existing workspace is strong evidence that the app closes obsolete SSH itself, rather than succeeding only because Nova removed the connected VM. Replacement failure also tests producer retention of the newly created resource IDs so final cleanup can observe them.

### Isolation and cleanup

- The proxy rejects CONNECT, non-HTTP URLs, non-catalog hosts and public/non-IP catalog endpoints. No insecure TLS setting is accepted.
- DELETE faults use IDs obtained from this run's own successful Provision. No delete-by-name, guessed resource ID or shared management network cleanup occurs.
- Temporary keypair and management security group are newly created with a random run name; independent GET404 checks follow exact deletion.
- All returned Provision/Reset resource IDs are appended before result assertions. Parent cleanup first disables faults, uses a fresh background 4-minute context, deduplicates exact type/ID references, performs Reconcile without candidate discovery, deletes only observed existing tracked resources, and observes again before any retry. Lookup failure is not interpreted as absence.
- Subtest sessions and managers close before parent resource cleanup. Parent tracked resources clean before the temporary management SG and keypair, and proxy restoration occurs last.
- Raw provider responses, request headers, tokens, config, key bytes and shell output are not printed. Probe contents are used transiently in memory only.

### Harness improvements reported before execution

1. The initial `rejectCreate` condition matches any allowed host's `/servers` POST while its phase flag is enabled. In this explicitly selected, serial single test it is only reached by the intended replacement request, but the code does not inspect project/body metadata. Recommended tightening: require Nova compute endpoint/project and matching audit lab/generation-2 metadata. If not changed, Evidence must call this a replacement-phase Nova POST fault, not an intrinsically exact-owned-ID POST filter.
2. The initial cleanup loop performs three observation/delete rounds but has no final observation after the third delete; successful final deletion could therefore cause a false cleanup failure. Recommended adding the final Reconcile before absence verdict. This does not authorize uncertain retries or deleting unobserved candidates.
3. P2 waiter attachment uses bounded scheduling waits in this real harness. A failure to join in time can fail the test; a successful retry/cache result alone does not prove a live waiter was blocked before release. Deterministic joined-waiter synchronization remains covered by the already executed app regression tests. Describe this real-harness evidence alongside those tests.

### Pre-run review delta accepted

Re-read the complete revised harness with SHA256 `0a059260b755e6b9a133b0291cff6bb9e055e3a0463c21cbb627e091bbe77b43`. The replacement fault now requires the exact Nova compute endpoint host and project-specific `/servers` path, plus JSON `server.metadata.labbit_lab_instance_id` matching this run and generation `2`. Body reading is capped at 1 MiB, remains in memory, and is restored for upstream forwarding when not selected. The cleanup loop now performs a final fourth observation after at most three deletion attempts. Recommendations 1 and 2 are resolved in the external harness only; repository source was not changed.

Independently recomputed all 29 current repository file SHA256 values in `source-before-app-run.json`: zero mismatches. Independently recomputed the external harness hash: matches the revised manifest. Additional keypair, SG and ResourceRef ledger logs contain ownership/lifecycle metadata, not SSH output or credentials.

## Completed real execution and evidence review

Independently parsed the original `real-app-boundaries.jsonl` after completion. All seven subtests and the parent passed; no fail or skip action. Parent test: 227.71 seconds; package: 231.293 seconds. Both real VM and real app stderr artifacts are empty.

| Executed subtest | Result / seconds | Observed claim supported by source and log |
| --- | --- | --- |
| P2 real Keystone waiter deadline and cancel | PASS / 1.05 | Withheld actual authentication response; waiter deadline 80 ms and manager setup deadline 40 ms honored, waiter cancellation honored, owner/live queries succeed, factory count 1 and cached reuse |
| P2 real Keystone owner cancel and retry | PASS / 1.07 | Owner cancellation propagated; joined waiter safe shared failure; fresh real authentication and successful queries on retry; factory count 2 and cached reuse |
| P1 Reset preflight preserves SSH | PASS / 2.54 | Real missing-flavor preflight, no injected failure; only NOT_ATTEMPTED, established SSH remains usable and old target reopens |
| P1 first Cleanup deletion rejected | PASS / 1.63 | Injected exact owned worker DELETE409; workspace still exists; real SSH retired and old generation rejected before resolver |
| P1 partial Reset cleanup | PASS / 11.37 | Actual worker DELETE with independent GET404; workspace survives injected DELETE409; real Adapter FAILED shape; app closes surviving workspace SSH and fences the old target |
| P1 partial Cleanup / already absent worker | PASS / 0.64 | Actual worker deletion404, workspace injected409, real Cleanup result and app retirement/fencing |
| P1 Reset replacement creation failure | PASS / 15.17 | All 10 old generation resource deletions reported, 6 actual replacement Neutron resources retained in results, exact scoped Nova POST409 injected, stale channel/target retired |

The original log records exactly three selected DELETE409 responses and one replacement POST409 response. It then records independent Reconcile confirming all 16 distinct tracked resource IDs ABSENT, followed by separate exact temporary management SG GET404 and keypair GET404. The cleanup assertions execute before the parent PASS, so the PASS includes successful cleanup verification.

### Final read-only inventory

Read `read_only_residual_test.go` completely and confirmed it performs only authentication and SDK List/GET inventory, with no resource mutation. Harness SHA256: `8c2e7deff265da0dbb18faf96d3a1f74415237c95fd7ad724f4a720a35945729`.

Parsed `post-discovery-and-residual.jsonl`: `TestOpenStackM1Integration` PASS in 0.91 seconds; `TestLBT147ReadOnlyResiduals` PASS in 1.64 seconds; package PASS, no failure/skip and empty stderr. Post inventory servers=0, images=3, flavors=4, networks=4 matches pre-discovery. Matching test server/network/subnet/security-group/port/keypair/router counts are all zero. Other inventory totals: subnets=4, security groups=4, ports=11, keypairs=1, routers=1. These existing resources were observed, not deleted. Prefix-based inventory is supporting evidence; exact tracked-ID observation/deletion/absence above is the primary ownership and cleanup evidence.

### Source and SSOT closure

At 2026-10-12 11:44:00 KST, independently recomputed the 29 repository file byte hashes again after both actual-cloud runs and residual inventory: zero mismatch against the pre-run manifest and prior fixed-source audit. External app harness hash still `0a059260b755e6b9a133b0291cff6bb9e055e3a0463c21cbb627e091bbe77b43`. Git status remains exactly the six reviewed fix files. HEAD is not the full execution identifier by itself because the two production repairs and their regression tests remain uncommitted; the full byte manifest plus patch identifies executed source.

Read the final `source-manifest.json` (11:44:19 KST) and compared all entries to the independently verified pre-run/current hashes: 29 files, zero manifest differences, exactly six local changes, and matching app/residual harness hashes. It accurately records branch `feat/LBT-147-vm-access`, latest origin/main and unchanged merge base/HEAD.

Read the refreshed Jira/Confluence snapshot metadata and LBT-145 latest comment body. LBT-147/LBT-21 now show in-progress status; body/AC remain unchanged. D18 v5, D20 v7, D21 v10, test strategy v3 and MVP plan v19 match the prior reviewed requirements. LBT-145 comment still records KT generation-2 Reset not fully rerun successfully and two test Tier resources still present, so local OpenStack success must not be promoted to KT acceptance or entire LBT-147 dependency closure.

The initial automated comment-delta file reported a comparison mismatch caused by prior snapshot comment normalization; the implementing agent corrected this artifact after comparing original/new LBT-145 comment bodies. This reviewer read the current actual comment text and retains its unresolved KT prerequisites, rather than deriving a requirements change from that comparison artifact.

An independent marker scan of the three real execution logs found zero PEM private-key markers, X-Auth/X-Subject token headers, Basic/Bearer Authorization markers or JSON password values. This is a pattern scan; exact local-secret matching and any distributable artifact packaging are the implementing agent's final evidence checks. Harness and source inspection found no logged key/config/token/SSH-output values.

## Independent final conclusion

**PASS for the reviewed local OpenStack implementation and the repaired F1/F2 app boundaries.** No additional confirmed production defect was found. This conclusion uses the full original/fix review, meaningful automatic and real-SSH fixture regressions, current-source actual-cloud normal VM lifecycle test, actual cloud plus explicitly selected failure injection through the real app/Provider boundaries, and independent source/cleanup evidence checks.

Failure injection is explicit: Nova HTTP409 failures and Keystone response delay were synthesized by the external loopback proxy. Authentication, query responses, normal provisioning, worker/old-resource deletion, replacement Neutron creation, workspace SSH, app invalidation/cancellation logic and final inventory came from actual local OpenStack/VMs. This is not evidence that an uncontrolled actual Nova outage or Keystone slowdown occurred, nor a full SaaS/Browser/Control reconnect E2E test.

KT Cloud/LBT-145 prerequisites, SaaS/Browser/Control reconnect end-to-end flow, public WSS routing, LBT-148 Terminal integration and LBT-149 production SFTP remain outside the local OpenStack/app test boundary. The SFTP test proves subsystem/channel boundaries and probes, not production File operations. The existing managed session setup cancellation limitation can retire a shared transport to release a contextless SSH setup request and remains explicitly tracked for the subsequent channel semantics work. Full Jira completion and any future PR may be judged only within those declared limits. This review never authorizes push/PR/merge/deployment.
