from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile, re

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent/'labbit-sftp-149'
DEST = REPO/'docs/connector/evidence/LBT-149/2026-10-14'
BASE = '0599947407e9edd4539690e2f56eecf0622909ce'
SOURCE = 'a495184e13a159c0cca25256dd8d0766da83283e'
PREVIOUS = 'c753ce9c72c7f13773d3bcfbdb53bddc331343b2'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO,stderr=subprocess.DEVNULL).decode().strip()
def save(name,data): (DEST/name).write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
def read(path): return json.loads(path.read_text(encoding='utf-8'))

paths=git('diff','--name-only',BASE+'..'+SOURCE).splitlines()
files=[{'path':p,'byteSHA256':sha((REPO/p).read_bytes()),'testedGitBlob':git('rev-parse',SOURCE+':'+p),'deliveryGitBlob':git('hash-object','--path',p,p)} for p in paths]
snapBefore=read(ROOT/'live-after-storage/source-live-before.json')
snapAfter=read(ROOT/'live-after-storage/source-live-after.json')
assert snapBefore['head']==snapAfter['head']==SOURCE
assert snapBefore['files']==snapAfter['files']
mismatches=[f['path'] for f in snapBefore['files'] if sha((REPO/f['path']).read_bytes())!=f['sha256Bytes']]
assert mismatches==['runtime/contract.yaml']
runtimeBefore=subprocess.check_output(['git','show',SOURCE+':runtime/contract.yaml'],cwd=REPO)
runtimeAfter=(REPO/'runtime/contract.yaml').read_bytes()
assert runtimeBefore.replace(b'\r\n',b'\n').rstrip(b'\n')==runtimeAfter.replace(b'\r\n',b'\n').rstrip(b'\n')
binary=read(ROOT/'live-after-storage/binary-manifest.json')
assert all(sha((ROOT/'live-after-storage'/x['name']).read_bytes())==x['sha256'] for x in binary['binaries'])
save('source-manifest.json',{'recordedAt':datetime.now(timezone.utc).isoformat(),'base':BASE,'sourceHEAD':SOURCE,'branch':git('branch','--show-current'),'originMain':git('rev-parse','origin/main'),'files':files,'liveSourceBeforeAfterIdentical':True,'liveVMHelperGoSourceBytesStillMatch':True,'postTestRuntimeWhitespaceChange':{'path':'runtime/contract.yaml','testedByteSHA256':next(f['sha256Bytes'] for f in snapBefore['files'] if f['path']=='runtime/contract.yaml'),'deliveryByteSHA256':sha(runtimeAfter),'equalAfterNormalizeLineEndingsAndTrimTrailingNewlines':True,'validation':'contracts-final/source-contracts-before.json and full current Contracts PASS'},'binaryManifest':binary,'webAndInitialContractsTestedHEAD':PREVIOUS,'finalContractsTestedCandidate':'a495 + trailing empty runtime line removed; snapshot bytes identify exact candidate','subsequentChangedFiles':git('diff','--name-only',PREVIOUS+'..'+SOURCE).splitlines(),'webHTTPRuntimeWireDependencySemanticChangeAfterWebChecks':False,'baselineRunner':{'path':'docs/connector/evidence/LBT-148/2026-10-14/validate.py','byteSHA256':sha((REPO/'docs/connector/evidence/LBT-148/2026-10-14/validate.py').read_bytes())},'deliveryAdditions':'runtime trailing empty line cleanup + this Evidence directory; reviewed separately'})

runs={}
for stage in ['auto','web','contracts','contracts-final','live-final','residual','auto-after-storage','live-after-storage','residual-after-storage']:
    folder=ROOT/stage
    runs[stage]={p.name:read(p) for p in folder.glob('*-run.json')}
    for p in folder.glob('*-source-stability.json'): runs[stage][p.name]=read(p)
skips=[]
for line in (ROOT/'auto-after-storage/go-unit.log').read_text(encoding='utf-8').splitlines():
    try: event=json.loads(line)
    except ValueError: continue
    if event.get('Action')=='skip' and event.get('Test'): skips.append({'package':event['Package'],'test':event['Test']})
save('validation-summary.json',{'sourceHEAD':SOURCE,'runs':runs,'webTests':{'files':13,'tests':167,'failed':0,'testedHEAD':PREVIOUS},'automaticSkippedTests':skips,'linuxOnlyTests':'run in actual Linux VM regression binary; absent from Windows build','liveBoundary':'real local OpenStack + sshd + rooted helper/Service + PTY; no SaaS/FileWSS/Browser','initialFailures':[{'file':'live-initial-failure.log','kind':'first actual VM setup failure; cleanup7 absence; reason unknown'},{'file':'storage-classification-red.log','kind':'expected regression red before F-IO-004 fix'},{'kind':'first immediate reconnect loopback fixture failure','rawAvailability':'chat tool output only; not archived','followup':'bounded independent Read retries; no Save auto retry'}]})

included={}
for folder in ['auto','web','contracts','contracts-final','live-final','residual','auto-after-storage','live-after-storage','residual-after-storage']:
    for p in (ROOT/folder).iterdir():
        if p.is_file() and p.suffix in ['.json','.log','.txt']: included[folder+'/'+p.name]=p
for name in ['live-initial-failure.log','live-second.log','storage-classification-red.log','validate149.py','residual149.go.txt','package149.py']:
    included['historical/'+name]=ROOT/name
entries=[]
scan=[]
patterns=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'AKIA[0-9A-Z]{16}'),re.compile(rb'ghp_[A-Za-z0-9]{30,}')]
for name,path in included.items():
    b=path.read_bytes(); entries.append({'name':name,'size':len(b),'sha256':sha(b)})
    if any(p.search(b) for p in patterns): scan.append(name)
with zipfile.ZipFile(DEST/'validation-logs.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(included.items()): z.writestr(name,path.read_bytes())
with zipfile.ZipFile(DEST/'validation-logs.zip') as z:
    assert len(z.namelist())==len(included)
    assert all(sha(z.read(x['name']))==x['sha256'] for x in entries)
save('raw-log-manifest.json',{'entries':entries,'entryCount':len(entries),'archiveRoundTripHashesMatch':True,'binariesAndCredentialsExcluded':True})
for p in list(DEST.iterdir())+[REPO/x for x in paths]:
    if p.is_file() and p.suffix!='.zip' and any(x.search(p.read_bytes()) for x in patterns): scan.append(str(p.relative_to(REPO)))
save('secret-scan.json',{'rules':'private PEM headers, AWS access key shape, GitHub classic token shape; metadata/log/source manual review in audit','findings':scan,'matches':len(scan),'rawLogEntriesScanned':len(included),'limitations':'not an exhaustive entropy scanner; fixture mock secret identifiers are source-only synthetic values'})
assert not scan
save('artifact-checksums.json',{'files':[{'name':p.name,'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(DEST.iterdir()) if p.is_file() and p.name!='artifact-checksums.json']})
print(json.dumps({'sourceFiles':len(files),'rawEntries':len(entries),'zipBytes':(DEST/'validation-logs.zip').stat().st_size,'scanMatches':len(scan)}))
