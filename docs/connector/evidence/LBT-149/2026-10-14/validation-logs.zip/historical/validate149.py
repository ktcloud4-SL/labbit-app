"""LBT-149 validation wrapper; reuses the tracked portable baseline validator."""
import importlib.util
import os
from pathlib import Path
import sys

repo = Path(os.environ['LABBIT_EVIDENCE_REPO'])
baseline = repo/'docs/connector/evidence/LBT-148/2026-10-14/validate.py'
spec = importlib.util.spec_from_file_location('baseline_validator', baseline)
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
mode = sys.argv[1]
before = v.snapshot(mode+'-before')
try:
    if mode == 'auto':
        v.auto()
        v.run('workspace-race', ['go','test','-mod=readonly','-race','-json','-count=1','-timeout=3m','./internal/connector/workspacefile','./internal/connector/workspacefs'], env=v.clean_env())
    elif mode in ('web','contracts'):
        getattr(v, mode)()
    else:
        raise SystemExit('Expected auto, web or contracts')
finally:
    after = v.snapshot(mode+'-after')
    v.save(mode+'-source-stability.json', {'unchanged':before['head']==after['head'] and before['files']==after['files'], 'headBefore':before['head'], 'headAfter':after['head']})
