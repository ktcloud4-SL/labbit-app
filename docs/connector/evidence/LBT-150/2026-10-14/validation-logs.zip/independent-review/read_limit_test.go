package filetransport

import "testing"

// maxBytes is a SaaS ceiling, not a statement of the current file's size.
func TestReviewSmallReadAcceptsLargerSaaSCeiling(t *testing.T) {
	f := &testFiles{content:[]byte("a")}
	p,m := newPeer(t,f,func(c *Config){ c.MaxFileBytes=64 })
	plan := planFor("READ")
	plan.payload["maxBytes"]=65
	start(t,p,m,"READ-ceiling",plan)
	if got := code(await(t,plan.result)); got != "" {
		t.Fatalf("one-byte file failed with larger SaaS upper bound: %s",got)
	}
	await(t,plan.binary)
	idle(t,m)
}
