package filetransport

import (
	"bytes"
	"fmt"
	"testing"
	"time"
)

func TestReviewOversizeSaveReturnsStableBusinessError(t *testing.T) {
	f:=&testFiles{}
	p,m:=newPeer(t,f,func(c *Config){ c.MaxFileBytes=64 })
	for i:=0;i<100;i++ {
		plan:=planFor("SAVE")
		plan.body=bytes.Repeat([]byte("a"),65)
		plan.payload["size"]=65
		start(t,p,m,fmt.Sprintf("SAVE-over-%d",i),plan)
		select {
		case result:=<-plan.result:
			if got:=code(result);got!="TOO_LARGE" { t.Fatalf("unexpected code %s",got) }
		case closeCode:=<-plan.closed:
			select {
			case result:=<-plan.result:
				if got:=code(result);got!="TOO_LARGE" { t.Fatalf("unexpected code %s",got) }
			default:
				t.Fatalf("oversized Save's required body raced semantic failure: close=%d without TOO_LARGE result at iteration=%d",closeCode,i)
			}
		case <-time.After(time.Second): t.Fatal("no result or close")
		}
		idle(t,m)
	}
	if f.count()!=0 { t.Fatal("oversized Save reached storage") }
}
