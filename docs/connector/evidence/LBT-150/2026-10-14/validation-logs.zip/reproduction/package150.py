from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile, re, shutil

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent/'labbit-file-150'
REVIEW = ROOT.parent/'LBT-150-independent-review'
DEST = REPO/'docs/connector/evidence/LBT-150/2026-10-14'
BASE = 'ebe3f42f8b716c53e5e6f75857bf070759cccb82'
SOURCE = 'f41d20a129005d344b8f68bdd2b1de2822ac088e'
LIVE_SOURCE = '7ee9716291f54534789f32c204b6e795411dbe68'
PREVIOUS = 'c7825493f01a1d72783d77b8ebf7c8140b3d4fdc'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO,stderr=subprocess.DEVNULL).decode().strip()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def save(name,data): (DEST/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

assert git('rev-parse','HEAD')==SOURCE
for mode,stage,expected in [('auto','auto-strict-final',SOURCE),('live','live-wait-final',LIVE_SOURCE),('residual','residual-boundary-final','929ec1ac353395e23d3ba75a3586b03dbe26635f'),('helper-json','helper-strict-final',SOURCE)]:
    stable=read(ROOT/stage/(mode+'-source-stability.json'))
    assert stable['unchanged'] and stable['headBefore']==stable['headAfter']==expected, (mode,stable)
    assert all(read(p)['exitCode']==0 for p in (ROOT/stage).glob('*-run.json'))
for stage in ['web-final','contracts-final']:
    assert all(read(p)['exitCode']==0 for p in (ROOT/stage).glob('*-run.json'))

changed=git('diff','--name-only',BASE+'..'+SOURCE).splitlines()
files=[{'path':p,'byteSHA256':sha((REPO/p).read_bytes()),'testedGitBlob':git('rev-parse',SOURCE+':'+p),'deliveryGitBlob':git('hash-object','--path',p,p)} for p in changed]
assert all(f['testedGitBlob']==f['deliveryGitBlob'] for f in files)
before=read(ROOT/'live-wait-final/source-live-before.json')
assert before['localStatus']==''
liveDelta=git('diff','--name-only',LIVE_SOURCE+'..'+SOURCE).splitlines()
assert liveDelta==['internal/connector/filetransport/transport_test.go']
assert [f['path'] for f in before['files'] if sha((REPO/f['path']).read_bytes())!=f['sha256Bytes']]==liveDelta
assert sha((ROOT/'live-wait-final/labbit-workspace-sftp').read_bytes())==read(ROOT/'live-wait-final/binary-manifest.json')['helperSHA256']
subsequent=git('diff','--name-only',PREVIOUS+'..'+SOURCE).splitlines()
unchangedPrefixes=['web/','contracts/','runtime/','db/','.github/workflows/']
assert not any(p.startswith(tuple(unchangedPrefixes)) or p in ['go.mod','go.sum'] for p in subsequent)
ssot=['AGENTS.md','CONTRIBUTING.md','TESTING.md','contracts/connector/README.md','contracts/connector/file-control.schema.json','contracts/connector/file-data.schema.json','contracts/http/openapi.yaml','runtime/contract.yaml','docs/backend/README.md','docs/connector/evidence/LBT-148/2026-10-14/validate.py']
save('source-manifest.json',{'recordedAtUTC':datetime.now(timezone.utc).isoformat(),'base':BASE,'sourceHEAD':SOURCE,'liveSourceHEAD':LIVE_SOURCE,'liveToFinalChangedFiles':liveDelta,'liveToFinalDifference':'Test peer pads/ fragments JSON limit+1 for deterministic close observation; no production/actual fixture/helper changes','branch':git('branch','--show-current'),'originMain':git('rev-parse','origin/main'),'files':files,'finalSourceBeforeAfterIdentical':True,'finalLiveProductionAndFixtureSourceBytesStillMatch':True,'earlierWebContractsHEAD':PREVIOUS,'laterChangedFiles':subsequent,'webWireRuntimeDBDependencyBlobsUnchangedSinceEarlierValidation':True,'SSOT':[{'path':p,'sha256Bytes':sha((REPO/p).read_bytes()),'gitBlob':git('rev-parse',SOURCE+':'+p)} for p in ssot],'deliveryAdditions':'A–F audit/README/snapshot/manifests/review/log archive only; no executed code changes','binaryManifest':read(ROOT/'live-wait-final/binary-manifest.json')})
shutil.copyfile(ROOT/'requirements-final.json',DEST/'requirements-snapshot.json')

runs={}
included={}
for folder in sorted(ROOT.iterdir()):
    if not folder.is_dir(): continue
    runs[folder.name]={p.name:read(p) for p in folder.glob('*-run.json')}
    for p in folder.glob('*-source-stability.json'): runs[folder.name][p.name]=read(p)
    for p in folder.iterdir():
        if p.is_file() and p.suffix in ['.json','.log','.txt','.patch']: included[folder.name+'/'+p.name]=p
for p in REVIEW.iterdir():
    if p.is_file() and p.suffix in ['.json','.log','.go','.md']: included['independent-review/'+p.name]=p
included['reproduction/package150.py']=Path(__file__).resolve()
included['reproduction/repeat150.py']=ROOT/'repeat150.py'
skips=[]; reasons={}
noTestPackages=[]
for line in (ROOT/'auto-strict-final/go-unit.log').read_text(encoding='utf-8').splitlines():
    try: e=json.loads(line)
    except ValueError: continue
    if e.get('Test'):
        key=(e.get('Package'),e.get('Test'))
        if e.get('Action')=='output' and not e.get('Output','').startswith(('=== RUN','--- SKIP','--- PASS')): reasons[key]=e.get('Output','').strip()
        elif e.get('Action')=='skip': skips.append({'package':key[0],'test':key[1],'reason':reasons.get(key)})
    elif e.get('Action')=='skip' and e.get('Package'): noTestPackages.append(e['Package'])
save('validation-summary.json',{'sourceHEAD':SOURCE,'runs':runs,'web':{'files':13,'tests':167,'head':PREVIOUS},'automaticSkippedTests':skips,'automaticNoTestPackages':noTestPackages,'actualAndResidualSourceEquivalence':'Live7ee/residual929 differ from final only in unrelated TLS contract-peer test; production/helper/actualfixture/residualoverlay unchanged','realBoundary':'local OpenStack VM+sshd+SFTP helper and production Broker/Router/Connector; trusted TLS Data, fixture auth, plain loopback Control','fullBrowserSaaSE2E':False,'initialConsoleOnlyHistory':'initial duplicate constants/fake sender compile and peer budget adjustments; no invented archive','historicalRunStability':'Only final marked unchanged source snapshots support final source; prior unstable candidates are development evidence'})

patterns=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'AKIA[0-9A-Z]{16}'),re.compile(rb'ghp_[A-Za-z0-9]{30,}'),re.compile(rb'github_pat_[A-Za-z0-9_]{50,}')]
scan=[]; entries=[]
for name,p in sorted(included.items()):
    b=p.read_bytes();entries.append({'name':name,'size':len(b),'sha256':sha(b)})
    if any(x.search(b) for x in patterns):scan.append(name)
assert not scan,scan
with zipfile.ZipFile(DEST/'validation-logs.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(included.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(DEST/'validation-logs.zip') as z:
    assert len(z.namelist())==len(entries)
    assert all(sha(z.read(e['name']))==e['sha256'] for e in entries)
save('raw-log-manifest.json',{'entries':entries,'entryCount':len(entries),'archiveRoundTripHashesMatch':True,'binariesAndCredentialsExcluded':True})
save('secret-scan.json',{'rules':'PEM private key headers, AWS key shape, GitHub classic/finegrained token shapes; manual cloud logs/control fixtures review','matches':len(scan),'findings':scan,'rawEntries':len(entries),'limitations':'Not exhaustive entropy scanning. Synthetic fixture-only credential literals and generated mock key code are not actual secrets. Personal config/key files and Linux binary excluded.'})
save('artifact-checksums.json',{'files':[{'name':p.name,'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(DEST.iterdir()) if p.is_file() and p.name!='artifact-checksums.json']})
print(json.dumps({'sourceFiles':len(files),'rawEntries':len(entries),'zipBytes':(DEST/'validation-logs.zip').stat().st_size,'scanMatches':len(scan)}))
