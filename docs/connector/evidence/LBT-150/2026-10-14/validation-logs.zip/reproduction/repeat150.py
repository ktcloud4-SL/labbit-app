from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
repo=Path(os.environ['LABBIT_EVIDENCE_REPO']).resolve(strict=True)
spec=importlib.util.spec_from_file_location('repeat_validator',repo/'docs/connector/evidence/LBT-148/2026-10-14/validate.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
before=v.snapshot('helper-json-before')
try:
 v.run('helper-json-repeat',['go','test','-mod=readonly','-race','-json','-count=20','-timeout=2m','-run','^(TestInterruptedHelperDrainsSFTPAndPreservesPTY|TestMalformedFramesNeverReachSave)$','./internal/connector/workspacefile','./internal/connector/filetransport'],env=v.clean_env())
finally:
 after=v.snapshot('helper-json-after')
 v.save('helper-json-source-stability.json',{'unchanged':before['head']==after['head'] and before['files']==after['files'],'headBefore':before['head'],'headAfter':after['head']})
