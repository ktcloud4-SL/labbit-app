$ErrorActionPreference = 'Stop'
$repoDirectory = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $repoDirectory
$gofmtPath = (Get-Command gofmt).Source
$failures = @()
$crlfOnly = @()
foreach ($file in @(git ls-files '*.go')) {
    $source = [IO.File]::ReadAllText((Join-Path $repoDirectory $file))
    $normalized = $source.Replace("`r`n", "`n")
    $startInfo = [Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $gofmtPath
    $startInfo.UseShellExecute = $false
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.StandardInputEncoding = [Text.UTF8Encoding]::new($false)
    $startInfo.StandardOutputEncoding = [Text.UTF8Encoding]::new($false)
    $startInfo.StandardErrorEncoding = [Text.UTF8Encoding]::new($false)
    $startInfo.CreateNoWindow = $true
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    [void]$process.Start()
    $process.StandardInput.Write($normalized)
    $process.StandardInput.Close()
    $formatted = $process.StandardOutput.ReadToEnd()
    $diagnostic = $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    if ($process.ExitCode -ne 0 -or $normalized -cne $formatted) {
        $failures += $file
        Write-Output "FORMAT DIFFERENCE: $file $diagnostic"
    } elseif ($source -cne $formatted) {
        $crlfOnly += $file
    }
    $process.Dispose()
}
Write-Output "LF-normalized Go format differences=$($failures.Count); CRLF-only files=$($crlfOnly.Count)"
$crlfOnly | ForEach-Object { Write-Output "CRLF only: $_" }
if ($failures.Count -gt 0) { exit 1 }
