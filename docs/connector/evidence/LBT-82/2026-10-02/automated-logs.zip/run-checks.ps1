$ErrorActionPreference = 'Continue'
$repoDirectory = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $repoDirectory
$results = @()
function Invoke-Check {
    param([string]$Name, [string[]]$Arguments)
    & go @Arguments 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot ($Name + '.jsonl')) | Out-Null
    $code = $LASTEXITCODE
    $script:results += [pscustomobject]@{ name=$Name; command=('go '+($Arguments -join ' ')); exitCode=$code }
    Write-Output "$Name exit=$code"
}
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'check-normalized-format.ps1') 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'format.log') | Out-Null
$results += [pscustomobject]@{ name='LF-normalized-format'; exitCode=$LASTEXITCODE }
Invoke-Check 'vet' @('vet','./...')
Invoke-Check 'all-unit' @('test','-json','-count=1','-timeout=5m','./...')
Invoke-Check 'build' @('build','./...')
Invoke-Check 'regressions-20' @('test','-json','-count=20','-timeout=2m','-run','TestValidateConnection|TestRunSSHCommandCancellation|TestProvisionWithoutStartupScript|TestControlWSSFailedReset|TestRecordingProviderFailedProvision','./internal/connector/provider/openstack')
$env:CGO_ENABLED='1'
Invoke-Check 'connector-race' @('test','-race','-json','-count=1','-timeout=5m','./internal/connector/...','./internal/server/connector','./internal/server/connectorwss')
$results | ConvertTo-Json -Depth 4 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'checks.json')
if (@($results | Where-Object { $_.exitCode -ne 0 }).Count) { exit 1 }
