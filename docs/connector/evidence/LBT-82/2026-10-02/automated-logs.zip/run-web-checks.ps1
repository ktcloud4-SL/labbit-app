$ErrorActionPreference = 'Continue'
$repoDirectory = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath (Join-Path $repoDirectory 'web')
$results = @()

function Invoke-WebCheck {
    param([string]$Name, [string[]]$NodeArguments)
    & node @NodeArguments 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot ($Name + '.log'))
    $code = $LASTEXITCODE
    $script:results += [pscustomobject]@{ name = $Name; command = ('node ' + ($NodeArguments -join ' ')); exitCode = $code }
    Write-Output "$Name exit=$code"
}

Invoke-WebCheck 'final-web-typecheck' @('node_modules/typescript/bin/tsc', '--noEmit')
Invoke-WebCheck 'final-web-lint' @('node_modules/eslint/bin/eslint.js', '.', '--max-warnings=0')
Invoke-WebCheck 'final-web-test' @('node_modules/vitest/vitest.mjs', 'run')
Invoke-WebCheck 'final-web-build' @('node_modules/vite/bin/vite.js', 'build')
$results | ConvertTo-Json -Depth 4 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'web-check-results.json')
if (@($results | Where-Object { $_.exitCode -ne 0 }).Count -gt 0) { exit 1 }
