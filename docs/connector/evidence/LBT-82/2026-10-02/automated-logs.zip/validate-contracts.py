import json
from pathlib import Path
import yaml
from jsonschema import Draft202012Validator
from openapi_spec_validator import validate

validate(yaml.safe_load(Path('contracts/http/openapi.yaml').read_text(encoding='utf-8')))
print('OpenAPI: PASS')
def walk(node, document, path):
    if isinstance(node, dict):
        ref = node.get('$ref')
        if isinstance(ref, str) and ref.startswith('#/'):
            current = document
            for raw in ref[2:].split('/'):
                token = raw.replace('~1','/').replace('~0','~')
                if not isinstance(current, dict) or token not in current:
                    raise RuntimeError(f'{path}: unresolved local ref {ref}')
                current = current[token]
        for value in node.values(): walk(value, document, path)
    elif isinstance(node, list):
        for value in node: walk(value, document, path)
for path in sorted(Path('contracts').rglob('*.json')):
    schema = json.loads(path.read_text(encoding='utf-8'))
    assert schema.get('$schema') == Draft202012Validator.META_SCHEMA['$id']
    Draft202012Validator.check_schema(schema)
    walk(schema, schema, path)
    print(f'{path}: Draft 2020-12 PASS')
assert isinstance(yaml.safe_load(Path('runtime/contract.yaml').read_text(encoding='utf-8')), dict)
prefixes = [p.name.split('_',1)[0] for p in Path('db/migrations').glob('[0-9]*_*.sql')]
assert len(prefixes) == len(set(prefixes))
print('Runtime/Migration metadata: PASS (not PostgreSQL execution)')
