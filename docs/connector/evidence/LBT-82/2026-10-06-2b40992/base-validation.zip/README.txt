LBT-82 / PR #48 — 현재 소스의 최종 로컬 검증 증적

실행 소스: 2b40992279e16b8593c244c9169df72053a4622c
Git tree: 40c8cad13bd5f308b1459a066682870e65e00872
통합 main: 32ead4d12b0d3f4b56a66c9007273e261dad62ed
실 OpenStack 실행: 2026-10-06 19:20–19:29 Asia/Seoul
원격 PR: https://github.com/ktcloud4-SL/labbit-app/pull/48

상태
- 이 폴더는 ignored 로컬 증적이다. 원격 push, PR/Jira/Confluence 게시, main merge는 하지 않았다.
- Go/race/Web/Contracts/실 PostgreSQL은 같은 2b409922에서 앞서 실행한 원본 로그를 그대로 모았다.
- 아래 OpenStack 로그는 이번에 2b409922에서 새로 실행했다. 부모 b529357의 결과를 현재 결과로 재사용하지 않았다.
- 이번 실환경 단계에서 제품 코드나 tracked 테스트를 추가 수정하지 않았다.
- 최종 증적 독립 검토 상태는 independent-audit.json의 마지막 pass 및 verdict를 확인한다.

검증 결과
검사                              결과 및 한계
Go 기본                           포맷 읽기 검사/vet/build PASS. vet/build는 동일 SHA에서 추가 실행한 exit0 transcript도 포함. 26패키지, 테스트·하위테스트 2268 PASS / 0 FAIL / 6 SKIP.
Connector/Backend 경계 race        10패키지, 1002 PASS / 0 FAIL / 5 OpenStack opt-in SKIP.
Web                               typecheck/lint/build PASS, 9파일 109테스트 PASS. HTTP smoke PASS는 이전 동일 SHA 실행의 root attestation이며 독립 검토 가능한 HTTP exit transcript는 없음.
Contracts                         OpenAPI/6 JSON Schema/runtime/migration 검증 PASS. 로컬 RESET shape 회귀 11 PASS.
실 PostgreSQL 16.15                격리된 로컬 DB, 5패키지 854 PASS / 0 FAIL / 0 SKIP.
Backend oversized-frame 회귀       실 PostgreSQL + race 10회 PASS. 생성한 DB 잔여 0, 소유한 테스트 PG 종료.
실 OpenStack M1                    시작 조회 PASS 1.27s, 종료 조회 PASS 0.85s.
Mock SaaS → 실제 Provider          WSS 전체 lifecycle PASS 229.88s, 선택 target SKIP 없음.
실 Internet ON/OFF                 ON PASS 113.44s, OFF PASS 139.45s, 두 분기 모두 실제 실행.
Cleanup 및 fixture 사후 조회       아래 범위에서 residual 0.

실제 lifecycle 관측
1. Mock SaaS Control 메시지를 실제 Client/Handler를 통해 실제 OpenStack Adapter에 전달.
2. Provision(generation 1): 생성 리소스 8개, StartupScript + 인증된 SSH + cloud-init 완료 + 서버 ID 기반 host-key pin 경로.
3. Reset(generation 2): 이전 generation 정리 후 새 리소스 8개. StartupScript/SSH/pin 경로 재실행.
4. Reconcile(g2): 8개 PRESENT.
5. Cleanup(g2): 8개 deleted.
6. final Reconcile: g1+g2의 서로 다른 Provider ID 16개가 모두 ABSENT, 해당 리소스 residual 0.
7. 전체 서버/네트워크 조회는 시작과 종료 모두 server 0 / network 4. 기존 네트워크 4개를 삭제하거나 프로젝트 전체 리소스 0이라고 주장하지 않는다.
8. 독립 검토가 지적한 fixture 증적 누락을 보완: 임시 Management SG prefix와 임시 keypair prefix를 읽기 전용 사후 조회, 각각 0.

Internet 범위
- 각 ON/OFF 분기에서 VM에 인증된 SSH로 접속한 후 VM 내부에서 1.1.1.1:443 TCP 연결을 검사했다.
- ON은 실제 연결 성공, OFF는 실제 연결 차단을 확인했다. SSH 실패를 OFF 성공으로 취급하지 않는다.
- DNS/UDP/IPv6/모든 목적지/여러 VM의 정책까지 증명한 것은 아니다.

요구사항 → 구현 → 검증 추적성 요약
요구사항              구현/자동 회귀                         실환경 증적                           남은 범위
LBT-82 latest main     main32ead4d 통합, Go/경계 race         real-wss-lifecycle.jsonl               app.Run/Supervisor 실환경, 실제 SaaS는 별도
D-26 strict RESET     main schema/type/양쪽 validator 유지   g1→g2 실제 Handler+Provider           Backend durable Operation Worker는 별도
D-19 generation       Reset guard/cleanup/provision 회귀     g1/g2 생성 및 16개 최종 ABSENT         실제 부분 삭제 실패/ID 재사용 미실행
D-18 network/SG       소유권/egress 검증 회귀                 real-internet-policy.jsonl             다중 VM/DNS/UDP/IPv6 미실행
D-20/D-24 cleanup     부분 실패/UNKNOWN/Fake 회귀             final Reconcile 및 fixture census     실제 장애/재시작/lease 미주입
Startup/SSH identity  host-key/cancel/worker Fake 회귀        Provision/Reset 인증 SSH + startup     브라우저 PTY/C2·실제 IP 재사용은 별도
A1 long logicalName   244/245/255 roundtrip,256 거절          일반 workspace lifecycle만 실행        긴 키 cloud 실환경은 미실행
A2 final JSON cap     1MiB/초과 Mock 및 실제 PG 1009 회귀     정상 크기 실제 WSS lifecycle           대형 실제 catalog·기관 query E2E 미실행
A3 reauthentication   public New Fake401/동시 refresh 회귀   일반 실제 Keystone 인증/lifecycle     실제 token TTL 만료는 미실행
재현 가능한 Evidence  SHA/tree/blob/hash/명령/환경변수 명시   이 폴더의 원본 로그                    로컬 저장이며 아직 원격 게시 안 함

전체 추적성 및 findings는 independent-audit.json을 확인한다.
validation-summary.json에는 latest main 대비 전체 diff 92개 파일의 blob ledger가 있다.
source-manifest.json은 historical docs/connector/evidence를 제외한 tracked 소스 339개 blob을 식별한다.
ignored fixture-census.go와 재현 스크립트는 제품 소스가 아니며 artifact-checksums.json으로 별도 식별한다.

Findings 처리 및 독립 검토
- A1: Provider가 생성한 긴 logicalName을 다시 거절하던 lifecycle 불일치 수정(48ae47f).
- A2: Provider 조회 응답 최종 JSON 1MiB 제한 및 안전한 실패 응답 수정(b529357).
- A3: 갱신 가능한 인증의 bounded reauthentication 수정(b529357). UNKNOWN mutation을 자동 재실행하지 않음.
- M1: 충돌 병합 뒤 남은 중복 RESET 검사 제거, main의 canonical 검사 유지(27913b3).
- A4: 사용자 승인하에 Backend oversized 방어 테스트 한 파일만 수정(2b409922). 제품 Backend/Router/RESET/DB는 수정하지 않음.
- E1(P3): SG/keypair fixture의 사후 삭제 증적 누락을 현재 실행의 read-only census로 보완. 제품/테스트 변경 없음.
- 전체 diff 기준 검토 후 A1/A2/A3/A4 수정 delta를 분리된 reviewer가 재검토했다. 이전 판단/실패는 역사로 남기며 현재 상태와 혼동하지 않는다.
- 최종 combined-pack 독립 검토 및 해시 검증 결과는 independent-audit.json에 기록한다.
- E2(P3): vet/build 및 dev HTTP smoke의 exit 증적 부족을 지적받았다. vet/build는 같은 SHA에서 재실행한 원본 transcript로 보완했다. HTTP smoke는 root attestation으로 구분하고 이번 보충 실행은 shell policy가 launch 전에 차단하여 새로운 HTTP 검증이라고 주장하지 않는다. Web 자동 테스트/빌드나 실환경 cloud 실패는 아니다.

미실행/잔여 위험
- 실제 배포 SaaS/TLS443 HELLO/Heartbeat/reconnect(G1), 실제 app.Run/lazyProvider/Supervisor+cloud, Browser/SaaS Terminal C2는 실행하지 않았다.
- 다중 VM/다중 Lab의 실환경 실패·복구·재시작·quota 고갈·부분 삭제·응답 유실·ID/IP 재사용은 Fake 회귀와 구분한다.
- standalone M2/M3 및 M1 network-mutation target을 별도로 추가 실행하지 않았다. 이번 full lifecycle은 WSS target으로 검증했다.
- Go 기본 검사의 opt-in 5개 skip와 Windows POSIX 0600 assertion skip는 숨기지 않는다. Windows ACL 보장은 구현/검증하지 않았다.
- 기존 main의 sentAt/non-hex digest drift(F6), 이전 Internet ON 최초 실패 원인 미확정은 이전 리뷰의 non-blocking 위험으로 유지한다.
- Backend의 institutional ProviderResponse routing 및 durable READY/Terminal 소유권 경로는 이 PR의 실제 E2E 성공으로 주장하지 않는다.
- 실제 token TTL 만료/credential rotation, giant catalog 메모리/페이지네이션, 기존 SDK service/catalog deadline 한계는 별도 위험이다.
- 로컬 Windows Go1.27.1/Node24/Python3.12 검사는 Ubuntu Actions 환경과 동일하지 않다. 아직 원격 CI를 실행하지 않았다.
- 검사 PASS는 팀장님의 최종 승인/main merge 또는 Jira 완료 처리를 대신하지 않는다.

재현 방법
1. 이 pack의 reproduce.ps1과 fixture-census.go를 checkout 밖 같은 폴더에 저장한다.
2. 위 exact commit의 clean checkout에서 PowerShell7/Go1.27.1/GCC(CGO_ENABLED=1)를 준비한다.
3. 실제 customer-local clouds.yaml 및 runtime 계약에 맞는 Connector 전용 Ed25519 SSH 개인키를 호출자가 제공한다. 비밀/실제 endpoint/키 내용은 이 pack에 포함하지 않는다.
4. OpenStack image/flavor/network 및 실행 계정 권한이 필요하다. 테스트는 자체 키에 맞는 임시 keypair와 제한된 Management SG를 만든 후 정리한다. 공유/customer 리소스 삭제 권한을 의미하지 않는다.
5. 아래 명령은 먼저 일반 Go/race를 실행하고 각 OpenStack gate를 초기화한 뒤 cloud target을 순차 실행한다.

pwsh -NoProfile -File <pack-folder>/reproduce.ps1 -ProviderConfigFile <customer-clouds.yaml> -SSHPrivateKeyFile <matching-key-file> -CloudName labbit-test -SSHUsername ubuntu

필요하면 -WithPostgres -WithWeb -WithContracts를 추가한다. PostgreSQL은 격리된 16.x/CREATE DATABASE 권한으로 LABBIT_TEST_DATABASE_DSN을 설정하고, Web은 lockfile 의존성, Contracts는 execution-manifest의 validator 버전을 준비한다.
실 PostgreSQL oversized-frame 반복 회귀는 별도로 다음과 같이 재실행한다(같은 격리 DB 환경).
go test -json -race -tags integration -mod=readonly -run '^TestConnectorClientOversizedMessageIsClosedWith1009$' -count=10 -timeout=8m ./internal/server/app
실패/UNKNOWN 발생 시 자동 재시도하지 말고 생성된 리소스 소유권·Cleanup을 먼저 점검한다.

주요 파일
- execution-manifest.json: 정확한 명령, opt-in gate, 제한시간, 환경/버전, secret 제외 정책.
- validation-summary.json: PASS/FAIL/SKIP 수치, 실환경 결과, 전체 diff ledger.
- independent-audit.json: SSOT 출처, findings, 추적성, 독립 리뷰/검토 제외 영역.
- real-*.jsonl/json: 이번 exact commit의 실환경 원본 결과.
- go-vet-build-transcript.json: 같은 SHA에서 보충 실행한 명령/시간/stdout·stderr/exit0.
- fixture-census.go: 사후 fixture prefix 조회만 하는 ignored 읽기 전용 진단.
- secret-scan.json: 알려진 credential/key/endpoint와 고신뢰 marker 검사. 완전한 DLP라는 의미는 아님.
- artifact-checksums.json: 이 폴더 파일별 SHA256/byte 크기. checksum 파일 자체는 외부 해시로 검증 가능.
- PR-review-update.txt: 게시하지 않은 로컬 재리뷰 요청 초안.

외부 SSOT
Jira: https://samsunglions.atlassian.net/browse/LBT-82
GitHub review: https://github.com/ktcloud4-SL/labbit-app/pull/48
Confluence D-26 page ID28672005 / 검증 전략 page ID9666637 및 관련 D-17/18/19/20/24.
Git wire/runtime 계약이 실제 필드의 SSOT이며 Confluence는 확정 결정/검증 전략 근거다.
