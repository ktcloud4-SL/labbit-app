package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/gophercloud/gophercloud/v2/openstack"
	"github.com/gophercloud/gophercloud/v2/openstack/compute/v2/keypairs"
	openstackconfig "github.com/gophercloud/gophercloud/v2/openstack/config"
	"github.com/gophercloud/gophercloud/v2/openstack/config/clouds"
	"github.com/gophercloud/gophercloud/v2/openstack/identity/v3/tokens"
	"github.com/gophercloud/gophercloud/v2/openstack/networking/v2/extensions/security/groups"
)

// Read-only evidence helper, not product source or an extra lifecycle test.
// Emit counts only; never print auth, endpoint, key or raw Provider errors.
func main() {
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	auth, endpoint, tlsConfig, err := clouds.Parse(
		clouds.WithLocations(os.Getenv("LABBIT_PROVIDER_CONFIG_FILE")),
		clouds.WithCloudName(os.Getenv("OS_CLOUD")),
	)
	if err != nil || (tlsConfig != nil && tlsConfig.InsecureSkipVerify) {
		fail("config unavailable or insecure")
	}
	provider, err := openstackconfig.NewProviderClient(ctx, auth, openstackconfig.WithTLSConfig(tlsConfig))
	if err != nil {
		fail("authentication unavailable")
	}
	result, ok := provider.GetAuthResult().(tokens.CreateResult)
	if !ok {
		fail("scoped project unavailable")
	}
	project, err := result.ExtractProject()
	if err != nil || project == nil || project.ID == "" {
		fail("scoped project unavailable")
	}
	network, err := openstack.NewNetworkV2(provider, endpoint)
	if err != nil {
		fail("network service unavailable")
	}
	compute, err := openstack.NewComputeV2(provider, endpoint)
	if err != nil {
		fail("compute service unavailable")
	}
	groupPages, err := groups.List(network, groups.ListOpts{ProjectID: project.ID}).AllPages(ctx)
	if err != nil {
		fail("security group discovery failed")
	}
	groupItems, err := groups.ExtractGroups(groupPages)
	if err != nil {
		fail("security group extraction failed")
	}
	keyPages, err := keypairs.List(compute, keypairs.ListOpts{}).AllPages(ctx)
	if err != nil {
		fail("keypair discovery failed")
	}
	keyItems, err := keypairs.ExtractKeyPairs(keyPages)
	if err != nil {
		fail("keypair extraction failed")
	}
	managementSGs, integrationKeys := 0, 0
	for _, item := range groupItems {
		if strings.HasPrefix(item.Name, "labbit-integration-management-") {
			managementSGs++
		}
	}
	for _, item := range keyItems {
		if strings.HasPrefix(item.Name, "labbit-integration-key-") {
			integrationKeys++
		}
	}
	if err := json.NewEncoder(os.Stdout).Encode(map[string]any{
		"sourceCommit":                      os.Getenv("LABBIT_EVIDENCE_SOURCE_SHA"),
		"observedAt":                        time.Now().UTC().Format(time.RFC3339Nano),
		"readOnly":                          true,
		"temporaryManagementSecurityGroups": managementSGs,
		"temporaryIntegrationKeypairs":      integrationKeys,
		"scope":                             "scoped project SGs and authenticated user keypairs, test-fixture name prefixes only; no deletion",
	}); err != nil {
		fail("evidence encoding failed")
	}
	if managementSGs != 0 || integrationKeys != 0 {
		os.Exit(2)
	}
}

func fail(message string) {
	fmt.Fprintln(os.Stderr, message)
	os.Exit(1)
}
