param(
    [Parameter(Mandatory=$true)][string]$ProviderConfigFile,
    [Parameter(Mandatory=$true)][string]$SSHPrivateKeyFile,
    [string]$CloudName='labbit-test',
    [string]$SSHUsername='ubuntu',
    [string]$PythonExecutable='python',
    [switch]$WithPostgres,
    [switch]$WithWeb,
    [switch]$WithContracts
)
$ErrorActionPreference='Stop'
$expectedCommit='2b40992279e16b8593c244c9169df72053a4622c'
# Save outside checkout. Use PowerShell7, Go1.27.1; GCC/CGO for race.
# Supply the Connector-owned matching Ed25519 management key per runtime contract.
# Optional Web requires installed lockfile dependencies; Contracts requires
# PyYAML6.0.3/openapi-spec-validator0.9.0/jsonschema4.26.0.
if ((git rev-parse HEAD) -ne $expectedCommit -or @(git status --porcelain).Count) { throw 'Checkout the clean exact tested source SHA' }
if (-not (Test-Path -LiteralPath $ProviderConfigFile -PathType Leaf) -or -not (Test-Path -LiteralPath $SSHPrivateKeyFile -PathType Leaf)) { throw 'Customer-local Provider config and matching SSH key files are required' }
$outputDirectory=Join-Path (Get-Location).Path ('.local/evidence/reproduced-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $outputDirectory | Out-Null
$gates=@('LABBIT_OPENSTACK_INTEGRATION','LABBIT_OPENSTACK_MUTATION_TEST','LABBIT_OPENSTACK_M2_TEST','LABBIT_OPENSTACK_M3_TEST','LABBIT_OPENSTACK_M2_WSS_TEST','LABBIT_OPENSTACK_M3_WSS_TEST','LABBIT_OPENSTACK_INTERNET_POLICY_TEST')
foreach($gate in $gates) { Remove-Item -LiteralPath ('Env:'+$gate) -ErrorAction SilentlyContinue }
$env:CGO_ENABLED='1'
function Invoke-RecordedGo([string]$Name, [string[]]$Arguments) {
    & go @Arguments 2>&1 | Tee-Object -FilePath (Join-Path $outputDirectory ($Name+'.jsonl')) | Out-Null
    if ($LASTEXITCODE) { throw ($Name+' failed; inspect log, do not blindly retry mutations') }
    Write-Output ($Name+' PASS')
}
Invoke-RecordedGo 'go-vet' @('vet','-mod=readonly','./...')
Invoke-RecordedGo 'go-unit' @('test','-json','-mod=readonly','-count=1','-timeout=5m','./...')
Invoke-RecordedGo 'go-build' @('build','-mod=readonly','./...')
Invoke-RecordedGo 'connector-race' @('test','-json','-race','-mod=readonly','-count=1','-timeout=8m','./internal/connector/...','./internal/server/connector','./internal/server/connectorwss/...')
if ($WithPostgres) {
    if ([string]::IsNullOrWhiteSpace($env:LABBIT_TEST_DATABASE_DSN)) { throw 'Set LABBIT_TEST_DATABASE_DSN to isolated PostgreSQL16 with CREATE DATABASE permission; never a shared or production DB' }
    $packages=@('./internal/postgres','./internal/postgres/postgrestest','./internal/server/app','./internal/server/auth','./internal/server/httpapi')
    Invoke-RecordedGo 'postgres-vet' (@('vet','-tags','integration')+$packages)
    Invoke-RecordedGo 'postgres-integration' (@('test','-json','-tags','integration','-mod=readonly','-count=1','-timeout=8m')+$packages)
}
if ($WithWeb) {
    Push-Location web
    try {
        foreach($target in @('typecheck','lint','test','build')) {
            & npm run $target 2>&1 | Tee-Object -FilePath (Join-Path $outputDirectory ('web-'+$target+'.log')) | Out-Null
            if ($LASTEXITCODE) { throw ('web '+$target+' failed') }
        }
    } finally { Pop-Location }
}
if ($WithContracts) {
    $env:PYTHONDONTWRITEBYTECODE='1'
    & $PythonExecutable -m openapi_spec_validator contracts/http/openapi.yaml
    if ($LASTEXITCODE) { throw 'OpenAPI invalid' }
    $workflow=Get-Content -LiteralPath .github/workflows/contracts.yml -Raw
    $scripts=[regex]::Matches($workflow,"(?ms)          python <<'PY'\r?\n(.*?)          PY")
    if ($scripts.Count -ne 2) { throw 'Inspect changed Contracts workflow before reproduction' }
    foreach($script in $scripts) {
        & $PythonExecutable -c ([regex]::Replace($script.Groups[1].Value,'(?m)^          ',''))
        if ($LASTEXITCODE) { throw 'Contracts invalid' }
    }
    & $PythonExecutable -m unittest discover -s contracts/connector/tests -v
    if ($LASTEXITCODE) { throw 'RESET regression failed' }
}
$env:LABBIT_PROVIDER_CONFIG_FILE=$ProviderConfigFile
$env:OS_CLOUD=$CloudName
$env:LABBIT_OPENSTACK_SSH_USERNAME=$SSHUsername
$env:LABBIT_OPENSTACK_SSH_PRIVATE_KEY_FILE=$SSHPrivateKeyFile
foreach($target in @(
    @{name='TestOpenStackM1Integration';gate='LABBIT_OPENSTACK_INTEGRATION';timeout='2m';log='real-baseline'},
    @{name='TestOpenStackM2ControlWSSIntegration';gate='LABBIT_OPENSTACK_M3_WSS_TEST';timeout='20m';log='real-wss-lifecycle'},
    @{name='TestOpenStackInternetPolicyIntegration';gate='LABBIT_OPENSTACK_INTERNET_POLICY_TEST';timeout='25m';log='real-internet-policy'},
    @{name='TestOpenStackM1Integration';gate='LABBIT_OPENSTACK_INTEGRATION';timeout='2m';log='real-post-cleanup'}
)) {
    foreach($gate in $gates) { Remove-Item -LiteralPath ('Env:'+$gate) -ErrorAction SilentlyContinue }
    Set-Item -LiteralPath ('Env:'+$target.gate) -Value '1'
    Invoke-RecordedGo $target.log @('test','-json','-mod=readonly','-count=1',('-timeout='+$target.timeout),'-run',('^'+$target.name+'$'),'./internal/connector/provider/openstack')
    $events=Get-Content -LiteralPath (Join-Path $outputDirectory ($target.log+'.jsonl')) | ConvertFrom-Json
    if (-not @($events | Where-Object {$_.Action -eq 'pass' -and $_.Test -eq $target.name}).Count) { throw 'Selected target skipped/failed: not PASS' }
}
$fixtureCensus=Join-Path $PSScriptRoot 'fixture-census.go'
if (-not (Test-Path -LiteralPath $fixtureCensus -PathType Leaf)) { throw 'Keep fixture-census.go beside this reproduction script' }
$env:LABBIT_EVIDENCE_SOURCE_SHA=$expectedCommit
& go run -mod=readonly $fixtureCensus | Tee-Object -FilePath (Join-Path $outputDirectory 'real-fixture-census.json')
if ($LASTEXITCODE) { throw 'Read-only fixture census failed or found remaining fixture prefixes; inspect ownership, never delete unrelated resources' }
Write-Output ('Tested '+$expectedCommit+'; output='+$outputDirectory)

