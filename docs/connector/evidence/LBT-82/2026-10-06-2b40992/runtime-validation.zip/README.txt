LBT-82 / PR48 — additional local runtime acceptance evidence

Product source: 2b40992279e16b8593c244c9169df72053a4622c
Product tree: 40c8cad13bd5f308b1459a066682870e65e00872
Integrated/current observed main: 32ead4d12b0d3f4b56a66c9007273e261dad62ed
Date: 2026-10-06 Asia/Seoul
Scope: local only. No push, PR/Jira/Confluence publication or main merge.
Product/tracked test code is unchanged in this additional verification.

This is a supplementary pack, not a rewrite of historical evidence.
Prior exact-source Go/race/Web/Contracts/PostgreSQL/full-diff92-file audit:
../LBT-82-2b40992-final-20261006/publication
Historical logs/claims/limitations in that pack retain their original scope.

Test inputs outside the product commit
- runtime_probe_test.go, posix_probe_test.go, reauth_probe_test.go: ignored,
  separately hashed acceptance tooling. Include these files when sharing evidence.
- runtime core was compiled before the two supplementary test files were added.
  Its executed runtime_probe_test.go SHA256 is
  06c09f1fda01e91a470c33408de3950fae674c89adc4f90b917a65820f669553.
- Product Go dependencies are the repository's unchanged go.mod/go.sum.
- All opt-in gates are explicit. Gate-off compile/vet success is not live PASS.
- Temporary test credentials/public test CA are freshly generated and are not
  deployment credentials. Raw PTY bytes and cloud secrets are not persisted.

Runtime fixture architecture
- Real public app.Run(ctx) runs in an isolated helper subprocess, production
  environment mode, actual Supervisor/Handler/lazy Provider/Terminal wiring.
- The locally generated trusted TLS peer substitutes only SaaS Control/Data.
  Full certificate/hostname validation remains enabled; no InsecureSkipVerify.
- Test peer trust is isolated to the child. Parent OpenStack fixture cleanup
  retains its normal verifier. All cloud catalog endpoints must be HTTP before
  mutation. This lab's OpenStack-side TLS is therefore NOT validated.
- HELLO_ACK uses accelerated 1s/5s timings, not a 45s deployed OFFLINE test.
- Existing customer private key is read-only; each cloud mutation run imports
  a unique matching temporary keypair and creates a solely owned Management SG.
- Test resources have generated lab IDs. Cleanup uses exact returned IDs,
  never name/tag-only adoption. Discovered candidates are observations, not
  deletion authority. Global server/network counts are supporting evidence.
- An unexpected lost mutation result would require exact-ID/manual recovery;
  it is not converted into permission to delete arbitrary candidate resources.

Reproduction
1. Use a clean checkout of the exact product commit above, with these separately
   hashed helper files in the same ignored directory under the module.
2. Configure the caller's local clouds.yaml, OS_CLOUD and matching Ed25519 key.
   Update runner paths/fixture image, flavor, management network/CIDR for a
   separate test environment. Never point these tests at shared/prod resources.
3. Sequentially execute run-runtime.ps1, run-posix.ps1, run-reauth.ps1.
   Each run may create/delete only its own cloud fixtures/tokens. Do not run
   same-cloud acceptance helpers in parallel.
4. Core target: TestProductionAppRunRealOpenStack (45m Go timeout).
   Linux target: TestPOSIXCredentialOnRealLinuxVM (15m Go timeout).
   Token target: TestRealKeystoneOwnedTokenReauthentication (5m Go timeout).
5. run-posix records immediate cross-build source/flags/exit/hash/build metadata.
   It executes the existing TestInstallCredentialFile binary on a disposable
   Linux VM via pinned SSH. Storage remains the existing Fake transactor.
6. Reauth revokes ONLY tokens proven issued for its isolated helper. Token
   values remain in RAM; cleanup must confirm invalidation. No credential
   rotation, project quota change or global Keystone TTL change is performed.

Initial failed attempt
- runtime-real.jsonl: external-network extension decoding in the new harness
  incorrectly hid the external flag; test stopped before cloud mutations.
- Observed baseline/post-run were both server0/network4. The harness decoder
  was corrected; this is not a product-source change or lifecycle PASS.
- The first harness revision's separate hash was not retained. The corrected
  live core source is identified above; never relabel the first run as PASS.

Claim boundaries / exclusions
- Local TLS mock SaaS is not an actual deployed SaaS G1/443 acceptance result.
- Main's frontend LabPage terminal section remains a placeholder; no real
  browser Terminal/C2 screen is claimed. Backend terminal API/relay exists,
  but full Operation Worker/result sink is not yet wired in main.
- Direct app.Run(ctx) cancellation is tested, not cmd/connector OS-signal flow.
- Data reconnect demonstrates the same PTY, not a deliberately gated historical
  output replay/fan-out/grace-expiry test. Peer resumed/history flags alone do
  not prove the real Backend relay behavior.
- Deleted old Server ID refusal is not forced ID reuse. IP reuse is not forced.
- Network claims: VM-local IPv4 TCP443 to 1.1.1.1 and 1.0.0.1; direct UDP DNS53
  to 1.1.1.1 with matching response transaction/source/QR/rcode; no IPv6 default
  route observed. Not all destinations/ports/protocols, IPv6 reachability, OS
  resolver/cached DNS or every VM's egress enforcement.
- Own-token revocation/reauthentication is not natural TTL expiry. Glance401 is
  inferred from SDK recovery, not directly observed at the transport layer.
- No shared quota exhaustion, global token/credential revoke, user image
  removal or intentional ambiguous mutation-result loss is injected.
- Linux POSIX0600 is not Windows ACL validation; main does not implement an
  equivalent Windows ACL confidentiality guarantee.
- Remote CI requires an authorized push; it was not run for this local source.
- The prior Web dev-HTTP smoke has an attestation-only transcript limitation;
  no new HTTP launch is claimed here. Prior raw Web unit/build logs remain valid.

Latest SSOT observations
- Jira LBT-82, LBT-20, LBT-22 and Confluence D17/D18/D19/D20/D26/validation
  strategy were freshly read during this work. Git remains wire/runtime SSOT.
- D26's historical 'remaining risk' paragraph is not a current build-status
  tracker: Backend74 is already in integrated main32ead4d. No remote doc edits.

Final observed results
- Runtime real acceptance: PASS, 1360.62s, 1 run / 0 fail / 0 skip.
- Linux POSIX credential test: PASS, 111.40s, 1 run / 0 fail / 0 skip.
- Real helper-token invalidation/re-authentication: PASS, 4.07s,
  1 run / 0 fail / 0 skip. Both helper-issued tokens confirmed INVALID.
- Success lifecycle old/new22refs, fault8refs, no-script10refs,
  worker-failure11refs and Linux7refs were individually confirmed ABSENT.
- Core and Linux baseline/post census: servers0/networks4. Owned temporary
  keypairs and Management SGs also confirmed ABSENT; customer ones unchanged.
- Worker case proves controlled failing-input Provider failure and cleanup,
  not directly collected guest cloud-init exit code or failure cause.
- See verification-summary.json for SSOT-to-code-to-executed-evidence mapping,
  exact timestamps, failure path distinctions and remaining limits.
- See independent-audit.json for the separate reviewer pass; artifact-checksums
  bind evidence/tools, including the externally supplied Linux executable.
- Product source remains unchanged; no remote CI/push/publication occurred.
- POSIX/reauth logs do not directly print executed helper-source hashes.
  Final-package helper hashes support reproduction, not retroactive execution
  proof. Core's pre-execution hash is retained separately. Independent review
  reported no new P0-P2 findings in this evidence scope; see audit P3 limits.
