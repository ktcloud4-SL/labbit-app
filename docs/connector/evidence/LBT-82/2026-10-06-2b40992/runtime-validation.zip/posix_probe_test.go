package runtimeprobe

import (
	"archive/tar"
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/google/uuid"
	p "github.com/ktcloud4-SL/labbit-app/internal/connector/protocol"
	"golang.org/x/crypto/ssh"
)

// Exact existing POSIX assertion on a solely owned disposable Linux VM.
// The database/storage layer remains Fake, exactly as in main_test.go.
func TestPOSIXCredentialOnRealLinuxVM(t *testing.T) {
	if os.Getenv("LABBIT_RUNTIME_POSIX") != "1" {
		t.Skip("explicit owned Linux acceptance gate required")
	}
	sha, err := exec.Command("git", "rev-parse", "HEAD").Output()
	if err != nil || strings.TrimSpace(string(sha)) != sourceSHA {
		t.Fatal("exact source SHA required")
	}
	status, err := exec.Command("git", "status", "--porcelain").Output()
	if err != nil || len(status) != 0 {
		t.Fatal("clean tracked source required")
	}
	binary, err := os.ReadFile(os.Getenv("LABBIT_RUNTIME_LINUX_BINARY"))
	if err != nil || len(binary) < 4 || string(binary[:4]) != "\x7fELF" {
		t.Fatal("cross-built exact-source Linux test artifact required")
	}
	sum := sha256.Sum256(binary)
	t.Logf("source=%s linux-test-artifact-SHA256=%s", sourceSHA, hex.EncodeToString(sum[:]))
	f := setupFixture(t)
	secret := make([]byte, 32)
	if _, err := rand.Read(secret); err != nil {
		t.Fatal(err)
	}
	credential := hex.EncodeToString(secret)
	credFile := filepath.Join(t.TempDir(), "connector.credential")
	if os.WriteFile(credFile, []byte(credential), 0600) != nil {
		t.Fatal("owned credential fixture unavailable")
	}
	t.Setenv("LABBIT_CONNECTOR_CREDENTIAL_FILE", credFile)
	peer := newPeer(t, credential)
	t.Setenv("LABBIT_SAAS_BASE_URL", peer.server.URL)
	t.Setenv("LABBIT_TERMINAL_RELAY_URL", "")
	t.Setenv("LABBIT_CONNECTOR_RUNTIME_ID", "")
	stop := startRuntime(t, peer)
	snap := *f.snapshot
	snap.VMs = append([]p.ResolvedVmSpec(nil), snap.VMs[:1]...)
	snap.InternetOutbound = false
	snap.StartupScript = nil
	lab := uuid.NewString()
	result := f.operation(t, peer, lab, 1, p.MutationTypeProvision, &snap, nil, false)
	if result.Payload.Outcome != p.OutcomeSucceeded {
		t.Fatal("owned Linux VM provision failed")
	}
	refs := f.known[lab][1]
	if len(refs) != 7 || f.reconcile(t, peer, lab, 1, refs) != 7 {
		t.Fatal("owned offline Linux topology requires exact seven PRESENT refs")
	}
	id := serverID(t, refs, "workspace")
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	address, err := f.adapter.ResolveServerAddress(ctx, "workspace", id)
	if err != nil {
		t.Fatal("verified Management IP unavailable")
	}
	callback, err := f.adapter.SSHHostKeyCallback(ctx, id)
	if err != nil {
		t.Fatal("existing Server-ID pin unavailable")
	}
	keyBytes, err := os.ReadFile(f.cfg.Provision.SSHPrivateKeyFile)
	if err != nil {
		t.Fatal("customer-local management key unavailable")
	}
	signer, err := ssh.ParsePrivateKey(keyBytes)
	if err != nil {
		t.Fatal("management key parse failed")
	}
	conn, err := (&net.Dialer{Timeout: 10 * time.Second}).DialContext(ctx, "tcp", net.JoinHostPort(address, "22"))
	if err != nil {
		t.Fatal("owned VM SSH dial failed")
	}
	t.Cleanup(func() { _ = conn.Close() })
	_ = conn.SetDeadline(time.Now().Add(15 * time.Second))
	sshConn, chans, requests, err := ssh.NewClientConn(conn, net.JoinHostPort(address, "22"), &ssh.ClientConfig{User: "ubuntu", Auth: []ssh.AuthMethod{ssh.PublicKeys(signer)}, HostKeyCallback: callback})
	if err != nil {
		t.Fatal("owned VM pinned SSH handshake failed")
	}
	_ = conn.SetDeadline(time.Time{})
	client := ssh.NewClient(sshConn, chans, requests)
	t.Cleanup(func() { _ = client.Close() })
	remoteDir := "/tmp/labbit-posix-" + uuid.NewString()
	remoteFile := remoteDir + "/fixture.test"
	var cleanupOnce sync.Once
	cleanup := func() {
		cleanupOnce.Do(func() {
			_ = conn.SetDeadline(time.Now().Add(15 * time.Second))
			s, err := client.NewSession()
			if err != nil {
				t.Error("owned artifact cleanup session failed")
				return
			}
			defer s.Close()
			if s.Run("if test -d "+remoteDir+"; then rm -f -- "+remoteFile+" && rmdir -- "+remoteDir+"; fi") != nil {
				t.Error("owned exact artifact cleanup failed")
			}
		})
	}
	t.Cleanup(cleanup)
	session, err := client.NewSession()
	if err != nil {
		t.Fatal("upload session failed")
	}
	var archive bytes.Buffer
	tw := tar.NewWriter(&archive)
	if tw.WriteHeader(&tar.Header{Name: "fixture.test", Mode: 0700, Size: int64(len(binary))}) != nil {
		t.Fatal("artifact tar header failed")
	}
	if _, err := tw.Write(binary); err != nil {
		t.Fatal("artifact tar content failed")
	}
	if tw.Close() != nil {
		t.Fatal("artifact tar completion failed")
	}
	session.Stdin = bytes.NewReader(archive.Bytes())
	_ = conn.SetDeadline(time.Now().Add(3 * time.Minute))
	if session.Run("mkdir -m 700 -- "+remoteDir+" && tar xf - -C "+remoteDir) != nil {
		session.Close()
		t.Fatal("owned test artifact extraction failed")
	}
	session.Close()
	run, err := client.NewSession()
	if err != nil {
		t.Fatal("Linux test session failed")
	}
	defer run.Close()
	var output bytes.Buffer
	run.Stdout = &output
	run.Stderr = &output
	if run.Run("sha256sum "+remoteFile+" && "+remoteFile+" -test.v -test.run '^TestInstallCredentialFile$' -test.timeout=2m") != nil {
		failureHash := sha256.Sum256(output.Bytes())
		t.Logf("Linux failed-output withheld; bytes=%d SHA256=%x", output.Len(), failureHash)
		t.Fatal("actual Linux credential test did not pass")
	}
	text := output.String()
	if strings.Contains(text, "credentials =") || strings.Contains(text, "password =") || strings.Contains(text, "Password:") {
		t.Fatal("unsafe fixture diagnostic output withheld")
	}
	if !strings.Contains(text, hex.EncodeToString(sum[:])) || !strings.Contains(text, "--- PASS: TestInstallCredentialFile") || !strings.Contains(text, "POSIX_permission_0600") || strings.Contains(text, "--- SKIP") || strings.Contains(text, "--- FAIL") {
		t.Fatal("missing/skip/failed POSIX evidence")
	}
	t.Log("Linux existing credential test output (generated fixture values only):\n" + text)
	cleanup()
	clean := f.operation(t, peer, lab, 1, p.MutationTypeCleanup, nil, refs, false)
	if clean.Payload.Outcome != p.OutcomeSucceeded || f.reconcile(t, peer, lab, 1, refs) != 0 {
		t.Fatal("Linux fixture VM residual remained")
	}
	stop()
	t.Log("actual Linux POSIX0600 assertion PASS; no Windows ACL claim; storage remains Fake")
}
