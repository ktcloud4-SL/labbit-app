package runtimeprobe

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"net/http/httptest"
	"net/http/httputil"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/gophercloud/gophercloud/v2"
	sdk "github.com/gophercloud/gophercloud/v2/openstack"
	"github.com/gophercloud/gophercloud/v2/openstack/config"
	"github.com/gophercloud/gophercloud/v2/openstack/config/clouds"
	"github.com/gophercloud/gophercloud/v2/openstack/identity/v3/tokens"
	p "github.com/ktcloud4-SL/labbit-app/internal/connector/protocol"
	osp "github.com/ktcloud4-SL/labbit-app/internal/connector/provider/openstack"
)

// Real Keystone issued-token invalidation, not natural TTL expiry. Only tokens
// demonstrably issued for this isolated helper are revoked. No VM mutation.
func TestRealKeystoneOwnedTokenReauthentication(t *testing.T) {
	if os.Getenv("LABBIT_RUNTIME_REAUTH") != "1" {
		t.Skip("explicit own-token invalidation gate required")
	}
	sha, err := exec.Command("git", "rev-parse", "HEAD").Output()
	if err != nil || strings.TrimSpace(string(sha)) != sourceSHA {
		t.Fatal("exact source required")
	}
	status, err := exec.Command("git", "status", "--porcelain").Output()
	if err != nil || len(status) != 0 {
		t.Fatal("clean tracked source required")
	}
	cfg := osp.ConfigFromEnvironment()
	ao, eo, tlsConfig, err := clouds.Parse(clouds.WithLocations(cfg.File), clouds.WithCloudName(cfg.CloudName))
	if err != nil || (tlsConfig != nil && tlsConfig.InsecureSkipVerify) || !strings.HasPrefix(ao.IdentityEndpoint, "http://") {
		t.Fatal("secure-config existing HTTP lab preflight failed")
	}
	if ao.TokenID != "" || (ao.Password == "" && ao.ApplicationCredentialSecret == "") {
		t.Skip("renewable test credential unavailable; do not change customer credential")
	}
	ao.AllowReauth = true
	ctx, cancel := context.WithTimeout(context.Background(), time.Minute)
	defer cancel()
	parent, err := config.NewProviderClient(ctx, ao, config.WithTLSConfig(tlsConfig))
	if err != nil {
		t.Fatal("control fixture authentication failed")
	}
	identity, err := sdk.NewIdentityV3(parent, eo)
	if err != nil {
		t.Fatal("real Identity API unavailable")
	}
	scoped, ok := parent.GetAuthResult().(tokens.CreateResult)
	if !ok {
		t.Fatal("scoped own fixture identity unavailable")
	}
	project, err := scoped.ExtractProject()
	if err != nil || project == nil {
		t.Fatal("own project scope unavailable")
	}
	catalog, err := scoped.ExtractServiceCatalog()
	if err != nil {
		t.Fatal("catalog trust preflight unavailable")
	}
	for _, entry := range catalog.Entries {
		for _, endpoint := range entry.Endpoints {
			u, err := url.Parse(endpoint.URL)
			if err != nil || u.Scheme != "http" {
				t.Fatal("non-HTTP catalog requires explicit child cloud CA setup")
			}
		}
	}
	upstream, err := url.Parse(ao.IdentityEndpoint)
	if err != nil {
		t.Fatal("Identity endpoint invalid")
	}
	var mu sync.Mutex
	issued := []string{}
	proxy := httputil.NewSingleHostReverseProxy(upstream)
	proxy.ErrorLog = log.New(io.Discard, "", 0)
	proxy.Director = func(r *http.Request) {
		r.URL.Scheme = upstream.Scheme
		r.URL.Host = upstream.Host
		r.Host = upstream.Host
	}
	proxy.ModifyResponse = func(r *http.Response) error {
		if r.Request.Method == http.MethodPost && strings.HasSuffix(r.Request.URL.Path, "/auth/tokens") && r.StatusCode == 201 {
			token := r.Header.Get("X-Subject-Token")
			if token != "" {
				mu.Lock()
				issued = append(issued, token)
				mu.Unlock()
			}
		}
		return nil
	}
	authPeer := httptest.NewServer(proxy)
	t.Cleanup(authPeer.Close)
	t.Cleanup(func() {
		mu.Lock()
		owned := append([]string(nil), issued...)
		mu.Unlock()
		for _, token := range owned {
			if token == "" || token == parent.Token() {
				t.Error("unsafe token-cleanup identity; no revocation")
				continue
			}
			c, stop := context.WithTimeout(context.Background(), 15*time.Second)
			revokeErr := tokens.Revoke(c, identity, token).Err
			stop()
			if revokeErr != nil && !gophercloud.ResponseCodeIs(revokeErr, 404) {
				t.Error("owned helper token cleanup failed; bearer value withheld")
			}
			validateCtx, validateCancel := context.WithTimeout(context.Background(), 15*time.Second)
			valid, validateErr := tokens.Validate(validateCtx, identity, token)
			validateCancel()
			if validateErr != nil || valid {
				t.Error("owned helper token invalidation not confirmed")
			} else {
				t.Log("owned helper issued token cleanup confirmed INVALID")
			}
		}
	})
	authMap := map[string]string{"auth_url": authPeer.URL + "/v3", "username": ao.Username, "password": ao.Password, "user_id": ao.UserID, "project_id": ao.TenantID, "project_name": ao.TenantName, "user_domain_id": ao.DomainID, "user_domain_name": ao.DomainName, "application_credential_id": ao.ApplicationCredentialID, "application_credential_name": ao.ApplicationCredentialName, "application_credential_secret": ao.ApplicationCredentialSecret}
	authMap["project_id"] = project.ID
	delete(authMap, "project_name")
	for k, v := range authMap {
		if v == "" {
			delete(authMap, k)
		}
	}
	cloudMap := map[string]any{"clouds": map[string]any{cfg.CloudName: map[string]any{"auth": authMap, "region_name": eo.Region, "interface": eo.Availability, "identity_api_version": "3"}}}
	raw, err := json.Marshal(cloudMap)
	if err != nil {
		t.Fatal("temporary auth config encoding failed")
	}
	cloudFile := filepath.Join(t.TempDir(), "clouds.yaml")
	if os.WriteFile(cloudFile, raw, 0600) != nil {
		t.Fatal("temporary private auth config unavailable")
	}
	t.Setenv(osp.EnvProviderConfigFile, cloudFile)
	t.Setenv("LABBIT_ENVIRONMENT", "production")
	t.Setenv("LABBIT_CONNECTOR_ID", uuid.NewString())
	t.Setenv("LABBIT_CONNECTOR_RUNTIME_ID", "")
	t.Setenv(osp.EnvSSHKnownHostsFile, filepath.Join(t.TempDir(), "known_hosts"))
	connection := uuid.NewString()
	t.Setenv(osp.EnvProviderConnection, connection)
	random := make([]byte, 32)
	if _, err := rand.Read(random); err != nil {
		t.Fatal(err)
	}
	credential := hex.EncodeToString(random)
	credFile := filepath.Join(t.TempDir(), "connector.credential")
	if os.WriteFile(credFile, []byte(credential), 0600) != nil {
		t.Fatal("owned peer credential fixture failed")
	}
	t.Setenv("LABBIT_CONNECTOR_CREDENTIAL_FILE", credFile)
	peer := newPeer(t, credential)
	t.Setenv("LABBIT_SAAS_BASE_URL", peer.server.URL)
	t.Setenv("LABBIT_TERMINAL_RELAY_URL", "")
	stop := startRuntime(t, peer)
	runtimeID := peer.runtimeID(t)
	list := func() {
		id := uuid.NewString()
		peer.send(t, p.ProviderRequestMessage{BaseEnvelope: p.BaseEnvelope{Type: p.MessageTypeProviderRequest, MessageID: id, SentAt: time.Now().UTC()}, Payload: p.ProviderRequestPayload{RequestType: p.ProviderRequestListImages, ProviderConnectionID: connection}})
		var result p.ProviderResponseMessage
		if json.Unmarshal(peer.wait(t, "control", p.MessageTypeProviderResponse, id, time.Minute), &result) != nil || result.Payload.Outcome != p.OutcomeSucceeded || len(result.Payload.Items) == 0 {
			t.Fatal("real image query/re-authentication failed")
		}
	}
	list()
	mu.Lock()
	count := len(issued)
	old := ""
	if count == 1 {
		old = issued[0]
	}
	mu.Unlock()
	if old == "" || old == parent.Token() {
		t.Fatal("helper-only issued token identity not proven")
	}
	revokeCtx, revokeCancel := context.WithTimeout(context.Background(), 15*time.Second)
	err = tokens.Revoke(revokeCtx, identity, old).Err
	revokeCancel()
	if err != nil {
		t.Fatal("own helper token revocation not permitted; no broader credential change")
	}
	list()
	query(t, peer, connection)
	mu.Lock()
	count = len(issued)
	different := count == 2 && issued[1] != old
	mu.Unlock()
	if !different {
		t.Fatal("real re-auth must issue exactly one distinct replacement token")
	}
	if peer.runtimeID(t) != runtimeID || peer.count("control", p.MessageTypeHello) != 1 {
		t.Fatal("provider authentication recovery disconnected Control runtime")
	}
	heartbeats := peer.count("control", p.MessageTypeHeartbeat)
	peer.waitCount(t, "control", p.MessageTypeHeartbeat, heartbeats+1)
	stop()
	t.Logf("source=%s actual Keystone issued own token -> exact revocation -> real Glance query with SDK reauthentication -> one replacement issuance -> image query/ValidateConnection/Heartbeat PASS; Control HELLO1; Glance401 inferred not directly observed; no natural TTL expiry or mutation replay claim", sourceSHA)
}
