$ErrorActionPreference='Stop'
$repoDirectory=(Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $repoDirectory
$expectedCommit='2b40992279e16b8593c244c9169df72053a4622c'
if ((git rev-parse HEAD) -ne $expectedCommit -or @(git status --porcelain).Count) {throw 'Use clean exact source HEAD'}
$binaryPath=Join-Path $PSScriptRoot 'dev-auth-fixture-linux.test'
$env:GOOS='linux';$env:GOARCH='amd64';$env:CGO_ENABLED='0'
Write-Output ('build source='+$expectedCommit+' GOOS=linux GOARCH=amd64 CGO_ENABLED=0 target=./tools/dev-auth-class-fixture') | Tee-Object -FilePath (Join-Path $PSScriptRoot 'linux-build.log')
& go test -mod=readonly -c -o $binaryPath './tools/dev-auth-class-fixture' 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'linux-build.log') -Append
if ($LASTEXITCODE) {throw 'Linux cross-build failed'}
Write-Output 'cross-build exit=0' | Tee-Object -FilePath (Join-Path $PSScriptRoot 'linux-build.log') -Append
Get-FileHash -LiteralPath $binaryPath -Algorithm SHA256 | Format-List | Out-String | Tee-Object -FilePath (Join-Path $PSScriptRoot 'linux-build.log') -Append
& go version -m $binaryPath 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'linux-build.log') -Append
$env:GOOS='windows';$env:GOARCH='amd64';$env:CGO_ENABLED='1'
$env:LABBIT_PROVIDER_CONFIG_FILE='C:/Users/user/.config/openstack/clouds.yaml'
$env:OS_CLOUD='labbit-test'
$env:LABBIT_OPENSTACK_SSH_PRIVATE_KEY_FILE='C:/Users/user/.ssh/dandelion.pem'
$env:LABBIT_OPENSTACK_SSH_USERNAME='ubuntu'
$env:LABBIT_RUNTIME_POSIX='1'
$env:LABBIT_RUNTIME_LINUX_BINARY=$binaryPath
& go test -json -mod=readonly -count=1 -timeout=15m -run '^TestPOSIXCredentialOnRealLinuxVM$' './.local/evidence/LBT-82-runtime-20261006' 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'posix-linux-real.jsonl')
$result=$LASTEXITCODE
Write-Output ('posix-linux exit='+$result)
if ($result) {throw 'Linux acceptance did not pass; preserve evidence and audit owned cleanup'}
