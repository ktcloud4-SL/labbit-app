$ErrorActionPreference='Stop'
$repoDirectory=(Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $repoDirectory
if ((git rev-parse HEAD) -ne '2b40992279e16b8593c244c9169df72053a4622c' -or @(git status --porcelain).Count) {throw 'Use clean exact source HEAD'}
$env:LABBIT_PROVIDER_CONFIG_FILE='C:/Users/user/.config/openstack/clouds.yaml'
$env:OS_CLOUD='labbit-test'
$env:LABBIT_OPENSTACK_SSH_PRIVATE_KEY_FILE='C:/Users/user/.ssh/dandelion.pem'
$env:LABBIT_OPENSTACK_SSH_USERNAME='ubuntu'
$env:LABBIT_RUNTIME_REAUTH='1'
$env:CGO_ENABLED='1'
& go test -json -mod=readonly -count=1 -timeout=5m -run '^TestRealKeystoneOwnedTokenReauthentication$' './.local/evidence/LBT-82-runtime-20261006' 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'reauth-real.jsonl')
$result=$LASTEXITCODE
Write-Output ('reauth-real exit='+$result)
if ($result) {throw 'Real-token acceptance did not pass; preserve evidence'}
