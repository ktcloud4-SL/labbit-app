param([string]$ExpectedCommit='2b40992279e16b8593c244c9169df72053a4622c', [string]$LogName='runtime-real.jsonl')
$ErrorActionPreference='Stop'
$repoDirectory=(Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $repoDirectory
if ((git rev-parse HEAD) -ne $ExpectedCommit -or @(git status --porcelain).Count) { throw 'Use clean exact source HEAD' }
$env:LABBIT_PROVIDER_CONFIG_FILE='C:/Users/user/.config/openstack/clouds.yaml'
$env:OS_CLOUD='labbit-test'
$env:LABBIT_OPENSTACK_SSH_PRIVATE_KEY_FILE='C:/Users/user/.ssh/dandelion.pem'
$env:LABBIT_OPENSTACK_SSH_USERNAME='ubuntu'
$env:LABBIT_RUNTIME_REAL='1'
$env:CGO_ENABLED='1'
# Compiler and credentials already installed/configured by the user workflow.
# The harness creates only uniquely owned resources and never edits customer keys.
& go test -json -mod=readonly -count=1 -timeout=45m -run '^TestProductionAppRunRealOpenStack$' './.local/evidence/LBT-82-runtime-20261006' 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot $LogName)
$result=$LASTEXITCODE
Write-Output ('runtime-real exit='+$result)
if ($result) { throw 'Live acceptance did not pass; preserve evidence and audit owned-resource cleanup' }
