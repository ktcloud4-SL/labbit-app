package runtimeprobe

// Ignored, separately hashed acceptance harness. All Connector components below
// are unmodified production code from the recorded clean source commit.
import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/gophercloud/gophercloud/v2"
	sdk "github.com/gophercloud/gophercloud/v2/openstack"
	"github.com/gophercloud/gophercloud/v2/openstack/compute/v2/keypairs"
	"github.com/gophercloud/gophercloud/v2/openstack/compute/v2/servers"
	"github.com/gophercloud/gophercloud/v2/openstack/config"
	"github.com/gophercloud/gophercloud/v2/openstack/config/clouds"
	"github.com/gophercloud/gophercloud/v2/openstack/identity/v3/tokens"
	"github.com/gophercloud/gophercloud/v2/openstack/networking/v2/extensions/security/groups"
	"github.com/gophercloud/gophercloud/v2/openstack/networking/v2/extensions/security/rules"
	"github.com/gophercloud/gophercloud/v2/openstack/networking/v2/networks"
	"github.com/gophercloud/gophercloud/v2/openstack/networking/v2/ports"
	"github.com/gorilla/websocket"
	"github.com/ktcloud4-SL/labbit-app/internal/connector/app"
	p "github.com/ktcloud4-SL/labbit-app/internal/connector/protocol"
	provider "github.com/ktcloud4-SL/labbit-app/internal/connector/provider"
	osp "github.com/ktcloud4-SL/labbit-app/internal/connector/provider/openstack"
	"golang.org/x/crypto/ssh"
)

const sourceSHA = "2b40992279e16b8593c244c9169df72053a4622c"

type wireRecord struct {
	role string
	raw  []byte
}
type tlsPeer struct {
	server             *httptest.Server
	credential         string
	mu                 sync.Mutex
	control, data      *websocket.Conn
	records            []wireRecord
	output             chan []byte
	sessions           map[string]bool
	closed             bool
	caFile             string
	closedDataSessions map[string]bool
}

func newPeer(t *testing.T, credential string) *tlsPeer {
	peer := &tlsPeer{credential: credential, output: make(chan []byte, 1000), sessions: map[string]bool{}, closedDataSessions: map[string]bool{}}
	mux := http.NewServeMux()
	mux.HandleFunc("/connector/v1/control", peer.controlHTTP)
	mux.HandleFunc("/connector/v1/terminal-data", peer.dataHTTP)
	peer.server = httptest.NewUnstartedServer(mux)
	peer.server.StartTLS()
	peer.caFile = filepath.Join(t.TempDir(), "peer-public-certificate.pem")
	if os.WriteFile(peer.caFile, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: peer.server.Certificate().Raw}), 0600) != nil {
		t.Fatal("test peer public CA file failed")
	}
	t.Cleanup(func() {
		peer.mu.Lock()
		peer.closed = true
		if peer.control != nil {
			_ = peer.control.Close()
		}
		if peer.data != nil {
			_ = peer.data.Close()
		}
		peer.mu.Unlock()
		peer.server.Close()
	})
	return peer
}
func (peer *tlsPeer) upgrade(w http.ResponseWriter, r *http.Request, subprotocol string) *websocket.Conn {
	if r.Header.Get("Authorization") != "Bearer "+peer.credential {
		http.Error(w, "unauthorized", 401)
		return nil
	}
	up := websocket.Upgrader{Subprotocols: []string{subprotocol}, CheckOrigin: func(*http.Request) bool { return true }}
	conn, err := up.Upgrade(w, r, nil)
	if err != nil {
		return nil
	}
	return conn
}
func (peer *tlsPeer) save(role string, raw []byte) {
	peer.mu.Lock()
	peer.records = append(peer.records, wireRecord{role, append([]byte(nil), raw...)})
	peer.mu.Unlock()
}
func (peer *tlsPeer) controlHTTP(w http.ResponseWriter, r *http.Request) {
	c := peer.upgrade(w, r, p.SubprotocolControl)
	if c == nil {
		return
	}
	defer c.Close()
	peer.mu.Lock()
	peer.control = c
	peer.mu.Unlock()
	for {
		_, raw, err := c.ReadMessage()
		if err != nil {
			return
		}
		peer.save("control", raw)
		var env p.BaseEnvelope
		if json.Unmarshal(raw, &env) != nil {
			return
		}
		if env.Type == p.MessageTypeHello {
			ack := map[string]any{"type": p.MessageTypeHelloAck, "messageId": uuid.NewString(), "replyToMessageId": env.MessageID, "sentAt": time.Now().UTC(), "payload": map[string]any{"serverTime": time.Now().UTC(), "heartbeatIntervalSeconds": 1, "offlineTimeoutSeconds": 5}}
			peer.mu.Lock()
			err = c.WriteJSON(ack)
			peer.mu.Unlock()
			if err != nil {
				return
			}
		}
	}
}
func (peer *tlsPeer) dataHTTP(w http.ResponseWriter, r *http.Request) {
	c := peer.upgrade(w, r, p.SubprotocolTerminalData)
	if c == nil {
		return
	}
	defer c.Close()
	_, raw, err := c.ReadMessage()
	if err != nil {
		return
	}
	var attach p.TerminalDataAttachMessage
	if json.Unmarshal(raw, &attach) != nil {
		return
	}
	defer func() {
		peer.mu.Lock()
		if peer.data == c {
			peer.closedDataSessions[attach.TerminalSessionID] = true
			peer.data = nil
		}
		peer.mu.Unlock()
	}()
	peer.save("data", raw)
	peer.mu.Lock()
	resumed := peer.sessions[attach.TerminalSessionID]
	peer.sessions[attach.TerminalSessionID] = true
	peer.data = c
	peer.closedDataSessions[attach.TerminalSessionID] = false
	history := false
	err = c.WriteJSON(p.TerminalDataAttachedMessage{BaseEnvelope: p.BaseEnvelope{Type: p.MessageTypeTerminalDataAttached, MessageID: uuid.NewString(), ReplyToMessageID: attach.MessageID, SentAt: time.Now().UTC(), TerminalSessionID: attach.TerminalSessionID, LabInstanceID: attach.LabInstanceID, Generation: attach.Generation}, Payload: p.TerminalDataAttachedPayload{Resumed: &resumed, HistoryAvailable: &history}})
	peer.mu.Unlock()
	if err != nil {
		return
	}
	for {
		kind, b, err := c.ReadMessage()
		if err != nil {
			return
		}
		if kind == websocket.BinaryMessage {
			select {
			case peer.output <- b:
			default:
				return
			}
		} else {
			peer.save("data", b)
		}
	}
}
func (peer *tlsPeer) send(t *testing.T, msg any) {
	t.Helper()
	peer.mu.Lock()
	defer peer.mu.Unlock()
	if peer.control == nil {
		t.Fatal("no connected Control")
	}
	if err := peer.control.WriteJSON(msg); err != nil {
		t.Fatal("peer Control send failed")
	}
}
func (peer *tlsPeer) drop(role string) {
	peer.mu.Lock()
	defer peer.mu.Unlock()
	if role == "control" && peer.control != nil {
		_ = peer.control.Close()
	} else if role == "data" && peer.data != nil {
		_ = peer.data.Close()
	}
}
func (peer *tlsPeer) count(role, kind string) int {
	peer.mu.Lock()
	defer peer.mu.Unlock()
	n := 0
	for _, r := range peer.records {
		var e p.BaseEnvelope
		if r.role == role && json.Unmarshal(r.raw, &e) == nil && e.Type == kind {
			n++
		}
	}
	return n
}
func (peer *tlsPeer) wait(t *testing.T, role, kind, reply string, timeout time.Duration) []byte {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		peer.mu.Lock()
		for _, r := range peer.records {
			var e p.BaseEnvelope
			if r.role == role && json.Unmarshal(r.raw, &e) == nil && e.Type == kind && (reply == "" || e.ReplyToMessageID == reply) {
				b := append([]byte(nil), r.raw...)
				peer.mu.Unlock()
				return b
			}
		}
		peer.mu.Unlock()
		time.Sleep(25 * time.Millisecond)
	}
	t.Fatalf("timeout for %s %s reply %s", role, kind, reply)
	return nil
}
func (peer *tlsPeer) waitCount(t *testing.T, role, kind string, want int) {
	t.Helper()
	deadline := time.Now().Add(20 * time.Second)
	for time.Now().Before(deadline) {
		if peer.count(role, kind) >= want {
			return
		}
		time.Sleep(25 * time.Millisecond)
	}
	t.Fatalf("%s %s count below %d", role, kind, want)
}
func (peer *tlsPeer) waitSession(t *testing.T, role, kind, session string) {
	t.Helper()
	deadline := time.Now().Add(15 * time.Second)
	for time.Now().Before(deadline) {
		peer.mu.Lock()
		for _, r := range peer.records {
			var e p.BaseEnvelope
			if r.role == role && json.Unmarshal(r.raw, &e) == nil && e.Type == kind && e.TerminalSessionID == session {
				peer.mu.Unlock()
				return
			}
		}
		peer.mu.Unlock()
		time.Sleep(25 * time.Millisecond)
	}
	t.Fatal("expected session-specific lifecycle event missing")
}
func (peer *tlsPeer) runtimeID(t *testing.T) string {
	t.Helper()
	peer.mu.Lock()
	defer peer.mu.Unlock()
	id := ""
	for _, r := range peer.records {
		var hello p.HelloMessage
		if r.role == "control" && json.Unmarshal(r.raw, &hello) == nil && hello.Type == p.MessageTypeHello {
			id = hello.Payload.RuntimeID
		}
	}
	if id == "" {
		t.Fatal("runtime ID missing")
	}
	return id
}
func (peer *tlsPeer) assertAttachRuntime(t *testing.T, session string) {
	t.Helper()
	id := peer.runtimeID(t)
	peer.mu.Lock()
	defer peer.mu.Unlock()
	found := false
	for _, r := range peer.records {
		var a p.TerminalDataAttachMessage
		if r.role == "data" && json.Unmarshal(r.raw, &a) == nil && a.Type == p.MessageTypeTerminalDataAttach && a.TerminalSessionID == session {
			found = true
			if a.Payload.RuntimeID != id {
				t.Fatal("Control/Data runtime IDs diverged")
			}
		}
	}
	if !found {
		t.Fatal("Data attach missing")
	}
}
func (peer *tlsPeer) shell(t *testing.T, command, expected string) {
	t.Helper()
	for {
		select {
		case <-peer.output:
		default:
			goto drained
		}
	}
drained:
	// Disable echo so a marker in typed input cannot be mistaken for VM output.
	peer.mu.Lock()
	if peer.data == nil {
		peer.mu.Unlock()
		t.Fatal("no Terminal Data")
	}
	err := peer.data.WriteMessage(websocket.BinaryMessage, []byte(command+"\n"))
	peer.mu.Unlock()
	if err != nil {
		t.Fatal("terminal input write failed")
	}
	deadline := time.NewTimer(25 * time.Second)
	defer deadline.Stop()
	var received strings.Builder
	for {
		select {
		case b := <-peer.output:
			received.Write(b)
			if strings.Contains(received.String(), expected) {
				return
			}
		case <-deadline.C:
			t.Fatal("actual VM PTY did not emit expected assertion marker")
		}
	}
}
func (peer *tlsPeer) resize(t *testing.T, lab, session string, gen int64) {
	t.Helper()
	peer.mu.Lock()
	defer peer.mu.Unlock()
	err := peer.data.WriteJSON(p.TerminalDataResizeMessage{BaseEnvelope: p.BaseEnvelope{Type: p.MessageTypeTerminalDataResize, MessageID: uuid.NewString(), SentAt: time.Now().UTC(), TerminalSessionID: session, LabInstanceID: lab, Generation: gen}, Payload: p.TerminalDataResizePayload{Cols: 101, Rows: 37}})
	if err != nil {
		t.Fatal("resize frame failed")
	}
}

type fixture struct {
	cfg           osp.Config
	adapter       *osp.Adapter
	computeClient *gophercloud.ServiceClient
	netClient     *gophercloud.ServiceClient
	snapshot      *p.CreationSnapshot
	known         map[string]map[int64][]p.ProviderResourceRef
	blockerIDs    []string
}

func setupFixture(t *testing.T) *fixture {
	t.Helper()
	cfg := osp.ConfigFromEnvironment()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	auth, endpoint, tlsConfig, err := clouds.Parse(clouds.WithLocations(cfg.File), clouds.WithCloudName(cfg.CloudName))
	if err != nil || (tlsConfig != nil && tlsConfig.InsecureSkipVerify) {
		t.Fatal("local secure cloud configuration unavailable")
	}
	auth.AllowReauth = auth.TokenID == "" && (auth.Password != "" || auth.ApplicationCredentialSecret != "")
	sdkProvider, err := config.NewProviderClient(ctx, auth, config.WithTLSConfig(tlsConfig))
	if err != nil {
		t.Fatal("fixture authentication failed")
	}
	compute, err := sdk.NewComputeV2(sdkProvider, endpoint)
	if err != nil {
		t.Fatal("compute fixture unavailable")
	}
	network, err := sdk.NewNetworkV2(sdkProvider, endpoint)
	if err != nil {
		t.Fatal("network fixture unavailable")
	}
	authResult, ok := sdkProvider.GetAuthResult().(tokens.CreateResult)
	if !ok {
		t.Fatal("scoped project unavailable")
	}
	project, err := authResult.ExtractProject()
	if err != nil || project == nil {
		t.Fatal("scoped project unavailable")
	}
	// Child roots are scoped to the TLS test peer. This existing local cloud
	// uses HTTP SDK endpoints. Do not accidentally run against HTTPS cloud
	// services without explicitly supplying their real trust anchors.
	if !strings.HasPrefix(auth.IdentityEndpoint, "http://") {
		t.Fatal("HTTPS cloud requires a separate explicit child CA setup")
	}
	catalog, err := authResult.ExtractServiceCatalog()
	if err != nil {
		t.Fatal("catalog trust preflight unavailable")
	}
	for _, entry := range catalog.Entries {
		for _, endpoint := range entry.Endpoints {
			if !strings.HasPrefix(endpoint.URL, "http://") {
				t.Fatal("non-HTTP cloud endpoint needs explicit child cloud trust setup")
			}
		}
	}
	cfg.Provision.ProviderConnectionID = uuid.NewString()
	cfg.Provision.ProjectID = project.ID
	adapter, err := osp.New(ctx, cfg)
	if err != nil {
		t.Fatal("real Provider discovery failed")
	}
	images, err := adapter.ListImages(ctx)
	if err != nil {
		t.Fatal("images unavailable")
	}
	flavors, err := adapter.ListFlavors(ctx)
	if err != nil {
		t.Fatal("flavors unavailable")
	}
	nets, err := adapter.ListNetworks(ctx)
	if err != nil {
		t.Fatal("networks unavailable")
	}
	baselineServers, err := adapter.ListServers(ctx)
	if err != nil {
		t.Fatal("baseline server census unavailable")
	}
	t.Logf("read-only baseline servers=%d networks=%d; counts are evidence, not ownership", len(baselineServers), len(nets))
	t.Cleanup(func() {
		c, stop := context.WithTimeout(context.Background(), time.Minute)
		defer stop()
		postServers, err1 := adapter.ListServers(c)
		postNets, err2 := adapter.ListNetworks(c)
		if err1 != nil || err2 != nil {
			t.Error("post-run census unavailable")
			return
		}
		t.Logf("read-only post-run servers=%d networks=%d", len(postServers), len(postNets))
		if len(postServers) != len(baselineServers) || len(postNets) != len(nets) {
			t.Error("post-run census differs from baseline; investigate, never delete by count")
		}
	})
	snapshot := &p.CreationSnapshot{ProviderConnectionID: cfg.Provision.ProviderConnectionID, WorkspaceVMKey: "workspace", InternetOutbound: true}
	for _, image := range images {
		if image.Name == "ubuntu" {
			snapshot.VMs = append(snapshot.VMs, p.ResolvedVmSpec{VMKey: "workspace", Role: "WORKSPACE", ImageID: image.ID})
			break
		}
	}
	if len(snapshot.VMs) != 1 {
		t.Fatal("exact ubuntu image unavailable")
	}
	for _, flavor := range flavors {
		if flavor.Name == "m1.small" {
			snapshot.VMs[0].FlavorID = flavor.ID
			snapshot.VMs[0].FlavorSpec = &p.ResolvedFlavorSpec{VCPUs: flavor.VCPUs, RAMMiB: flavor.RAMMiB, DiskGiB: flavor.DiskGiB}
			break
		}
	}
	if snapshot.VMs[0].FlavorID == "" {
		t.Fatal("exact m1.small unavailable")
	}
	worker := snapshot.VMs[0]
	worker.VMKey = "worker"
	worker.Role = "WORKER"
	snapshot.VMs = append(snapshot.VMs, worker)
	for _, n := range nets {
		if n.Name == "sharednet1" {
			cfg.Provision.ManagementNetworkID = n.ID
		}
	}
	if cfg.Provision.ManagementNetworkID == "" {
		t.Fatal("management network unavailable")
	}
	pages, err := networks.List(network, networks.ListOpts{}).AllPages(ctx)
	if err != nil {
		t.Fatal("external network list failed")
	}
	var expanded []struct {
		ID       string `json:"id"`
		Status   string `json:"status"`
		External bool   `json:"router:external"`
	}
	if networks.ExtractNetworksInto(pages, &expanded) != nil {
		t.Fatal("external network decode failed")
	}
	count := 0
	for _, n := range expanded {
		if n.External && n.Status == "ACTIVE" {
			cfg.Provision.ExternalNetworkID = n.ID
			count++
		}
	}
	if count != 1 {
		t.Fatal("external network ambiguous")
	}
	suffix := uuid.NewString()
	stateful := true
	sg, err := groups.Create(ctx, network, groups.CreateOpts{Name: "labbit-runtime-management-" + suffix, Stateful: &stateful}).Extract()
	if err != nil {
		t.Fatal("temporary SG creation failed")
	}
	t.Cleanup(func() {
		c, stop := context.WithTimeout(context.Background(), time.Minute)
		defer stop()
		err := groups.Delete(c, network, sg.ID).ExtractErr()
		if err != nil && !gophercloud.ResponseCodeIs(err, 404) {
			t.Error("owned temporary Management SG cleanup failed")
		} else {
			if _, err := groups.Get(c, network, sg.ID).Extract(); !gophercloud.ResponseCodeIs(err, 404) {
				t.Error("Management SG absence not confirmed")
			} else {
				t.Log("fixture Management SG exact-ID ABSENT")
			}
		}
	})
	for _, r := range sg.Rules {
		if rules.Delete(ctx, network, r.ID).ExtractErr() != nil {
			t.Fatal("temporary SG default-rule removal failed")
		}
	}
	cfg.Provision.ManagementSecurityGroupID = sg.ID
	cfg.Provision.SSHAllowedCIDR = "172.16.8.1/32"
	if _, err := rules.Create(ctx, network, rules.CreateOpts{Direction: rules.DirIngress, EtherType: rules.EtherType4, SecGroupID: sg.ID, Protocol: rules.ProtocolTCP, PortRangeMin: 22, PortRangeMax: 22, RemoteIPPrefix: cfg.Provision.SSHAllowedCIDR}).Extract(); err != nil {
		t.Fatal("temporary SG SSH rule failed")
	}
	keyBytes, err := os.ReadFile(cfg.Provision.SSHPrivateKeyFile)
	if err != nil {
		t.Fatal("local SSH key unavailable")
	}
	signer, err := ssh.ParsePrivateKey(keyBytes)
	if err != nil || signer.PublicKey().Type() != ssh.KeyAlgoED25519 {
		t.Fatal("runtime requires Ed25519 management key")
	}
	keyName := "labbit-runtime-key-" + suffix
	if _, err := keypairs.Create(ctx, compute, keypairs.CreateOpts{Name: keyName, PublicKey: strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))}).Extract(); err != nil {
		t.Fatal("temporary keypair import failed")
	}
	t.Cleanup(func() {
		c, stop := context.WithTimeout(context.Background(), time.Minute)
		defer stop()
		err := keypairs.Delete(c, compute, keyName, nil).ExtractErr()
		if err != nil && !gophercloud.ResponseCodeIs(err, 404) {
			t.Error("owned temporary keypair cleanup failed")
		} else {
			if _, err := keypairs.Get(c, compute, keyName, nil).Extract(); !gophercloud.ResponseCodeIs(err, 404) {
				t.Error("keypair absence not confirmed")
			} else {
				t.Log("fixture keypair exact-name ABSENT")
			}
		}
	})
	cfg.Provision.KeyPairName = keyName
	cfg.Provision.LabSubnetCIDR = "198.22.0.0/24"
	cfg.Provision.SSHKnownHostsFile = filepath.Join(t.TempDir(), "known_hosts")
	settings := map[string]string{osp.EnvProviderConnection: cfg.Provision.ProviderConnectionID, osp.EnvProjectID: project.ID, osp.EnvManagementNetwork: cfg.Provision.ManagementNetworkID, osp.EnvManagementSecurityGroup: sg.ID, osp.EnvExternalNetwork: cfg.Provision.ExternalNetworkID, osp.EnvKeyPairName: keyName, osp.EnvSSHAllowedCIDR: cfg.Provision.SSHAllowedCIDR, osp.EnvLabSubnetCIDR: cfg.Provision.LabSubnetCIDR, osp.EnvSSHKnownHostsFile: cfg.Provision.SSHKnownHostsFile, "LABBIT_ENVIRONMENT": "production", "LABBIT_LOG_LEVEL": "warn", "LABBIT_CONNECTOR_ID": uuid.NewString()}
	for k, v := range settings {
		t.Setenv(k, v)
	}
	adapter, err = osp.New(ctx, osp.ConfigFromEnvironment())
	if err != nil {
		t.Fatal("configured real Provider unavailable")
	}
	fixture := &fixture{cfg: osp.ConfigFromEnvironment(), adapter: adapter, computeClient: compute, netClient: network, snapshot: snapshot, known: map[string]map[int64][]p.ProviderResourceRef{}}
	t.Cleanup(func() {
		for _, id := range fixture.blockerIDs {
			c, stop := context.WithTimeout(context.Background(), time.Minute)
			err := ports.Delete(c, network, id).ExtractErr()
			stop()
			if err != nil && !gophercloud.ResponseCodeIs(err, 404) {
				t.Error("owned fault port cleanup failed")
			}
		}
		for lab, byGen := range fixture.known {
			for gen, refs := range byGen {
				c, stop := context.WithTimeout(context.Background(), 2*time.Minute)
				converted := make([]provider.ResourceRef, 0, len(refs))
				for _, r := range refs {
					converted = append(converted, provider.ResourceRef{ResourceType: r.ResourceType, ProviderID: r.ProviderID, Generation: r.Generation, LogicalName: r.LogicalName})
				}
				result, err := adapter.Cleanup(c, provider.CleanupRequest{Correlation: provider.Correlation{OperationID: uuid.NewString(), LabInstanceID: lab, Generation: gen}, ProviderResources: converted})
				stop()
				if err != nil || result.Outcome != provider.OutcomeSucceeded {
					t.Error("owned exact-ID emergency cleanup failed")
				}
			}
		}
	})
	return fixture
}
func (f *fixture) track(lab string, resources []p.ProviderResourceResult) {
	if f.known[lab] == nil {
		f.known[lab] = map[int64][]p.ProviderResourceRef{}
	}
	for _, r := range resources {
		refs := f.known[lab][r.Generation]
		exists := false
		for _, old := range refs {
			if old.ProviderID == r.ProviderID {
				exists = true
			}
		}
		if !exists {
			f.known[lab][r.Generation] = append(refs, r.ProviderResourceRef)
		}
	}
}
func (f *fixture) operation(t *testing.T, peer *tlsPeer, lab string, gen int64, mutation string, snapshot *p.CreationSnapshot, refs []p.ProviderResourceRef, drop bool) p.OperationResultMessage {
	t.Helper()
	id := uuid.NewString()
	msg := p.OperationCommandMessage{BaseEnvelope: p.BaseEnvelope{Type: p.MessageTypeOperationCommand, MessageID: id, SentAt: time.Now().UTC(), OperationID: uuid.NewString(), LabInstanceID: lab, Generation: gen}, Payload: p.OperationCommandPayload{MutationType: mutation, CreationSnapshot: snapshot, ProviderResources: refs}}
	peer.send(t, msg)
	var ack p.OperationAckMessage
	if json.Unmarshal(peer.wait(t, "control", p.MessageTypeOperationAck, id, 20*time.Second), &ack) != nil || !ack.Payload.Accepted {
		t.Fatal("runtime rejected valid operation")
	}
	if drop {
		before := peer.count("control", p.MessageTypeHello)
		peer.drop("control")
		peer.waitCount(t, "control", p.MessageTypeHello, before+1)
		peer.waitCount(t, "control", p.MessageTypeHeartbeat, 1)
	}
	var result p.OperationResultMessage
	if json.Unmarshal(peer.wait(t, "control", p.MessageTypeOperationResult, id, 10*time.Minute), &result) != nil {
		t.Fatal("operation result decode failed")
	}
	f.track(lab, result.Payload.ProviderResources)
	t.Logf("runtime %s gen%d outcome=%s refs=%d", mutation, gen, result.Payload.Outcome, len(result.Payload.ProviderResources))
	owned, _ := json.Marshal(f.known[lab])
	t.Logf("owned exact refs lab=%s %s", lab, owned)
	return result
}
func (f *fixture) reconcile(t *testing.T, peer *tlsPeer, lab string, gen int64, refs []p.ProviderResourceRef) (present int) {
	t.Helper()
	id := uuid.NewString()
	discover := true
	peer.send(t, p.ReconcileRequestMessage{BaseEnvelope: p.BaseEnvelope{Type: p.MessageTypeReconcileRequest, MessageID: id, SentAt: time.Now().UTC(), OperationID: uuid.NewString(), LabInstanceID: lab, Generation: gen}, Payload: p.ReconcileRequestPayload{KnownResources: refs, DiscoverCandidates: &discover}})
	var result p.ReconcileResultMessage
	if json.Unmarshal(peer.wait(t, "control", p.MessageTypeReconcileResult, id, 2*time.Minute), &result) != nil || result.Payload.Error != nil || len(result.Payload.Observations) != len(refs) {
		t.Fatal("runtime Reconcile failed")
	}
	expected := make(map[p.ProviderResourceRef]bool, len(refs))
	for _, r := range refs {
		expected[r] = true
	}
	for _, o := range result.Payload.Observations {
		key := p.ProviderResourceRef{ResourceType: o.ResourceType, ProviderID: o.ProviderID, Generation: o.Generation, LogicalName: o.LogicalName}
		if !expected[key] || o.Source != "KNOWN_RESOURCE" {
			t.Fatal("unexpected/duplicate/mismatched Reconcile identity or discovery source")
		}
		delete(expected, key)
		if !o.Exists && o.ObservedState != "ABSENT" {
			t.Fatal("missing exact ABSENT state")
		}
		if o.Exists {
			present++
		}
	}
	if len(expected) != 0 {
		t.Fatal("missing exact Reconcile identities")
	}
	t.Logf("runtime Reconcile known=%d present=%d absent=%d", len(refs), present, len(refs)-present)
	return present
}
func query(t *testing.T, peer *tlsPeer, connection string) {
	t.Helper()
	id := uuid.NewString()
	peer.send(t, p.ProviderRequestMessage{BaseEnvelope: p.BaseEnvelope{Type: p.MessageTypeProviderRequest, MessageID: id, SentAt: time.Now().UTC()}, Payload: p.ProviderRequestPayload{RequestType: p.ProviderRequestValidateConnection, ProviderConnectionID: connection}})
	var result p.ProviderResponseMessage
	if json.Unmarshal(peer.wait(t, "control", p.MessageTypeProviderResponse, id, time.Minute), &result) != nil || result.Payload.Outcome != p.OutcomeSucceeded {
		t.Fatal("runtime lazy real Provider authentication/query failed")
	}
	t.Log("app.Run lazy real Provider query PASS")
}
func startRuntime(t *testing.T, peer *tlsPeer) (stop func()) {
	t.Helper()
	before := peer.count("control", p.MessageTypeHello)
	heartbeats := peer.count("control", p.MessageTypeHeartbeat)
	child := exec.Command(os.Args[0], "-test.run=^TestRuntimeChild$", "-test.timeout=45m")
	child.Env = append(os.Environ(), "LABBIT_RUNTIME_CHILD=1", "LABBIT_RUNTIME_CA_FILE="+peer.caFile)
	stdin, err := child.StdinPipe()
	if err != nil {
		t.Fatal("child stdin pipe failed")
	}
	child.Stdout = io.Discard
	child.Stderr = io.Discard
	if child.Start() != nil {
		t.Fatal("isolated app.Run helper failed to start")
	}
	done := make(chan error, 1)
	go func() { done <- child.Wait() }()
	var once sync.Once
	stop = func() {
		once.Do(func() {
			_ = stdin.Close() // EOF requests graceful app.Run cancellation, not force kill.
			select {
			case err := <-done:
				if err != nil {
					t.Error("app.Run returned shutdown error")
				}
			case <-time.After(10 * time.Second):
				t.Error("app.Run graceful shutdown timed out")
				_ = child.Process.Kill() // Only the exact helper process created by this harness.
				select {
				case <-done:
				case <-time.After(5 * time.Second):
					t.Error("owned helper process did not terminate")
				}
			}
		})
	}
	t.Cleanup(stop)
	peer.waitCount(t, "control", p.MessageTypeHello, before+1)
	peer.waitCount(t, "control", p.MessageTypeHeartbeat, heartbeats+1)
	t.Log("exact app.Run production TLS HELLO/ACK/Heartbeat PASS")
	return stop
}

func TestRuntimeChild(t *testing.T) {
	if os.Getenv("LABBIT_RUNTIME_CHILD") != "1" {
		t.Skip("subprocess helper only")
	}
	caBytes, err := os.ReadFile(os.Getenv("LABBIT_RUNTIME_CA_FILE"))
	if err != nil {
		t.Fatal("test peer CA unavailable")
	}
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(caBytes) {
		t.Fatal("test CA invalid")
	}
	// The parent fixture/cleanup process retains the normal platform verifier.
	// Only this dedicated child trusts the local TLS peer, with full validation.
	t.Setenv("GODEBUG", os.Getenv("GODEBUG")+",x509usefallbackroots=1")
	x509.SetFallbackRoots(roots)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go func() { _, _ = io.Copy(io.Discard, os.Stdin); cancel() }()
	if app.Run(ctx) != nil {
		t.Fatal("app.Run failed")
	}
}
func openTerminal(t *testing.T, peer *tlsPeer, lab string, gen int64, server string) string {
	t.Helper()
	session := uuid.NewString()
	id := uuid.NewString()
	peer.send(t, p.TerminalOpenMessage{BaseEnvelope: p.BaseEnvelope{Type: p.MessageTypeTerminalOpen, MessageID: id, SentAt: time.Now().UTC(), TerminalSessionID: session, LabInstanceID: lab, Generation: gen}, Payload: p.TerminalOpenPayload{TargetVmKey: "workspace", ProviderServerID: server, Cols: 80, Rows: 24}})
	var result p.TerminalOpenResultMessage
	if json.Unmarshal(peer.wait(t, "control", p.MessageTypeTerminalOpenResult, id, 30*time.Second), &result) != nil || result.Payload.Outcome != p.OutcomeSucceeded {
		t.Fatal("real VM runtime Terminal failed")
	}
	peer.shell(t, "stty -echo; printf '\\107\\117\\124\\105\\123\\124\\137\\122\\105\\101\\104\\131\\n'", "GOTEST_READY")
	return session
}
func closeTerminal(t *testing.T, peer *tlsPeer, lab, session string, gen int64) {
	t.Helper()
	peer.send(t, p.TerminalCloseMessage{BaseEnvelope: p.BaseEnvelope{Type: p.MessageTypeTerminalClose, MessageID: uuid.NewString(), SentAt: time.Now().UTC(), TerminalSessionID: session, LabInstanceID: lab, Generation: gen}, Payload: p.TerminalClosePayload{Reason: p.TerminalReasonSessionClosed}})
	peer.waitSession(t, "control", p.MessageTypeTerminalEnded, session)
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		peer.mu.Lock()
		closed := peer.closedDataSessions[session]
		peer.mu.Unlock()
		if closed {
			t.Log("real VM Terminal CLOSE/ENDED and Data socket closure PASS")
			return
		}
		time.Sleep(25 * time.Millisecond)
	}
	t.Fatal("Terminal Data socket leaked after close")
}
func serverID(t *testing.T, refs []p.ProviderResourceRef, vm string) string {
	t.Helper()
	for _, r := range refs {
		if r.ResourceType == provider.ResourceTypeServer && r.LogicalName == vm {
			return r.ProviderID
		}
	}
	t.Fatal("tracked server reference missing")
	return ""
}

func networkProbe(t *testing.T, peer *tlsPeer, allowed bool) {
	t.Helper()
	// No raw PTY transcript is persisted. The marker is encoded in input so
	// terminal echo cannot masquerade as executed VM output.
	want := "False"
	if allowed {
		want = "True"
	}
	code := "import socket,struct,subprocess\nwant=" + want + "\nfor host in ('1.1.1.1','1.0.0.1'):\n ok=False\n try:\n  s=socket.create_connection((host,443),4);s.close();ok=True\n except OSError: pass\n assert ok==want, 'TCP policy mismatch'\nq=struct.pack('!6H',32107,256,1,0,0,0)+b'\\x07example\\x03com\\x00'+struct.pack('!2H',1,1)\ns=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.settimeout(4);ok=False\ntry:\n s.sendto(q,('1.1.1.1',53));b,a=s.recvfrom(4096);ok=(a[0]=='1.1.1.1' and b[:2]==q[:2] and bool(b[2]&128) and not (b[3]&15))\nexcept OSError: pass\nfinally: s.close()\nassert ok==want, 'UDP DNS policy mismatch'\nassert not subprocess.check_output(['ip','-6','route','show','default']).strip(), 'unexpected IPv6 default route; investigate bypass'\nprint('NETWORK_POLICY_OK')\n"
	encoded := base64.StdEncoding.EncodeToString([]byte(code))
	peer.shell(t, "python3 -c \"exec(__import__('base64').b64decode('"+encoded+"'))\"", "NETWORK_POLICY_OK")
	t.Logf("actual VM IPv4 TCP443 two destinations + UDP DNS53 allowed=%t PASS; no IPv6 default route (not IPv6 reachability PASS)", allowed)
}

func TestProductionAppRunRealOpenStack(t *testing.T) {
	if os.Getenv("LABBIT_RUNTIME_REAL") != "1" {
		t.Skip("explicit owned-cloud runtime acceptance gate required")
	}
	sha, err := exec.Command("git", "rev-parse", "HEAD").Output()
	if err != nil || strings.TrimSpace(string(sha)) != sourceSHA {
		t.Fatal("exact tested source SHA required")
	}
	status, err := exec.Command("git", "status", "--porcelain").Output()
	if err != nil || len(status) != 0 {
		t.Fatal("clean tracked source required")
	}
	t.Logf("source=%s; separately hashed ignored harness; production code unchanged", sourceSHA)
	fixture := setupFixture(t)
	random := make([]byte, 32)
	if _, err := rand.Read(random); err != nil {
		t.Fatal(err)
	}
	credential := hex.EncodeToString(random)
	credPath := filepath.Join(t.TempDir(), "connector.credential")
	if os.WriteFile(credPath, []byte(credential), 0600) != nil {
		t.Fatal("temporary credential file failed")
	}
	t.Setenv("LABBIT_CONNECTOR_CREDENTIAL_FILE", credPath)
	peer := newPeer(t, credential)
	t.Setenv("LABBIT_SAAS_BASE_URL", peer.server.URL)
	t.Setenv("LABBIT_TERMINAL_RELAY_URL", "")
	t.Setenv("LABBIT_CONNECTOR_RUNTIME_ID", "")
	stop := startRuntime(t, peer)
	runtime1 := peer.runtimeID(t)
	query(t, peer, fixture.cfg.Provision.ProviderConnectionID)
	script := "#!/bin/sh\nset -eu\necho runtime-startup-ready\n"
	digest := sha256.Sum256([]byte(script))
	fixture.snapshot.StartupScript = &p.StartupScriptSnapshot{Content: script, SHA256: hex.EncodeToString(digest[:])}
	lab := uuid.NewString()
	result := fixture.operation(t, peer, lab, 1, p.MutationTypeProvision, fixture.snapshot, nil, false)
	if result.Payload.Outcome != p.OutcomeSucceeded {
		t.Fatal("production multiVM Provision failed")
	}
	refs1 := fixture.known[lab][1]
	if len(refs1) != 11 {
		t.Fatalf("2VM topology refs=%d want11", len(refs1))
	}
	if fixture.reconcile(t, peer, lab, 1, refs1) != 11 {
		t.Fatal("created 2VM topology incomplete")
	}
	server := serverID(t, refs1, "workspace")
	session := openTerminal(t, peer, lab, 1, server)
	networkProbe(t, peer, true)
	peer.assertAttachRuntime(t, session)
	peer.shell(t, "PROBE_COUNT=1; PROBE_PID=$$; printf '\\120\\111\\104\\137\\123\\105\\124\\n'", "PID_SET")
	peer.resize(t, lab, session, 1)
	peer.shell(t, "test \"$(stty size)\" = '37 101' && printf '\\122\\105\\123\\111\\132\\105\\137\\117\\113\\n'", "RESIZE_OK")
	attaches := peer.count("data", p.MessageTypeTerminalDataAttach)
	peer.drop("data")
	peer.waitCount(t, "data", p.MessageTypeTerminalDataAttach, attaches+1)
	peer.shell(t, "test \"$PROBE_PID\" = \"$$\" && test \"$PROBE_COUNT\" = 1 && printf '\\123\\101\\115\\105\\137\\120\\124\\131\\n'", "SAME_PTY")
	peer.assertAttachRuntime(t, session)
	hellos := peer.count("control", p.MessageTypeHello)
	peer.drop("control")
	peer.waitCount(t, "control", p.MessageTypeHello, hellos+1)
	query(t, peer, fixture.cfg.Provision.ProviderConnectionID)
	if peer.runtimeID(t) != runtime1 {
		t.Fatal("Control reconnect changed process runtime ID")
	}
	peer.shell(t, "test \"$PROBE_PID\" = \"$$\" && printf '\\103\\117\\116\\124\\122\\117\\114\\137\\117\\113\\n'", "CONTROL_OK")
	closeTerminal(t, peer, lab, session, 1)
	stop()
	stop = startRuntime(t, peer)
	if peer.runtimeID(t) == runtime1 {
		t.Fatal("new app.Run process did not change runtime ID")
	}
	query(t, peer, fixture.cfg.Provision.ProviderConnectionID)
	if fixture.reconcile(t, peer, lab, 1, refs1) != 11 {
		t.Fatal("restart lost actual cloud reality")
	}
	session = openTerminal(t, peer, lab, 1, server)
	closeTerminal(t, peer, lab, session, 1)
	t.Log("runtime restart reloaded existing server pin and real SSH PTY PASS")
	reset := fixture.operation(t, peer, lab, 2, p.MutationTypeReset, fixture.snapshot, refs1, false)
	if reset.Payload.Outcome != p.OutcomeSucceeded {
		t.Fatal("production Reset failed")
	}
	refs2 := fixture.known[lab][2]
	if fixture.reconcile(t, peer, lab, 2, refs2) != 11 {
		t.Fatal("generation2 incomplete")
	}
	session = openTerminal(t, peer, lab, 2, serverID(t, refs2, "workspace"))
	closeTerminal(t, peer, lab, session, 2)
	oldRequest := uuid.NewString()
	peer.send(t, p.TerminalOpenMessage{BaseEnvelope: p.BaseEnvelope{Type: p.MessageTypeTerminalOpen, MessageID: oldRequest, SentAt: time.Now().UTC(), TerminalSessionID: uuid.NewString(), LabInstanceID: lab, Generation: 2}, Payload: p.TerminalOpenPayload{TargetVmKey: "workspace", ProviderServerID: server, Cols: 80, Rows: 24}})
	var oldResult p.TerminalOpenResultMessage
	if json.Unmarshal(peer.wait(t, "control", p.MessageTypeTerminalOpenResult, oldRequest, 30*time.Second), &oldResult) != nil || oldResult.Payload.Outcome != p.OutcomeFailed {
		t.Fatal("deleted old server ID permitted Terminal")
	}
	t.Log("old deleted Server ID rejected after Reset (not forced ID reuse)")
	cleanSuccess := fixture.operation(t, peer, lab, 2, p.MutationTypeCleanup, nil, refs2, false)
	all := append(append([]p.ProviderResourceRef(nil), refs1...), refs2...)
	if cleanSuccess.Payload.Outcome != p.OutcomeSucceeded || fixture.reconcile(t, peer, lab, 2, all) != 0 {
		t.Fatal("successful lifecycle residual remained")
	}
	// Independent lab for the partial-delete fault, separate from successful Reset.
	faultSnapshot := *fixture.snapshot
	faultSnapshot.VMs = append([]p.ResolvedVmSpec(nil), fixture.snapshot.VMs[:1]...)
	faultLab := uuid.NewString()
	faultProvision := fixture.operation(t, peer, faultLab, 1, p.MutationTypeProvision, &faultSnapshot, nil, false)
	if faultProvision.Payload.Outcome != p.OutcomeSucceeded {
		t.Fatal("fault lab setup failed")
	}
	faultRefs := fixture.known[faultLab][1]
	// Extra port is solely owned by this harness. It intentionally blocks old
	// subnet/SG deletion and is never supplied as Connector-owned ProviderResource.
	networkID := ""
	sgID := ""
	for _, r := range faultRefs {
		if r.ResourceType == provider.ResourceTypeNetwork {
			networkID = r.ProviderID
		}
		if r.ResourceType == provider.ResourceTypeSecurityGroup {
			sgID = r.ProviderID
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Minute)
	defer cancel()
	sgs := []string{sgID}
	blocker, err := ports.Create(ctx, fixture.netClient, ports.CreateOpts{NetworkID: networkID, Name: "labbit-runtime-fault-" + uuid.NewString(), SecurityGroups: &sgs}).Extract()
	if err != nil {
		t.Fatal("owned fault port creation failed")
	}
	fixture.blockerIDs = append(fixture.blockerIDs, blocker.ID)
	partial := fixture.operation(t, peer, faultLab, 2, p.MutationTypeReset, &faultSnapshot, faultRefs, false)
	if partial.Payload.Outcome != p.OutcomeFailed {
		t.Fatal("Reset incorrectly succeeded despite real cleanup conflict")
	}
	if len(fixture.known[faultLab][2]) != 0 {
		t.Fatal("replacement generation created after partial deletion")
	}
	censusCtx, censusCancel := context.WithTimeout(context.Background(), time.Minute)
	candidatePages, listErr := servers.List(fixture.computeClient, servers.ListOpts{}).AllPages(censusCtx)
	censusCancel()
	if listErr != nil {
		t.Fatal("actual new generation census unavailable")
	}
	actualServers, listErr := servers.ExtractServers(candidatePages)
	if listErr != nil {
		t.Fatal("actual new generation census decode failed")
	}
	for _, s := range actualServers {
		if s.Metadata["labbit_lab_instance_id"] == faultLab && s.Metadata["labbit_generation"] == "2" {
			t.Fatal("actual g2 server created after old cleanup rejection")
		}
	}
	t.Log("fault lab actual Nova generation2 Server census0 (read-only, never deletion authority)")
	if fixture.reconcile(t, peer, faultLab, 2, []p.ProviderResourceRef{}) != 0 {
		t.Fatal("actual replacement generation candidates found after old cleanup rejection")
	}
	remaining := fixture.reconcile(t, peer, faultLab, 1, faultRefs)
	if remaining == 0 || remaining == len(faultRefs) {
		t.Fatal("partial-deletion residual not observed")
	}
	t.Log("separate fault lab Reset partial-delete FAILED; g2 wire refs0; Reconcile PRESENT+ABSENT mix before retry")
	removeCtx, removeCancel := context.WithTimeout(context.Background(), time.Minute)
	defer removeCancel()
	if ports.Delete(removeCtx, fixture.netClient, blocker.ID).ExtractErr() != nil {
		t.Fatal("owned blocker removal failed")
	}
	if _, err := ports.Get(removeCtx, fixture.netClient, blocker.ID).Extract(); !gophercloud.ResponseCodeIs(err, 404) {
		t.Fatal("owned blocker absence not confirmed")
	}
	clean := fixture.operation(t, peer, faultLab, 1, p.MutationTypeCleanup, nil, faultRefs, false)
	if clean.Payload.Outcome != p.OutcomeSucceeded {
		t.Fatal("reconciled Cleanup failed")
	}
	if fixture.reconcile(t, peer, faultLab, 1, faultRefs) != 0 {
		t.Fatal("provider residual remained")
	}
	// Worker without startup script and real partial multiVM startup failure.
	for _, scenario := range []string{"no-script", "worker-startup-failure"} {
		snap := *fixture.snapshot
		snap.StartupScript = nil
		expectedRefs := 11
		if scenario == "no-script" {
			snap.InternetOutbound = false
			expectedRefs = 10
		}
		if scenario == "worker-startup-failure" {
			content := "#!/bin/sh\nset -eu\ncase \"$(hostname)\" in *worker*) exit 7;; *) echo workspace-ready;; esac\n"
			sum := sha256.Sum256([]byte(content))
			snap.StartupScript = &p.StartupScriptSnapshot{Content: content, SHA256: hex.EncodeToString(sum[:])}
		}
		extraLab := uuid.NewString()
		r := fixture.operation(t, peer, extraLab, 1, p.MutationTypeProvision, &snap, nil, false)
		if scenario == "no-script" && r.Payload.Outcome != p.OutcomeSucceeded {
			t.Fatal("actual Workspace/Worker SSH readiness without script failed")
		}
		if scenario == "worker-startup-failure" && r.Payload.Outcome != p.OutcomeFailed {
			t.Fatal("actual failed Worker startup not FAILED")
		}
		refs := fixture.known[extraLab][1]
		if len(refs) != expectedRefs {
			t.Fatal("partial multiVM resource tracking incomplete")
		}
		if fixture.reconcile(t, peer, extraLab, 1, refs) != expectedRefs {
			t.Fatal("multiVM real resource tracking lost")
		}
		if scenario == "no-script" {
			session := openTerminal(t, peer, extraLab, 1, serverID(t, refs, "workspace"))
			networkProbe(t, peer, false)
			closeTerminal(t, peer, extraLab, session, 1)
		}
		r = fixture.operation(t, peer, extraLab, 1, p.MutationTypeCleanup, nil, refs, false)
		if r.Payload.Outcome != p.OutcomeSucceeded || fixture.reconcile(t, peer, extraLab, 1, refs) != 0 {
			t.Fatal("multiVM Cleanup residual")
		}
		t.Logf("%s actual2VM branch PASS; residual0", scenario)
	}
	stop()
	t.Log("exact app.Run + lazyProvider + Supervisor + real2VM lifecycle/PTY/reconnect/restart/partial-failure acceptance PASS")
}
